/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.lost;

import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.util.DeterministicRandom;
import org.junit.jupiter.api.Test;

import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

class Phase1LostFoundationTest {

    @Test
    void cityCenterAndRadiusMatchExactSourceFormulas() {
        LostCityProfile profile = new LostCityProfile("default");
        City city = new City(12345L, profile, null, null, 256, 300);

        for (int cx = -4; cx <= 4; cx++) {
            for (int cz = -4; cz <= 4; cz++) {
                ChunkCoord c = new ChunkCoord("lostcities:world", cx, cz);
                boolean expectedCenter = new Random(cz * 797003437L + cx * 295075153L).nextDouble() < profile.cityChance;
                assertEquals(expectedCenter, city.isCityCenter(c));

                Random rr = new Random(cz * 100001653L + cx * 295075153L);
                float expectedRadius = profile.cityMinRadius + rr.nextInt(profile.cityMaxRadius - profile.cityMinRadius);
                assertEquals(expectedRadius, city.getCityRadius(c), 1e-6f);
            }
        }
    }

    @Test
    void citySphereUsesExactSourceSeed961744153And837971201() {
        LostCityProfile profile = new LostCityProfile("space");
        profile.grid32 = true; // isolate single sphere without 16-grid neighbor suppression
        long seed = 55555L;
        CitySphere.Cache cache = new CitySphere.Cache(seed, profile, null, 64, 300);
        ChunkCoord center = new ChunkCoord("lostcities:world", 8, 8);
        CitySphere actual = cache.getCitySphere(center);

        Random expectedRand = new Random(seed + 8 * 961744153L + 8 * 837971201L);
        boolean expectedEnabled = expectedRand.nextFloat() < profile.citySphereChance;
        assertEquals(expectedEnabled, actual.isEnabled());
    }

    @Test
    void damageAreaMatchesExactExplosionFormulaAndEasyBreakableMultiplier() {
        LostCityProfile profile = new LostCityProfile("default");
        profile.explosionChance = 1.0f;
        profile.miniExplosionChance = 0.0f;
        long seed = 42L;
        DamageArea area = new DamageArea(seed, "lostcities:world", 0, 0, profile, c -> true, c -> 0, null);
        assertTrue(area.hasExplosions());

        Explosion e0 = area.getExplosions().get(0);
        double d = Math.sqrt(e0.distSqToCenter(e0.centerX(), e0.centerY(), e0.centerZ()));
        float expectedSelfDamage = (float) (3.0f * (e0.radius() - d) / e0.radius());
        assertTrue(area.getDamage(e0.centerX(), e0.centerY(), e0.centerZ()) >= expectedSelfDamage - 1e-4f);
        assertEquals(2.5f, DamageArea.EASY_BREAKABLE_MULTIPLIER, 1e-6f);
        assertEquals(0.7f, DamageArea.BLOCK_DAMAGE_CHANCE, 1e-6f);
    }

    @Test
    void railwayStationMatchesExactSourceQualityRandomAnd05Threshold() {
        LostCityProfile profile = new LostCityProfile("default");
        long seed = 12345L;
        Railway railway = new Railway(seed, 256, 300);
        // mx = floorMod(cx+1, 20) == 0, mz = floorMod(cz+1, 20) == 10 -> cx = -1, cz = 9
        ChunkCoord stationCoord = new ChunkCoord("lostcities:world", -1, 9);
        Railway.Context ctx = new Railway.Context() {
            @Override public boolean isCityRaw(ChunkCoord c) { return true; }
            @Override public int getCityLevel(ChunkCoord c) { return 0; }
            @Override public int getHighwayXLevel(ChunkCoord c) { return -1; }
            @Override public int getHighwayZLevel(ChunkCoord c) { return -1; }
            @Override public boolean isOnSphereBorder(ChunkCoord c) { return false; }
        };
        Railway.RailChunkInfo info = railway.getRailChunkType(stationCoord, profile, ctx);
        float expectedR = new DeterministicRandom.QualityRandom(seed + 9 * 2600003897L + (-1) * 43600002517L).nextFloat();
        RailChunkType expectedType = expectedR < 0.5f ? RailChunkType.STATION_SURFACE : RailChunkType.STATION_UNDERGROUND;
        assertEquals(expectedType, info.type());
        assertEquals(3, info.rails());
        assertEquals(-3, Railway.getRailwayLevel(profile));
    }
}
