/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.terrain;

import mcjty.lostcities.paper.config.LostCityProfile;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class Phase2DTerrainFieldTest {

    @Test
    void noImpossibleBiomesAcrossTenThousandSamples() {
        LostCityProfile profile = new LostCityProfile("default");
        TerrainHeightField field = new TerrainHeightField(12345L, profile);
        int sea = field.seaLevel();

        for (int x = -500; x < 500; x += 10) {
            for (int z = -500; z < 500; z += 10) {
                TerrainHeightField.Sample s = field.sample(x, z);
                if (s.height() < sea) {
                    assertTrue(s.waterBiome(), "Underwater height must be water biome, got " + s.biomeId());
                    assertNotEquals("minecraft:desert", s.biomeId());
                } else if (s.height() > sea + 2) {
                    assertFalse(s.waterBiome(), "Dry land above beach must not be water biome, got " + s.biomeId());
                }
            }
        }
    }

    @Test
    void generateNoiseSamplingMeetsP95TargetUnder4MsPerChunk() {
        LostCityProfile profile = new LostCityProfile("default");
        TerrainHeightField field = new TerrainHeightField(777L, profile);
        long[] chunkNanos = new long[100];
        for (int i = 0; i < 100; i++) {
            int bx = (i % 10) << 4;
            int bz = (i / 10) << 4;
            long t0 = System.nanoTime();
            for (int lx = 0; lx < 16; lx++) {
                for (int lz = 0; lz < 16; lz++) {
                    field.sample(bx + lx, bz + lz);
                }
            }
            chunkNanos[i] = System.nanoTime() - t0;
        }
        Arrays.sort(chunkNanos);
        double p95Ms = chunkNanos[94] / 1_000_000.0;
        assertTrue(p95Ms < 4.0, "TerrainHeightField per-chunk p95 should be < 4.0ms, got " + p95Ms + "ms");
    }
}
