/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

import mcjty.lostcities.paper.assets.AssetLoader;
import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.config.HighwayGenerationMode;
import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.highway.HighwayModels.HighwayInfo;
import mcjty.lostcities.paper.core.lost.City;
import mcjty.lostcities.paper.core.lost.Highway;
import mcjty.lostcities.paper.core.lost.MultiChunk;
import mcjty.lostcities.paper.core.lost.Railway;
import mcjty.lostcities.paper.core.plan.ChunkPlanner;
import mcjty.lostcities.paper.core.terrain.TerrainHeightField;
import mcjty.lostcities.paper.util.PathSecurity;
import org.junit.jupiter.api.Test;

import java.nio.file.Path;
import java.util.List;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.*;

class Phase2BuildingInfoTest {

    @Test
    void computeCityLevelUsesExactProfileHeightThresholds() {
        LostCityProfile p = new LostCityProfile("default");
        ChunkCoord c = new ChunkCoord("lostcities:world", 0, 0);
        assertEquals(0, BuildingInfo.computeCityLevel(c, 1L, p, 70));
        assertEquals(1, BuildingInfo.computeCityLevel(c, 1L, p, 78));
        assertEquals(2, BuildingInfo.computeCityLevel(c, 1L, p, 85));
        assertEquals(7, BuildingInfo.computeCityLevel(c, 1L, p, 140));
    }

    @Test
    void buildingInfoSelectsPartsFromBuildingAssetRulesNotGlobalRandom() {
        AssetRegistry registry = new AssetLoader(
                Path.of("src/main/resources/data/lostcities/lostcities"),
                PathSecurity.DEFAULT_MAX_JSON_BYTES,
                Logger.getLogger("test")
        ).loadAll();
        LostCityProfile profile = new LostCityProfile("onlycities");
        profile.cityChance = 0.5;
        profile.buildingChance = 1.0f;
        ChunkPlanner planner = new ChunkPlanner(256, 300);
        City city = new City(12345L, profile, registry, null, 256, 300);

        BuildingInfo info = BuildingInfo.get(
                new ChunkCoord("lostcities:world", 0, 0), 12345L, profile, registry, planner,
                city, new TerrainHeightField(12345L, profile), HighwayInfo.NONE, Railway.RailChunkInfo.NOTHING);

        assertNotNull(info.getCityStyleId());
        assertFalse(info.getCityStyleId().isBlank());
        assertEquals(BuildingInfo.NO_CITY_HEIGHT_SENTINEL,
                BuildingInfo.getLowestCityHeightAtChunkCorner(info, info, info, info));
        assertTrue(info.isTunnel(0, 100) || !info.isTunnel(5, 71));
    }

    @Test
    void legacyHighwayEnforcesSpanAtLeast5AndCityLevelMode() {
        LostCityProfile p = new LostCityProfile("default");
        p.highwayGenerationMode = HighwayGenerationMode.LEGACY;
        p.highwayPerlinFactor = -100.0f; // force noise true for span test
        p.highwayLevelFromCities = 3;
        Highway hw = new Highway(12345L, 256, 300);
        HighwayInfo info = hw.computeHighwayInfo(
                new ChunkCoord("lostcities:world", 0, 0), p, null, c -> true, c -> 2, c -> false);
        assertEquals(2, info.xLevel());
        assertEquals(2, info.zLevel());
    }

    @Test
    void multiChunkEnforcesCorrectStyleFactor() {
        AssetRegistry registry = new AssetLoader(
                Path.of("src/main/resources/data/lostcities/lostcities"),
                PathSecurity.DEFAULT_MAX_JSON_BYTES,
                Logger.getLogger("test")
        ).loadAll();
        MultiChunk.Cache cache = new MultiChunk.Cache(32, 300);
        MultiChunk.Settings strict = new MultiChunk.Settings(8, 2, 2, 1.0f, 30);
        MultiChunk mc = cache.getOrCreate(
                new ChunkCoord("lostcities:world", 0, 0), strict, registry,
                c -> "lostcities:citystyle_standard",
                s -> List.of("lostcities:center"),
                c -> 0,
                c -> true
        );
        assertNotNull(mc);
    }
}
