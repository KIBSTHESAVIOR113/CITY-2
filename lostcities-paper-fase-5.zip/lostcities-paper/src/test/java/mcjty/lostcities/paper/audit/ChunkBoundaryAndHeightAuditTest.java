/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.audit;

import mcjty.lostcities.paper.assets.AssetLoader;
import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.BlockSurface;
import mcjty.lostcities.paper.core.ChunkDriver;
import mcjty.lostcities.paper.core.LostCityTerrainFeature;
import mcjty.lostcities.paper.core.lost.City;
import mcjty.lostcities.paper.core.plan.ChunkPlanner;
import mcjty.lostcities.paper.core.terrain.TerrainHeightField;
import mcjty.lostcities.paper.util.PathSecurity;
import org.junit.jupiter.api.Test;

import java.nio.file.Path;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Putaran 8 Audit Harness: verifies 200 chunk-boundary samples and both [0..256]
 * LostCities dimension height and [-64..320] adaptive Overworld fallback.
 */
class ChunkBoundaryAndHeightAuditTest {

    private static final class BoundedSurface implements BlockSurface {
        private final int cx, cz, minY, maxY;
        final Map<Long, String> blocks = new TreeMap<>();
        BoundedSurface(int cx, int cz, int minY, int maxY) { this.cx = cx; this.cz = cz; this.minY = minY; this.maxY = maxY; }
        @Override public int minY() { return minY; }
        @Override public int maxY() { return maxY; }
        @Override public boolean isInBounds(int x, int y, int z) { return (x >> 4) == cx && (z >> 4) == cz && y >= minY && y < maxY; }
        @Override public String getBlockId(int x, int y, int z) { return blocks.getOrDefault(ChunkDriver.packPos(x, y, z), y <= 64 ? "minecraft:stone" : "minecraft:air"); }
        @Override public void setBlockId(int x, int y, int z, String blockId) {
            assertTrue(y >= minY && y < maxY, "Out-of-height write detected: y=" + y);
            blocks.put(ChunkDriver.packPos(x, y, z), blockId);
        }
    }

    @Test
    void twoHundredBoundaryChunksRespectMinMaxHeightInBothModes() {
        AssetRegistry registry = new AssetLoader(
                Path.of("src/main/resources/data/lostcities/lostcities"),
                PathSecurity.DEFAULT_MAX_JSON_BYTES,
                Logger.getLogger("audit")
        ).loadAll();
        LostCityProfile profile = new LostCityProfile("default");

        int[][] heightModes = new int[][]{{0, 256}, {-64, 320}};
        for (int[] mode : heightModes) {
            LostCityTerrainFeature feature = new LostCityTerrainFeature(20260101L, "lostcities:lostcity", profile);
            ChunkPlanner planner = new ChunkPlanner(4096, 300);
        City city = new City(12345L, profile, registry, null, 2048, 300);
        TerrainHeightField field = new TerrainHeightField(12345L, profile);
            int sampled = 0;
            for (int cx = 0; cx < 10; cx++) {
                for (int cz = 0; cz < 10; cz++) {
                    BoundedSurface s = new BoundedSurface(cx, cz, mode[0], mode[1]);
                    Map<Long, String> cross = feature.generateChunk(s, cx, cz, registry, planner, city, field, null);
                    assertNotNull(cross);
                    sampled++;
                }
            }
            assertEquals(100, sampled);
        }
    }
}
