/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.highway.HighwayModels.HighwayInfo;
import mcjty.lostcities.paper.core.lost.City;
import mcjty.lostcities.paper.core.lost.Railway;
import mcjty.lostcities.paper.core.plan.ChunkPlanner;
import mcjty.lostcities.paper.core.terrain.TerrainHeightField;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.*;

class Phase3TerrainShapingTest {

    private static final class MapSurface implements BlockSurface {
        final Map<Long, String> blocks = new HashMap<>();
        final int minY = -64;
        final int maxY = 320;
        final int bx, bz;

        MapSurface(int cx, int cz) { this.bx = cx << 4; this.bz = cz << 4; }

        @Override public int minY() { return minY; }
        @Override public int maxY() { return maxY; }
        @Override public boolean isInBounds(int x, int y, int z) {
            return x >= bx && x < bx + 16 && z >= bz && z < bz + 16 && y >= minY && y < maxY;
        }
        @Override public String getBlockId(int x, int y, int z) {
            return blocks.getOrDefault(ChunkDriver.pack(x, y, z), "minecraft:air");
        }
        @Override public void setBlockId(int x, int y, int z, String id) {
            if ("minecraft:air".equals(id)) blocks.remove(ChunkDriver.pack(x, y, z));
            else blocks.put(ChunkDriver.pack(x, y, z), id);
        }
    }

    @Test
    void terrainHeightFieldReachesMountainPeaksAndClimateBiomes() {
        LostCityProfile p = LostCityProfile.createDefault("default");
        TerrainHeightField field = new TerrainHeightField(20260301L, p);
        int maxH = Integer.MIN_VALUE;
        int minH = Integer.MAX_VALUE;
        Set<String> biomes = new HashSet<>();
        for (int x = -2400; x <= 2400; x += 24) {
            for (int z = -2400; z <= 2400; z += 24) {
                TerrainHeightField.Sample s = field.sample(x, z);
                maxH = Math.max(maxH, s.height());
                minH = Math.min(minH, s.height());
                biomes.add(s.biomeId());
                if (s.height() < field.seaLevel()) {
                    assertTrue(s.waterBiome(), "Underwater biome must be water biome, got " + s.biomeId());
                }
            }
        }
        assertTrue(maxH >= 145, "Expected mountain peaks >= 145, got " + maxH);
        assertTrue(minH <= 55, "Expected oceans/valleys <= 55, got " + minH);
        assertTrue(biomes.size() >= 8, "Expected diverse climate biomes, got " + biomes);
    }

    @Test
    void moveDownPreservesSixSurfaceLayers() {
        LostCityProfile p = LostCityProfile.createDefault("default");
        LostCityTerrainFeature feature = new LostCityTerrainFeature(42L, "lostcities:world", p);
        MapSurface surface = new MapSurface(0, 0);
        for (int y = 0; y <= 90; y++) surface.setBlockId(4, y, 4, "minecraft:stone");
        surface.setBlockId(4, 91, 4, "minecraft:dirt");
        surface.setBlockId(4, 92, 4, "minecraft:dirt");
        surface.setBlockId(4, 93, 4, "minecraft:grass_block");

        try (GenerationContext.Scope ignored = GenerationContext.open(42L, "lostcities:world", 0, 0)) {
            ChunkDriver driver = GenerationContext.current().driver();
            driver.begin(surface, 0, 0);
            TerrainHeightField field = new TerrainHeightField(42L, p);
            City city = new City(42L, p, new AssetRegistry(), null, 128, 60);
            BuildingInfo info = BuildingInfo.get(new ChunkCoord("lostcities:world", 0, 0), 42L, p,
                    new AssetRegistry(), new ChunkPlanner(128, 60), city, field, HighwayInfo.NONE, Railway.RailChunkInfo.NOTHING);
            assertTrue(feature.moveDown(driver, info, 4, 4, 80, 319));
            driver.flush();
        }
        assertEquals("minecraft:grass_block", surface.getBlockId(4, 80, 4));
        assertEquals("minecraft:dirt", surface.getBlockId(4, 79, 4));
        assertEquals("minecraft:air", surface.getBlockId(4, 81, 4));
        assertEquals("minecraft:air", surface.getBlockId(4, 93, 4));
    }

    @Test
    void bipolateAndDesiredMaxHeightL1L2AreDeterministic() {
        assertEquals(70.0f, LostCityTerrainFeature.bipolate(70, 70, 70, 70, 7, 7), 0.001f);
        assertEquals(75.0f, LostCityTerrainFeature.bipolate(70, 80, 70, 80, 7, 0), 1.0f);

        LostCityProfile p = LostCityProfile.createDefault("default");
        AssetRegistry reg = new AssetRegistry();
        ChunkPlanner planner = new ChunkPlanner(512, 60);
        City city = new City(999L, p, reg, null, 256, 60);
        TerrainHeightField field = new TerrainHeightField(999L, p);
        Function<ChunkCoord, BuildingInfo> lookup = c -> BuildingInfo.get(
                c, 999L, p, reg, planner, city, field, HighwayInfo.NONE, Railway.RailChunkInfo.NOTHING);
        BuildingInfo info = lookup.apply(new ChunkCoord("lostcities:world", 0, 0));
        BuildingInfo.MinMax l1 = info.getDesiredMaxHeightL1(lookup);
        BuildingInfo.MinMax l2 = info.getDesiredMaxHeightL2(lookup);
        assertNotNull(l1);
        assertNotNull(l2);
        assertTrue(l2.min <= l2.max);
    }
}
