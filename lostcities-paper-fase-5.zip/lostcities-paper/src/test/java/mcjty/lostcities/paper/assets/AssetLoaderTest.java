/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.assets;

import mcjty.lostcities.paper.util.PathSecurity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.*;

class AssetLoaderTest {

    @Test
    void loadsAllBuiltinAssetsMatchingPrdCounts() {
        Path builtinAssets = Path.of("src/main/resources/data/lostcities/lostcities");
        AssetLoader loader = new AssetLoader(builtinAssets, PathSecurity.DEFAULT_MAX_JSON_BYTES, Logger.getLogger("test"));
        AssetRegistry reg = loader.loadAll();

        assertEquals(207, reg.parts().size());
        assertEquals(37, reg.buildings().size());
        assertEquals(30, reg.palettes().size());
        assertEquals(14, reg.multiBuildings().size());
        assertEquals(12, reg.variants().size());
        assertEquals(5, reg.cityStyles().size());
        assertEquals(5, reg.scattered().size());
        assertEquals(4, reg.styles().size());
        assertEquals(3, reg.stuff().size());
        assertEquals(3, reg.conditions().size());
        assertEquals(2, reg.worldStyles().size());
        assertTrue(reg.hasCriticalAssets());
    }

    @Test
    void corruptedJsonAssetIsSkippedWithoutCrash(@TempDir Path tmp) throws Exception {
        Path partsDir = tmp.resolve("parts");
        Files.createDirectories(partsDir);
        Files.writeString(partsDir.resolve("broken.json"), "{ not valid json");
        Files.writeString(partsDir.resolve("valid.json"), "{"xsize":16,"zsize":16,"slices":[["................"]]}");

        AssetLoader loader = new AssetLoader(tmp, PathSecurity.DEFAULT_MAX_JSON_BYTES, Logger.getLogger("test"));
        AssetRegistry reg = loader.loadAll();
        assertEquals(1, reg.parts().size());
        assertNotNull(reg.getPart("valid"));
        assertNull(reg.getPart("broken"));
    }

    @Test
    void rejectsPathTraversalAndOversizedJson(@TempDir Path tmp) throws Exception {
        assertThrows(IllegalArgumentException.class, () -> PathSecurity.validateSafeName("../secret", "profile"));
        assertThrows(IllegalArgumentException.class, () -> PathSecurity.resolveInside(tmp, "../../etc/passwd"));

        Path big = tmp.resolve("big.json");
        Files.writeString(big, "a".repeat(2048));
        assertThrows(Exception.class, () -> PathSecurity.readBoundedUtf8(big, 1024));
    }
}
