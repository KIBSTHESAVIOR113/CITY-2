/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.highway;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Function;

/**
 * Bounded LRU cache of {@link CompletableFuture} values ported from LostCities
 * {@code BoundedFutureCache}, removing failed futures so transient errors do not stick.
 */
public final class BoundedFutureCache<K, V> {

    private final int maxSize;
    private final ReentrantLock lock = new ReentrantLock();
    private final LinkedHashMap<K, CompletableFuture<V>> map;

    public BoundedFutureCache(int maxSize) {
        this.maxSize = Math.max(32, maxSize);
        this.map = new LinkedHashMap<>(Math.min(this.maxSize, 256), 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<K, CompletableFuture<V>> eldest) {
                return size() > BoundedFutureCache.this.maxSize;
            }
        };
    }

    public CompletableFuture<V> computeIfAbsent(K key, Function<K, CompletableFuture<V>> factory) {
        lock.lock();
        try {
            CompletableFuture<V> existing = map.get(key);
            if (existing != null) {
                return existing;
            }
            CompletableFuture<V> created = factory.apply(key);
            map.put(key, created);
            created.whenComplete((val, err) -> {
                if (err != null) {
                    lock.lock();
                    try {
                        map.remove(key, created);
                    } finally {
                        lock.unlock();
                    }
                }
            });
            return created;
        } finally {
            lock.unlock();
        }
    }

    public int size() {
        lock.lock();
        try {
            return map.size();
        } finally {
            lock.unlock();
        }
    }

    public void clear() {
        lock.lock();
        try {
            map.clear();
        } finally {
            lock.unlock();
        }
    }
}
