/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.lost;

import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.util.BoundedCache;

import java.util.function.Function;

/**
 * Per-world bounded cache of main chunk biome IDs (replaces static {@code BiomeInfo}).
 */
public final class BiomeInfo {

    private final String mainBiomeId;

    public BiomeInfo(String mainBiomeId) {
        this.mainBiomeId = mainBiomeId;
    }

    public String getMainBiomeId() {
        return mainBiomeId;
    }

    public static final class Cache {
        private final BoundedCache<ChunkCoord, BiomeInfo> cache;

        public Cache(int maxEntries, int ttlSeconds) {
            this.cache = new BoundedCache<>(maxEntries, ttlSeconds);
        }

        public BiomeInfo get(ChunkCoord coord, Function<ChunkCoord, String> biomeLookup) {
            return cache.computeIfAbsent(coord, k -> new BiomeInfo(biomeLookup.apply(k)));
        }

        public void clear() {
            cache.clear();
        }
    }
}
