/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.plan;

import mcjty.lostcities.paper.core.BuildingInfo;
import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.util.BoundedCache;

import java.util.concurrent.atomic.LongAdder;
import java.util.function.Supplier;

/**
 * Instance-scoped (per-world) staged planner with {@link BuildingInfo} cache hit/miss
 * instrumentation and per-chunk {@link BuildingInfo.MinMax} cache (C3).
 */
public final class ChunkPlanner {

    private final BoundedCache<ChunkCoord, ChunkPlan> plans;
    private final BoundedCache<ChunkCoord, Integer> cityLevels;
    private final BoundedCache<ChunkCoord, BuildingInfo.MinMax> minMaxL2Cache;
    private final LongAdder biLookups = new LongAdder();
    private final LongAdder biComputes = new LongAdder();

    public ChunkPlanner(int maxEntries, int ttlSeconds) {
        this.plans = new BoundedCache<>(maxEntries, ttlSeconds);
        this.cityLevels = new BoundedCache<>(maxEntries, ttlSeconds);
        this.minMaxL2Cache = new BoundedCache<>(maxEntries, ttlSeconds);
    }

    public int cityLevel(ChunkCoord coord, Supplier<Integer> supplier) {
        return cityLevels.computeIfAbsent(coord, k -> supplier.get());
    }

    public BuildingInfo.MinMax minMaxL2(ChunkCoord coord, Supplier<BuildingInfo.MinMax> supplier) {
        return minMaxL2Cache.computeIfAbsent(coord, k -> supplier.get());
    }

    public <T> T highway(ChunkCoord coord, Supplier<T> supplier) {
        ChunkPlan plan = plans.computeIfAbsent(coord, k -> new ChunkPlan());
        return plan.highway(supplier);
    }

    public BuildingInfo.Characteristics characteristics(ChunkCoord coord, Supplier<Staged<BuildingInfo.Characteristics>> supplier) {
        ChunkPlan plan = plans.computeIfAbsent(coord, k -> new ChunkPlan());
        return plan.characteristics(supplier);
    }

    public BuildingInfo buildingInfo(ChunkCoord coord, Supplier<Staged<BuildingInfo>> supplier) {
        biLookups.increment();
        ChunkPlan plan = plans.computeIfAbsent(coord, k -> new ChunkPlan());
        return plan.buildingInfo(() -> {
            biComputes.increment();
            return supplier.get();
        });
    }

    public void clear() {
        plans.clear();
        cityLevels.clear();
        minMaxL2Cache.clear();
    }

    public int planCacheSize() { return plans.size(); }
    public double planHitRate() { return plans.hitRate(); }
    public long buildingInfoLookups() { return biLookups.sum(); }
    public long buildingInfoComputes() { return biComputes.sum(); }

    public double buildingInfoHitRate() {
        long l = biLookups.sum();
        if (l == 0) return 0.0;
        long hits = Math.max(0L, l - biComputes.sum());
        return (hits * 100.0) / l;
    }
}
