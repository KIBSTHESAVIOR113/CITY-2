/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.highway;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import mcjty.lostcities.paper.core.highway.HighwayModels.HighwayHub;
import mcjty.lostcities.paper.core.highway.HighwayModels.HubKey;
import mcjty.lostcities.paper.persistence.AtomicFileStore;

import java.io.IOException;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Atomic, versioned persistence for inter-city highway hubs with signature verification.
 */
public final class HighwayStore {

    public static final int FORMAT_VERSION = 2;
    private static final String FILE_NAME = "highways.json";

    private final AtomicFileStore fileStore;
    private final long cacheSignature;
    private final ReentrantLock lock = new ReentrantLock();
    private final Map<HubKey, Optional<HighwayHub>> hubs = new TreeMap<>();
    private volatile boolean dirty = false;

    public HighwayStore(AtomicFileStore fileStore, long cacheSignature) {
        this.fileStore = fileStore;
        this.cacheSignature = cacheSignature;
        loadFromDisk();
    }

    private void loadFromDisk() {
        Optional<JsonObject> loaded = fileStore.readVersioned(FILE_NAME, FORMAT_VERSION);
        if (loaded.isEmpty()) return;
        JsonObject data = loaded.get();
        long sig = data.has("signature") ? data.get("signature").getAsLong() : Long.MIN_VALUE;
        if (sig != cacheSignature) {
            return;
        }
        if (!data.has("hubs") || !data.get("hubs").isJsonArray()) return;
        lock.lock();
        try {
            for (JsonElement el : data.getAsJsonArray("hubs")) {
                if (!el.isJsonObject()) continue;
                JsonObject ho = el.getAsJsonObject();
                HubKey key = new HubKey(ho.get("cellX").getAsInt(), ho.get("cellZ").getAsInt());
                boolean hasHub = ho.get("hasHub").getAsBoolean();
                if (hasHub) {
                    hubs.put(key, Optional.of(new HighwayHub(
                            key,
                            ho.get("chunkX").getAsInt(),
                            ho.get("chunkZ").getAsInt(),
                            ho.get("potential").getAsInt(),
                            ho.get("cityLevel").getAsInt()
                    )));
                } else {
                    hubs.put(key, Optional.empty());
                }
            }
        } finally {
            lock.unlock();
        }
    }

    public Optional<Optional<HighwayHub>> lookup(HubKey key) {
        lock.lock();
        try {
            return Optional.ofNullable(hubs.get(key));
        } finally {
            lock.unlock();
        }
    }

    public void store(HubKey key, Optional<HighwayHub> hub) {
        lock.lock();
        try {
            hubs.put(key, hub);
            dirty = true;
        } finally {
            lock.unlock();
        }
    }

    public void flushIfDirty() throws IOException {
        if (!dirty) return;
        JsonObject data = new JsonObject();
        data.addProperty("signature", cacheSignature);
        JsonArray arr = new JsonArray();
        lock.lock();
        try {
            for (Map.Entry<HubKey, Optional<HighwayHub>> e : hubs.entrySet()) {
                JsonObject ho = new JsonObject();
                ho.addProperty("cellX", e.getKey().planningCellX());
                ho.addProperty("cellZ", e.getKey().planningCellZ());
                ho.addProperty("hasHub", e.getValue().isPresent());
                if (e.getValue().isPresent()) {
                    HighwayHub h = e.getValue().get();
                    ho.addProperty("chunkX", h.chunkX());
                    ho.addProperty("chunkZ", h.chunkZ());
                    ho.addProperty("potential", h.potentialScore());
                    ho.addProperty("cityLevel", h.cityLevel());
                }
                arr.add(ho);
            }
            dirty = false;
        } finally {
            lock.unlock();
        }
        data.add("hubs", arr);
        fileStore.writeVersioned(FILE_NAME, FORMAT_VERSION, data);
    }
}
