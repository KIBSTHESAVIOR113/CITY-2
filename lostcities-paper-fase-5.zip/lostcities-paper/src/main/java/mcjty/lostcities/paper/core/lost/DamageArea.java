/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.lost;

import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.ChunkCoord;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToIntFunction;

/**
 * Port of {@code mcjty.lostcities.worldgen.lost.DamageArea} preserving all source literals:
 * longs (295075153L, 899826547L, 797003437L, 1400305337L, 573259391L) and
 * floats/doubles (256.0, 2.5f, 0.7f, 3.0f, -3.0, 16.0).
 */
public final class DamageArea {

    public static final float BLOCK_DAMAGE_CHANCE = 0.7f;
    public static final float EASY_BREAKABLE_MULTIPLIER = 2.5f;
    private static final double CHUNK_BOX_HEIGHT = 256.0;

    private final int chunkX;
    private final int chunkZ;
    private final List<Explosion> explosions;

    public DamageArea(
            long seed,
            String dimensionId,
            int chunkX,
            int chunkZ,
            LostCityProfile profile,
            Predicate<ChunkCoord> isCityPredicate,
            ToIntFunction<ChunkCoord> cityLevelProvider,
            Function<ChunkCoord, Float> cityStyleExplosionChance
    ) {
        this.chunkX = chunkX;
        this.chunkZ = chunkZ;
        List<Explosion> list = new ArrayList<>();

        double minX = chunkX << 4;
        double minZ = chunkZ << 4;
        double maxX = minX + 15.0;
        double maxZ = minZ + 15.0;

        // Exact seed from DamageArea.java:44
        Random damageRandom = new Random(seed + chunkZ * 295075153L + chunkX * 899826547L);

        int offset = (Math.max(profile.explosionMaxRadius, profile.miniExplosionMaxRadius) + 15) / 16;
        for (int cx = chunkX - offset; cx <= chunkX + offset; cx++) {
            for (int cz = chunkZ - offset; cz <= chunkZ + offset; cz++) {
                ChunkCoord coord = new ChunkCoord(dimensionId, cx, cz);
                if (!profile.explosionsInCitiesOnly || isCityPredicate.test(coord)) {
                    Explosion big = getExplosionAt(seed, coord, profile, cityLevelProvider);
                    if (big != null && intersectsBox(minX, 0.0, minZ, maxX, CHUNK_BOX_HEIGHT, maxZ, big)) {
                        Float chance = cityStyleExplosionChance == null ? null : cityStyleExplosionChance.apply(coord);
                        if (chance == null || damageRandom.nextFloat() < chance) {
                            list.add(big);
                        }
                    }
                    Explosion mini = getMiniExplosionAt(seed, coord, profile, cityLevelProvider);
                    if (mini != null && intersectsBox(minX, 0.0, minZ, maxX, CHUNK_BOX_HEIGHT, maxZ, mini)) {
                        Float chance = cityStyleExplosionChance == null ? null : cityStyleExplosionChance.apply(coord);
                        if (chance == null || damageRandom.nextFloat() < chance) {
                            list.add(mini);
                        }
                    }
                }
            }
        }
        this.explosions = Collections.unmodifiableList(list);
    }

    private static Explosion getExplosionAt(long seed, ChunkCoord coord, LostCityProfile profile, ToIntFunction<ChunkCoord> cityLevelProvider) {
        if (profile.explosionChance <= 0.0f) return null;
        // Exact seed from DamageArea.java:103
        Random rand = new Random(seed + coord.chunkZ() * 295075153L + coord.chunkX() * 797003437L);
        if (rand.nextFloat() < profile.explosionChance) {
            int rRange = Math.max(1, profile.explosionMaxRadius - profile.explosionMinRadius);
            int hRange = Math.max(1, profile.explosionMaxHeight - profile.explosionMinHeight);
            int radius = profile.explosionMinRadius + rand.nextInt(rRange);
            int x = (coord.chunkX() << 4) + rand.nextInt(16);
            int y = cityLevelProvider.applyAsInt(coord) * 6 + profile.explosionMinHeight + rand.nextInt(hRange);
            int z = (coord.chunkZ() << 4) + rand.nextInt(16);
            return new Explosion(radius, x, y, z);
        }
        return null;
    }

    private static Explosion getMiniExplosionAt(long seed, ChunkCoord coord, LostCityProfile profile, ToIntFunction<ChunkCoord> cityLevelProvider) {
        if (profile.miniExplosionChance <= 0.0f) return null;
        // Exact seed from DamageArea.java:114
        Random rand = new Random(seed + coord.chunkZ() * 1400305337L + coord.chunkX() * 573259391L);
        if (rand.nextFloat() < profile.miniExplosionChance) {
            int rRange = Math.max(1, profile.miniExplosionMaxRadius - profile.miniExplosionMinRadius);
            int hRange = Math.max(1, profile.miniExplosionMaxHeight - profile.miniExplosionMinHeight);
            int radius = profile.miniExplosionMinRadius + rand.nextInt(rRange);
            int x = (coord.chunkX() << 4) + rand.nextInt(16);
            int y = cityLevelProvider.applyAsInt(coord) * 6 + profile.miniExplosionMinHeight + rand.nextInt(hRange);
            int z = (coord.chunkZ() << 4) + rand.nextInt(16);
            return new Explosion(radius, x, y, z);
        }
        return null;
    }

    public String damageBlock(String blockId, boolean notBreakable, boolean easyBreakable,
                              Random random, int y, float damage, String ironBarsOrNull, int waterLevel, String liquidBlock) {
        if (notBreakable) return blockId;
        if (easyBreakable) {
            damage *= EASY_BREAKABLE_MULTIPLIER; // 2.5f
        }
        if (random.nextFloat() <= damage) {
            if (damage < BLOCK_DAMAGE_CHANCE && ironBarsOrNull != null) {
                if (random.nextFloat() < BLOCK_DAMAGE_CHANCE) {
                    return ironBarsOrNull;
                }
                return y <= waterLevel ? liquidBlock : "minecraft:air";
            }
            return y <= waterLevel ? liquidBlock : "minecraft:air";
        }
        return blockId;
    }

    private static double squaredDistanceBoxPoint(double minX, double minY, double minZ,
                                                  double maxX, double maxY, double maxZ, Explosion e) {
        double dx = Math.max(0.0, Math.max(minX - e.centerX(), e.centerX() - maxX));
        double dy = Math.max(0.0, Math.max(minY - e.centerY(), e.centerY() - maxY));
        double dz = Math.max(0.0, Math.max(minZ - e.centerZ(), e.centerZ() - maxZ));
        return dx * dx + dy * dy + dz * dz;
    }

    private static double maxSquaredDistanceBoxPoint(double minX, double minY, double minZ,
                                                     double maxX, double maxY, double maxZ, Explosion e) {
        double dx = Math.max(Math.abs(e.centerX() - minX), Math.abs(e.centerX() - maxX));
        double dy = Math.max(Math.abs(e.centerY() - minY), Math.abs(e.centerY() - maxY));
        double dz = Math.max(Math.abs(e.centerZ() - minZ), Math.abs(e.centerZ() - maxZ));
        return dx * dx + dy * dy + dz * dz;
    }

    private static boolean intersectsBox(double minX, double minY, double minZ,
                                         double maxX, double maxY, double maxZ, Explosion e) {
        return squaredDistanceBoxPoint(minX, minY, minZ, maxX, maxY, maxZ, e) <= e.sqRadius();
    }

    public boolean hasExplosions() { return !explosions.isEmpty(); }
    public List<Explosion> getExplosions() { return explosions; }

    public boolean hasExplosions(int subChunkY) {
        double minX = chunkX << 4;
        double minY = subChunkY << 4;
        double minZ = chunkZ << 4;
        for (Explosion e : explosions) {
            if (intersectsBox(minX, minY, minZ, minX + 15.0, minY + 15.0, minZ + 15.0, e)) {
                return true;
            }
        }
        return false;
    }

    public boolean isCompletelyDestroyed(int subChunkY) {
        double minX = chunkX << 4;
        double minY = subChunkY * 16.0;
        double minZ = chunkZ << 4;
        for (Explosion e : explosions) {
            double dmax = maxSquaredDistanceBoxPoint(minX, minY, minZ, minX + 15.0, minY + 15.0, minZ + 15.0, e);
            if (dmax <= e.sqRadius()) {
                // Exact formula from DamageArea.java:153
                double dist = (e.radius() - 3.0 * e.radius()) / -3.0;
                dist *= dist;
                if (dmax <= dist) {
                    return true;
                }
            }
        }
        return false;
    }

    public float getDamageFactor() {
        float damage = 0.0f;
        for (Explosion e : explosions) {
            double sq = e.distSqToCenter(chunkX * 16.0, e.centerY(), chunkZ * 16.0);
            if (sq < e.sqRadius()) {
                double d = Math.sqrt(sq);
                damage += (float) (3.0f * (e.radius() - d) / e.radius());
            }
        }
        return damage;
    }

    public float getDamage(int x, int y, int z) {
        float damage = 0.0f;
        for (Explosion e : explosions) {
            double sq = e.distSqToCenter(x, y, z);
            if (sq < e.sqRadius()) {
                double d = Math.sqrt(sq);
                damage += (float) (3.0f * (e.radius() - d) / e.radius());
            }
        }
        return damage;
    }
}
