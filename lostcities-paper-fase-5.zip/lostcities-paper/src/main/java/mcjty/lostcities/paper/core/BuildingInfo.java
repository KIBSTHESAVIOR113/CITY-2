/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

import mcjty.lostcities.paper.assets.AssetModels;
import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.config.StreetGenerationMode;
import mcjty.lostcities.paper.core.highway.HighwayModels.HighwayInfo;
import mcjty.lostcities.paper.core.lost.BuildingPartSelector;
import mcjty.lostcities.paper.core.lost.City;
import mcjty.lostcities.paper.core.lost.CityStyleResolver;
import mcjty.lostcities.paper.core.lost.ConditionContext;
import mcjty.lostcities.paper.core.lost.DamageArea;
import mcjty.lostcities.paper.core.lost.MultiChunk;
import mcjty.lostcities.paper.core.lost.Orientation;
import mcjty.lostcities.paper.core.lost.RailChunkType;
import mcjty.lostcities.paper.core.lost.Railway;
import mcjty.lostcities.paper.core.lost.WorldStyleResolver;
import mcjty.lostcities.paper.core.plan.ChunkPlanner;
import mcjty.lostcities.paper.core.plan.Staged;
import mcjty.lostcities.paper.core.street.PlannedRoadType;
import mcjty.lostcities.paper.core.terrain.TerrainHeightField;
import mcjty.lostcities.paper.util.DeterministicRandom;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Function;

/**
 * Fase 5 port of {@code BuildingInfo} closing all pre-Fase-5 debt:
 * - {@code initMultiBuildingSection} + {@code calculateTopLeft} (L590-627)
 * - {@code checkBuildingPossibility} (L512-560)
 * - {@code getRelativePos} / {@code localToGlobal} / {@code globalToLocal} (L194-196, L1785-1791)
 * - {@code calculateStairDirection} / {@code getActualStairDirection} (L1434-1492)
 * - {@code getRandomDoor} (L1329-1340) & {@code getCompiledPalette} (L198-245)
 * - {@code MinMax}, {@code getDesiredMaxHeightL1/L2}, {@code updateMinMaxL1/L2} (Fase 3).
 */
public final class BuildingInfo {

    public static final int FLOOR_HEIGHT = 6;
    public static final int NO_CITY_HEIGHT_SENTINEL = 100000;
    public static final long LARGE_BRIDGE_SALT = 0x4c41524745425247L; // 5494763486426845767L
    private static final int MAX_CORRIDOR_WALK = 16;
    private static final int MAX_BRIDGE_WALK = 16;

    public enum Direction {
        XMIN(-1, 0),
        XMAX(1, 0),
        ZMIN(0, -1),
        ZMAX(0, 1);

        public final int dx;
        public final int dz;

        Direction(int dx, int dz) {
            this.dx = dx;
            this.dz = dz;
        }

        public Transform getRotation() {
            return switch (this) {
                case XMIN -> Transform.ROTATE_NONE;
                case XMAX -> Transform.ROTATE_180;
                case ZMIN -> Transform.ROTATE_90;
                case ZMAX -> Transform.ROTATE_270;
            };
        }
    }

    public record BlockPos3D(int x, int y, int z) {}

    public static final class MinMax {
        public int min;
        public int max;

        public MinMax(int min, int max) {
            this.min = min;
            this.max = max;
        }

        public MinMax copy() {
            return new MinMax(min, max);
        }
    }

    public record Characteristics(
            boolean isCity,
            boolean couldHaveBuilding,
            int cityLevel,
            String buildingId,
            String multiBuildingId,
            int multiRelX,
            int multiRelZ,
            int multiDimX,
            int multiDimZ,
            String cityStyleId,
            PlannedRoadType plannedRoadType
    ) {
        public boolean isSingle() { return multiDimX <= 1 && multiDimZ <= 1; }
        public boolean isMulti() { return !isSingle(); }
        public boolean isTopLeft() { return multiRelX == 0 && multiRelZ == 0; }
    }

    public final ChunkCoord coord;
    public final LostCityProfile profile;
    public final boolean isCity;
    public final boolean hasBuilding;
    public final int cityLevel;
    public final int groundLevel;
    public final int waterLevel;
    public final int floors;
    public final int cellars;
    public final String buildingId;
    public final String multiBuildingId;
    public final int multiRelX;
    public final int multiRelZ;
    public final int multiDimX;
    public final int multiDimZ;
    public final String cityStyleId;
    public final String outsideStyleId;
    public final String frontPartId;
    public final String largeBridgePartId;
    public final String doorBlock;
    public final boolean allowDoors;
    public final char fillerChar;
    public final Transform partTransform;
    public final List<String> allFloorParts;   // indexed by (f + cellars) for f in [-cellars..floors]
    public final List<String> allFloorParts2;  // indexed by (f + cellars) for f in [-cellars..floors]
    public final List<String> floorParts;
    public final List<String> floorParts2;
    public final List<String> cellarParts;
    public final String roofPart;
    public final float ruinHeight;
    public final boolean hasLoot;
    public final boolean waterBiome;
    public final PlannedRoadType plannedRoadType;
    public final int highwayXLevel;
    public final int highwayZLevel;
    public final Railway.RailChunkInfo railInfo;
    public final boolean xRailCorridor;
    public final boolean zRailCorridor;
    public final boolean xBridge;
    public final boolean zBridge;
    public final float stairPriority;
    public final DamageArea damageArea;
    private final long paletteSeed;

    private volatile MinMax desiredMaxHeight1;
    private volatile MinMax desiredMaxHeight2;
    private volatile CompiledPalette compiledPalette;
    private volatile boolean stairsCalculated;
    private volatile Direction stairDirection;
    private volatile boolean actualStairsCalculated;
    private volatile Direction actualStairDirection;
    private final List<BlockPos3D> torchTodo = new CopyOnWriteArrayList<>();

    private BuildingInfo(
            ChunkCoord coord, LostCityProfile profile, boolean isCity, boolean hasBuilding,
            int cityLevel, int groundLevel, int waterLevel, int floors, int cellars,
            String buildingId, String multiBuildingId, int multiRelX, int multiRelZ, int multiDimX, int multiDimZ,
            String cityStyleId, String outsideStyleId, String frontPartId,
            String largeBridgePartId, String doorBlock, boolean allowDoors, char fillerChar,
            Transform partTransform, List<String> allFloorParts, List<String> allFloorParts2,
            List<String> floorParts, List<String> floorParts2, List<String> cellarParts,
            String roofPart, float ruinHeight, boolean hasLoot, boolean waterBiome,
            PlannedRoadType plannedRoadType, int highwayXLevel, int highwayZLevel,
            Railway.RailChunkInfo railInfo, boolean xRailCorridor, boolean zRailCorridor,
            boolean xBridge, boolean zBridge, float stairPriority, DamageArea damageArea, long paletteSeed
    ) {
        this.coord = coord;
        this.profile = profile;
        this.isCity = isCity;
        this.hasBuilding = hasBuilding;
        this.cityLevel = cityLevel;
        this.groundLevel = groundLevel;
        this.waterLevel = waterLevel;
        this.floors = floors;
        this.cellars = cellars;
        this.buildingId = buildingId;
        this.multiBuildingId = multiBuildingId;
        this.multiRelX = multiRelX;
        this.multiRelZ = multiRelZ;
        this.multiDimX = multiDimX;
        this.multiDimZ = multiDimZ;
        this.cityStyleId = cityStyleId;
        this.outsideStyleId = outsideStyleId;
        this.frontPartId = frontPartId;
        this.largeBridgePartId = largeBridgePartId;
        this.doorBlock = doorBlock;
        this.allowDoors = allowDoors;
        this.fillerChar = fillerChar;
        this.partTransform = partTransform;
        this.allFloorParts = List.copyOf(allFloorParts);
        this.allFloorParts2 = List.copyOf(allFloorParts2);
        this.floorParts = List.copyOf(floorParts);
        this.floorParts2 = List.copyOf(floorParts2);
        this.cellarParts = List.copyOf(cellarParts);
        this.roofPart = roofPart;
        this.ruinHeight = ruinHeight;
        this.hasLoot = hasLoot;
        this.waterBiome = waterBiome;
        this.plannedRoadType = plannedRoadType;
        this.highwayXLevel = highwayXLevel;
        this.highwayZLevel = highwayZLevel;
        this.railInfo = railInfo;
        this.xRailCorridor = xRailCorridor;
        this.zRailCorridor = zRailCorridor;
        this.xBridge = xBridge;
        this.zBridge = zBridge;
        this.stairPriority = stairPriority;
        this.damageArea = damageArea;
        this.paletteSeed = paletteSeed;
    }

    public int getCityGroundLevel() { return groundLevel + cityLevel * FLOOR_HEIGHT; }
    public int getBuildingBottomHeight() { return getCityGroundLevel() - cellars * FLOOR_HEIGHT; }

    /** Port of {@code BuildingInfo.getCityGroundLevelOutsideLower} (source L303-309). */
    public int getCityGroundLevelOutsideLower() {
        return isCity ? (groundLevel + cityLevel * FLOOR_HEIGHT) : (groundLevel + cityLevel * FLOOR_HEIGHT - 1);
    }

    public int getMaxHeight() { return getCityGroundLevel() + (floors + 1) * FLOOR_HEIGHT; }

    /** Port of {@code BuildingInfo.getRelativePos} (source L194-196). */
    public BlockPos3D getRelativePos(int rx, int y, int rz) {
        return new BlockPos3D((coord.chunkX() << 4) + rx, y, (coord.chunkZ() << 4) + rz);
    }

    /** Port of {@code BuildingInfo.localToGlobal} / {@code globalToLocal} (source L1785-1791). */
    public int localToGlobal(int l) { return l + cityLevel; }
    public int globalToLocal(int l) { return l - cityLevel; }

    public boolean isMultiBuilding() { return multiDimX > 1 || multiDimZ > 1; }
    public boolean isMultiTopLeft() { return multiRelX == 0 && multiRelZ == 0; }

    /** Port of {@code BuildingInfo.calculateTopLeft} (source L621-627). */
    public BuildingInfo calculateTopLeft(Function<ChunkCoord, BuildingInfo> lookup) {
        if (isMultiTopLeft() || !isMultiBuilding()) return this;
        ChunkCoord key = new ChunkCoord(coord.dimensionId(), coord.chunkX() - multiRelX, coord.chunkZ() - multiRelZ);
        return lookup.apply(key);
    }

    /**
     * Port of {@code BuildingInfo.getFloor(int f)} / {@code getFloorPart2(int f)} where {@code f}
     * ranges from {@code -cellars} to {@code floors} (0 = ground floor, {@code floors} = roof).
     */
    public String getFloorByLevel(int f) {
        int idx = f + cellars;
        return (idx >= 0 && idx < allFloorParts.size()) ? allFloorParts.get(idx) : null;
    }

    public String getFloorPart2ByLevel(int f) {
        int idx = f + cellars;
        return (idx >= 0 && idx < allFloorParts2.size()) ? allFloorParts2.get(idx) : null;
    }

    public String getFloor(int index) { return (index >= 0 && index < floorParts.size()) ? floorParts.get(index) : null; }
    public String getFloorPart2(int index) { return (index >= 0 && index < floorParts2.size()) ? floorParts2.get(index) : null; }
    public String getCityStyleId() { return cityStyleId; }
    public String getOutsideStyleId() { return outsideStyleId; }
    public int getHighwayXLevel() { return highwayXLevel; }
    public int getHighwayZLevel() { return highwayZLevel; }
    public Railway.RailChunkInfo getRailInfo() { return railInfo; }
    public PlannedRoadType getEffectivePlannedRoadType() { return plannedRoadType; }
    public DamageArea getDamageArea() { return damageArea; }
    public boolean isWaterBiome() { return waterBiome; }

    public void addTorchTodo(BlockPos3D pos) { torchTodo.add(pos); }
    public List<BlockPos3D> getTorchTodo() { return List.copyOf(torchTodo); }
    public void clearTorchTodo() { torchTodo.clear(); }

    /**
     * Port of {@code BuildingInfo.getCompiledPalette} (source L198-245):
     * multi-building chunks share the top-left chunk's compiled palette so walls/materials align.
     */
    public CompiledPalette getCompiledPalette(AssetRegistry registry, Function<ChunkCoord, BuildingInfo> lookup) {
        CompiledPalette result = this.compiledPalette;
        if (result != null) return result;
        synchronized (this) {
            result = this.compiledPalette;
            if (result != null) return result;
            if (isMultiBuilding() && !isMultiTopLeft() && lookup != null) {
                BuildingInfo tl = calculateTopLeft(lookup);
                if (tl != this) {
                    result = tl.getCompiledPalette(registry, lookup);
                    this.compiledPalette = result;
                    return result;
                }
            }
            String styleId = isCity ? CityStyleResolver.resolveStyleId(registry, cityStyleId) : outsideStyleId;
            AssetModels.CityStyleAsset cs = isCity ? registry.getCityStyle(cityStyleId) : null;
            AssetModels.BuildingAsset ba = hasBuilding ? registry.getBuilding(buildingId) : null;
            result = CompiledPalette.buildForBuilding(registry, styleId, cs, ba, new Random(paletteSeed));
            this.compiledPalette = result;
            return result;
        }
    }

    /** Port of {@code BuildingInfo.getRandomDoor} (source L1329-1340). */
    public static String getRandomDoor(Random rand) {
        return switch (rand.nextInt(7)) {
            case 0 -> "minecraft:birch_door";
            case 1 -> "minecraft:acacia_door";
            case 2 -> "minecraft:dark_oak_door";
            case 3 -> "minecraft:spruce_door";
            case 4 -> "minecraft:oak_door";
            case 5 -> "minecraft:jungle_door";
            case 6 -> "minecraft:iron_door";
            default -> "minecraft:oak_door";
        };
    }

    /** Port of {@code BuildingInfo.calculateStairDirection} (source L1440-1462). */
    public Direction getStairDirection(Function<ChunkCoord, BuildingInfo> lookup) {
        if (stairsCalculated) return stairDirection;
        synchronized (this) {
            if (stairsCalculated) return stairDirection;
            stairsCalculated = true;
            if (!hasBuilding && isCity) {
                BuildingInfo xmin = lookup.apply(coord.west());
                BuildingInfo xmax = lookup.apply(coord.east());
                BuildingInfo zmin = lookup.apply(coord.north());
                BuildingInfo zmax = lookup.apply(coord.south());
                if (cityLevel == xmin.cityLevel - 1 && !xmin.hasBuilding && xmin.isCity) {
                    stairDirection = Direction.XMIN;
                } else if (cityLevel == xmax.cityLevel - 1 && !xmax.hasBuilding && xmax.isCity) {
                    stairDirection = Direction.XMAX;
                } else if (cityLevel == zmin.cityLevel - 1 && !zmin.hasBuilding && zmin.isCity) {
                    stairDirection = Direction.ZMIN;
                } else if (cityLevel == zmax.cityLevel - 1 && !zmax.hasBuilding && zmax.isCity) {
                    stairDirection = Direction.ZMAX;
                } else {
                    stairDirection = null;
                }
            } else {
                stairDirection = null;
            }
            return stairDirection;
        }
    }

    /** Port of {@code BuildingInfo.getActualStairDirection} (source L1466-1492). */
    public Direction getActualStairDirection(Function<ChunkCoord, BuildingInfo> lookup) {
        if (actualStairsCalculated) return actualStairDirection;
        synchronized (this) {
            if (actualStairsCalculated) return actualStairDirection;
            actualStairsCalculated = true;
            Direction dir = getStairDirection(lookup);
            if (dir != null) {
                for (int cx = -1; cx <= 1; cx++) {
                    for (int cz = -1; cz <= 1; cz++) {
                        if (cx == 0 && cz == 0) continue;
                        ChunkCoord key = new ChunkCoord(coord.dimensionId(), coord.chunkX() + cx, coord.chunkZ() + cz);
                        BuildingInfo adj = lookup.apply(key);
                        if (adj.getStairDirection(lookup) != null && adj.stairPriority > stairPriority) {
                            dir = null;
                            break;
                        }
                    }
                    if (dir == null) break;
                }
            }
            actualStairDirection = dir;
            return actualStairDirection;
        }
    }

    public int getCityHeightForChunk() {
        if (isCity) return getCityGroundLevel();
        return waterBiome ? (groundLevel - profile.oceanCorrectionBorder) : NO_CITY_HEIGHT_SENTINEL;
    }

    public static int getLowestCityHeightAtChunkCorner(BuildingInfo info11, BuildingInfo info01, BuildingInfo info10, BuildingInfo info00) {
        if (info11.isCity && info10.isCity && info00.isCity && info01.isCity) return NO_CITY_HEIGHT_SENTINEL;
        if (!info11.isCity && !info10.isCity && !info00.isCity && !info01.isCity) return NO_CITY_HEIGHT_SENTINEL;
        int h = info11.getCityHeightForChunk();
        h = Math.min(h, info01.getCityHeightForChunk());
        h = Math.min(h, info10.getCityHeightForChunk());
        h = Math.min(h, info00.getCityHeightForChunk());
        return h;
    }

    public int getLowestCityHeightAtChunkCorner(Function<ChunkCoord, BuildingInfo> lookup) {
        BuildingInfo info00 = lookup.apply(coord.northWest());
        BuildingInfo info01 = lookup.apply(coord.west());
        BuildingInfo info10 = lookup.apply(coord.north());
        return getLowestCityHeightAtChunkCorner(this, info01, info10, info00);
    }

    public MinMax getDesiredMaxHeightL1(Function<ChunkCoord, BuildingInfo> lookup) {
        MinMax cached = this.desiredMaxHeight1;
        if (cached != null) return cached;

        int h = getLowestCityHeightAtChunkCorner(lookup);
        int cx = coord.chunkX();
        int cz = coord.chunkZ();
        MinMax result;
        if (h < 256) {
            result = new MinMax(
                    h + LostCityTerrainFeature.getRandomizedOffset(cx, cz, profile.terrainFixLowerMinOffset, profile.terrainFixLowerMaxOffset),
                    h + LostCityTerrainFeature.getRandomizedOffset(cx, cz, profile.terrainFixUpperMinOffset, profile.terrainFixUpperMaxOffset)
            );
        } else {
            result = new MinMax(NO_CITY_HEIGHT_SENTINEL, NO_CITY_HEIGHT_SENTINEL);
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (dx == 0 && dz == 0) continue;
                    ChunkCoord nc = new ChunkCoord(coord.dimensionId(), cx + dx, cz + dz);
                    int offs = ((dx != 0 && dz != 0) ? 25 : 20) + LostCityTerrainFeature.getHeightOffsetL1(cx + dx, cz + dz);
                    lookup.apply(nc).updateMinMaxL1(result, offs, lookup);
                }
            }
        }
        this.desiredMaxHeight1 = result;
        return result;
    }

    private void updateMinMaxL1(MinMax minMax, int offs, Function<ChunkCoord, BuildingInfo> lookup) {
        int h = getLowestCityHeightAtChunkCorner(lookup);
        if ((h - offs) < minMax.min) minMax.min = h - offs;
        if ((h + offs) < minMax.max) minMax.max = h + offs;
    }

    public MinMax getDesiredMaxHeightL2(Function<ChunkCoord, BuildingInfo> lookup) {
        MinMax cached = this.desiredMaxHeight2;
        if (cached != null) return cached;

        MinMax l1 = getDesiredMaxHeightL1(lookup);
        MinMax result;
        if (l1.min < 256) {
            result = l1.copy();
        } else {
            result = new MinMax(NO_CITY_HEIGHT_SENTINEL, NO_CITY_HEIGHT_SENTINEL);
            int cx = coord.chunkX();
            int cz = coord.chunkZ();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (dx == 0 && dz == 0) continue;
                    ChunkCoord nc = new ChunkCoord(coord.dimensionId(), cx + dx, cz + dz);
                    int offs = ((dx != 0 && dz != 0) ? 25 : 20) + LostCityTerrainFeature.getHeightOffsetL2(cx + dx, cz + dz);
                    lookup.apply(nc).updateMinMaxL2(result, offs, lookup);
                }
            }
        }
        this.desiredMaxHeight2 = result;
        return result;
    }

    private void updateMinMaxL2(MinMax minMax, int offs, Function<ChunkCoord, BuildingInfo> lookup) {
        MinMax h = getDesiredMaxHeightL1(lookup);
        if ((h.min - offs) < minMax.min) minMax.min = h.min - offs;
        if ((h.max + offs) < minMax.max) minMax.max = h.max + offs;
    }

    public boolean isTunnel(int level, int terrainHeight) {
        if (isCity) return cityLevel > level;
        int highwayHeight = groundLevel + level * FLOOR_HEIGHT + 3;
        return terrainHeight > highwayHeight;
    }

    public boolean canRailGoThrough() { return !hasBuilding || cellars == 0; }

    public boolean isSuitableForBridge(BuildingInfo other) {
        return other.cityLevel < this.cityLevel || other.waterBiome;
    }

    public boolean hasXCorridor(Function<ChunkCoord, BuildingInfo> lookup) {
        if (!xRailCorridor) return false;
        BuildingInfo cur = lookup.apply(coord.west());
        int steps = 0;
        while (steps < MAX_CORRIDOR_WALK && cur.canRailGoThrough() && cur.xRailCorridor) {
            cur = lookup.apply(cur.coord.west());
            steps++;
        }
        if (!cur.hasBuilding || cur.cellars == 0) return false;
        cur = lookup.apply(coord.east());
        steps = 0;
        while (steps < MAX_CORRIDOR_WALK && cur.canRailGoThrough() && cur.xRailCorridor) {
            cur = lookup.apply(cur.coord.east());
            steps++;
        }
        return cur.hasBuilding && cur.cellars > 0;
    }

    public boolean hasZCorridor(Function<ChunkCoord, BuildingInfo> lookup) {
        if (!zRailCorridor) return false;
        BuildingInfo cur = lookup.apply(coord.north());
        int steps = 0;
        while (steps < MAX_CORRIDOR_WALK && cur.canRailGoThrough() && cur.zRailCorridor) {
            cur = lookup.apply(cur.coord.north());
            steps++;
        }
        if (!cur.hasBuilding || cur.cellars == 0) return false;
        cur = lookup.apply(coord.south());
        steps = 0;
        while (steps < MAX_CORRIDOR_WALK && cur.canRailGoThrough() && cur.zRailCorridor) {
            cur = lookup.apply(cur.coord.south());
            steps++;
        }
        return cur.hasBuilding && cur.cellars > 0;
    }

    public boolean hasXBridge(Function<ChunkCoord, BuildingInfo> lookup) {
        if (!xBridge || isCity || !waterBiome) return false;
        BuildingInfo i = lookup.apply(coord.west());
        int steps = 0;
        while (steps < MAX_BRIDGE_WALK && !i.isCity && i.xBridge && isSuitableForBridge(i)) {
            i = lookup.apply(i.coord.west());
            steps++;
        }
        if (!i.isCity || i.hasBuilding || i.cityLevel > 0) return false;
        i = lookup.apply(coord.east());
        steps = 0;
        while (steps < MAX_BRIDGE_WALK && !i.isCity && i.xBridge && isSuitableForBridge(i)) {
            i = lookup.apply(i.coord.east());
            steps++;
        }
        return i.isCity && !i.hasBuilding && i.cityLevel <= 0;
    }

    public boolean hasZBridge(Function<ChunkCoord, BuildingInfo> lookup) {
        if (!zBridge || isCity || !waterBiome || hasXBridge(lookup)) return false;
        BuildingInfo i = lookup.apply(coord.north());
        int steps = 0;
        while (steps < MAX_BRIDGE_WALK && !i.isCity && i.zBridge && isSuitableForBridge(i)) {
            if (i.hasXBridge(lookup)) return false;
            i = lookup.apply(i.coord.north());
            steps++;
        }
        if (!i.isCity || i.hasBuilding || i.cityLevel > 0) return false;
        i = lookup.apply(coord.south());
        steps = 0;
        while (steps < MAX_BRIDGE_WALK && !i.isCity && i.zBridge && isSuitableForBridge(i)) {
            if (i.hasXBridge(lookup)) return false;
            i = lookup.apply(i.coord.south());
            steps++;
        }
        return i.isCity && !i.hasBuilding && i.cityLevel <= 0;
    }

    public boolean hasConnectionAt(int level, Orientation orientation) {
        return orientation == Orientation.X ? hasConnectionAtX(level) : hasConnectionAtZ(level);
    }

    public boolean hasConnectionAtX(int level) {
        return hasBuilding && level >= 0 && level < (floors + cellars) && (level == cellars || xRailCorridor);
    }

    public boolean hasConnectionAtZ(int level) {
        return hasBuilding && level >= 0 && level < (floors + cellars) && (level == cellars || zRailCorridor);
    }

    public static int getLevelBasedOnHeight(int height, LostCityProfile profile) {
        if (height < profile.cityLevel0Height) return 0;
        if (height < profile.cityLevel1Height) return 1;
        if (height < profile.cityLevel2Height) return 2;
        if (height < profile.cityLevel3Height) return 3;
        if (height < profile.cityLevel4Height) return 4;
        if (height < profile.cityLevel5Height) return 5;
        if (height < profile.cityLevel6Height) return 6;
        if (height < profile.cityLevel7Height) return 7;
        return 7;
    }

    public static int computeCityLevel(ChunkCoord coord, long seed, LostCityProfile profile, int terrainHeight) {
        if (profile.isSpace() || profile.isVoidSpheres()) {
            Random rand = new Random(seed + coord.chunkZ() * 817505771L + coord.chunkX() * 217645177L);
            return rand.nextInt(3);
        }
        return getLevelBasedOnHeight(terrainHeight, profile);
    }

    /** Port of {@code BuildingInfo.checkBuildingPossibility} (source L512-560). */
    public static boolean checkBuildingPossibility(
            boolean isMulti,
            PlannedRoadType plannedRoadType,
            float buildingChance,
            int cityLevel,
            HighwayInfo highwayInfo,
            Railway.RailChunkInfo railInfo,
            Random rand
    ) {
        float bc = rand.nextFloat();
        if (isMulti) return true;
        if (plannedRoadType != null && plannedRoadType != PlannedRoadType.NONE) return false;
        if (bc >= buildingChance) return false;
        if (highwayInfo != null && (highwayInfo.xLevel() >= 0 || highwayInfo.zLevel() >= 0)) {
            int maxh = Math.max(highwayInfo.xLevel(), highwayInfo.zLevel());
            return cityLevel > maxh + 1;
        }
        if (railInfo != null && railInfo.type() != RailChunkType.NONE) {
            if (railInfo.type() == RailChunkType.STATION_UNDERGROUND) return false;
            return cityLevel >= railInfo.level() + 2;
        }
        return true;
    }

    /** Port of {@code BuildingInfo.initMultiBuildingSection} (source L590-619). */
    public static Characteristics computeCharacteristics(
            ChunkCoord coord, long worldSeed, LostCityProfile profile, AssetRegistry registry,
            City city, TerrainHeightField heightField, MultiChunk.Cache multiChunkCache,
            HighwayInfo highwayInfo, Railway.RailChunkInfo railInfo
    ) {
        TerrainHeightField.Sample sample = heightField.sample((coord.chunkX() << 4) + 8, (coord.chunkZ() << 4) + 8);
        String biomeId = sample.biomeId();
        int terrainHeight = sample.height();
        double mult = WorldStyleResolver.getCityChanceMultiplier(registry, profile.getWorldStyle(), biomeId);
        float cityFactor = city.getCityFactor(coord, c -> mult);
        boolean isCity = cityFactor >= profile.cityThreshold
                && terrainHeight >= profile.cityMinHeight
                && terrainHeight <= profile.cityMaxHeight;
        int cityLevel = computeCityLevel(coord, worldSeed, profile, terrainHeight);

        String cityStyleId = city.getCityStyleId(coord,
                (c, r) -> WorldStyleResolver.selectRandomCityStyle(registry, profile.getWorldStyle(), biomeId, r));

        String multiBuildingId = "";
        int multiRelX = 0, multiRelZ = 0, multiDimX = 1, multiDimZ = 1;
        String chosenBuilding = "";

        if (isCity && multiChunkCache != null && registry != null) {
            MultiChunk mc = multiChunkCache.getOrCreate(
                    coord, MultiChunk.Settings.DEFAULT, registry,
                    c -> city.getCityStyleId(c, (cc, rr) -> WorldStyleResolver.selectRandomCityStyle(
                            registry, profile.getWorldStyle(), heightField.sampleChunkCenterBiome(cc), rr)),
                    style -> CityStyleResolver.listAllowedMultiBuildings(registry, style),
                    c -> computeCityLevel(c, worldSeed, profile, heightField.sampleChunkCenterHeight(c)),
                    c -> {
                        int h = heightField.sampleChunkCenterHeight(c);
                        return h >= profile.cityMinHeight && h <= profile.cityMaxHeight && city.isCityChunk(c, k -> 1.0);
                    }
            );
            MultiChunk.MB mb = mc.getMultiBuilding(coord);
            if (mb != null) {
                AssetModels.MultiBuildingAsset mba = registry.getMultiBuilding(mb.name());
                if (mba != null && mb.offsetX() < mba.dimX() && mb.offsetZ() < mba.dimZ()) {
                    multiBuildingId = mb.name();
                    multiRelX = mb.offsetX();
                    multiRelZ = mb.offsetZ();
                    multiDimX = mba.dimX();
                    multiDimZ = mba.dimZ();
                    if (multiRelZ < mba.buildings().size() && multiRelX < mba.buildings().get(multiRelZ).size()) {
                        chosenBuilding = mba.buildings().get(multiRelZ).get(multiRelX);
                    }
                }
            }
        }

        Random rand = DeterministicRandom.buildingRandom(coord.chunkX(), coord.chunkZ(), worldSeed);
        if (chosenBuilding.isEmpty()) {
            chosenBuilding = CityStyleResolver.selectRandomBuilding(registry, cityStyleId, rand);
        }
        boolean isMulti = multiDimX > 1 || multiDimZ > 1;
        boolean couldHaveBuilding = isCity && checkBuildingPossibility(
                isMulti, PlannedRoadType.NONE, profile.buildingChance, cityLevel, highwayInfo, railInfo, rand);

        return new Characteristics(
                isCity, couldHaveBuilding, cityLevel, chosenBuilding,
                multiBuildingId, multiRelX, multiRelZ, multiDimX, multiDimZ,
                cityStyleId, PlannedRoadType.NONE
        );
    }

    public static BuildingInfo get(
            ChunkCoord coord, long worldSeed, LostCityProfile profile, AssetRegistry registry,
            ChunkPlanner planner, City city, TerrainHeightField heightField,
            HighwayInfo highwayInfo, Railway.RailChunkInfo railInfo
    ) {
        return get(coord, worldSeed, profile, registry, planner, city, heightField, null, highwayInfo, railInfo);
    }

    public static BuildingInfo get(
            ChunkCoord coord, long worldSeed, LostCityProfile profile, AssetRegistry registry,
            ChunkPlanner planner, City city, TerrainHeightField heightField, MultiChunk.Cache multiChunkCache,
            HighwayInfo highwayInfo, Railway.RailChunkInfo railInfo
    ) {
        return planner.buildingInfo(coord, () -> compute(
                coord, worldSeed, profile, registry, planner, city, heightField, multiChunkCache, highwayInfo, railInfo));
    }

    private static Staged<BuildingInfo> compute(
            ChunkCoord coord, long worldSeed, LostCityProfile profile, AssetRegistry registry,
            ChunkPlanner planner, City city, TerrainHeightField heightField, MultiChunk.Cache multiChunkCache,
            HighwayInfo highwayInfo, Railway.RailChunkInfo railInfo
    ) {
        TerrainHeightField.Sample sample = heightField.sample((coord.chunkX() << 4) + 8, (coord.chunkZ() << 4) + 8);
        String biomeId = sample.biomeId();
        Characteristics ch = planner.characteristics(coord, () -> new Staged<>(computeCharacteristics(
                coord, worldSeed, profile, registry, city, heightField, multiChunkCache, highwayInfo, railInfo), true));

        // RNG Step 1 (BuildingInfo.java:801)
        Random rand = DeterministicRandom.buildingRandom(coord.chunkX(), coord.chunkZ(), worldSeed);

        // RNG Step 2 (BuildingInfo.java:805-813): prefersLonely west -> east -> north -> south
        boolean hasBuilding = ch.couldHaveBuilding();
        if (hasBuilding && ch.isSingle()) {
            ChunkCoord[] neighbors = new ChunkCoord[]{coord.west(), coord.east(), coord.north(), coord.south()};
            for (ChunkCoord n : neighbors) {
                Characteristics nCh = planner.characteristics(n, () -> new Staged<>(computeCharacteristics(
                        n, worldSeed, profile, registry, city, heightField, multiChunkCache, HighwayInfo.NONE, Railway.RailChunkInfo.NOTHING), true));
                AssetModels.BuildingAsset nb = registry.getBuilding(nCh.buildingId());
                float lonely = nb == null ? 0.0f : nb.prefersLonely();
                if (rand.nextFloat() < lonely) {
                    hasBuilding = false;
                    break;
                }
            }
        }

        // RNG Step 3 (BuildingInfo.java:930-980): floors, cellars & doorBlock
        AssetModels.BuildingAsset buildingAsset = registry.getBuilding(ch.buildingId());
        int minF = buildingAsset != null && buildingAsset.minFloors() >= 0 ? buildingAsset.minFloors() : profile.buildingMinFloors;
        int maxF = buildingAsset != null && buildingAsset.maxFloors() >= 0 ? buildingAsset.maxFloors() : profile.buildingMaxFloors;
        maxF = Math.max(minF, maxF);
        int floors = minF + rand.nextInt(Math.max(1, maxF - minF + 1));

        int minC = buildingAsset != null && buildingAsset.minCellars() >= 0 ? buildingAsset.minCellars() : profile.buildingMinCellars;
        int maxC = buildingAsset != null && buildingAsset.maxCellars() >= 0 ? buildingAsset.maxCellars() : profile.buildingMaxCellars;
        maxC = Math.max(minC, maxC);
        int cellars = minC + rand.nextInt(Math.max(1, maxC - minC + 1));

        String doorBlock = getRandomDoor(rand);
        boolean allowDoors = buildingAsset == null || buildingAsset.allowDoors();
        char fillerChar = (buildingAsset != null && buildingAsset.filler() != null && !buildingAsset.filler().isEmpty())
                ? buildingAsset.filler().charAt(0) : '#';

        // RNG Step 4: LargeBridge RNG with 0x4c41524745425247L
        String largeBridgePartId = "";
        if (profile.streetGenerationMode == StreetGenerationMode.HIERARCHICAL_GRID_V1) {
            Random bridgeRandom = new DeterministicRandom.QualityRandom(worldSeed ^ LARGE_BRIDGE_SALT
                    ^ (long) coord.chunkX() * 341873128712L ^ (long) coord.chunkZ() * 132897987541L);
            if (bridgeRandom.nextFloat() < profile.plannedPrimaryBridgeChance) {
                largeBridgePartId = "lostcities:bridge_large_open";
            }
        }

        // RNG Step 5 (BuildingInfo.java:1076-1090, C2): CityStyle corridorChance with profile fallback
        float corridorChance = CityStyleResolver.resolveCorridorChance(registry, ch.cityStyleId(), profile.corridorChance);
        boolean xRailCorridor = !(hasBuilding && cellars > 0) && (rand.nextFloat() < corridorChance);
        boolean zRailCorridor = !(hasBuilding && cellars > 0) && (rand.nextFloat() < corridorChance);
        boolean xBridge = !ch.isCity() && (rand.nextFloat() < profile.bridgeChance);
        boolean zBridge = !ch.isCity() && (rand.nextFloat() < profile.bridgeChance);

        // RNG Step 6: stairPriority & parts/parts2 selection (source uses Transform.ROTATE_NONE for buildings!)
        float stairPriority = rand.nextFloat();
        List<String> allFloorParts = new ArrayList<>();
        List<String> allFloorParts2 = new ArrayList<>();
        List<String> floorParts = new ArrayList<>();
        List<String> floorParts2 = new ArrayList<>();
        List<String> cellarParts = new ArrayList<>();
        String roofPart = "";
        if (hasBuilding && buildingAsset != null) {
            String belowPart = "";
            for (int f = -cellars; f <= floors; f++) {
                ConditionContext ctx1 = new ConditionContext(
                        ch.cityLevel() + f, f, cellars, floors, "", belowPart,
                        buildingAsset.id(), coord, true, profile.isSpheres() || profile.isSpace(), biomeId);
                String selected = BuildingPartSelector.selectPrimaryPart(buildingAsset, rand, ctx1);
                String resolved = selected == null ? "" : selected;
                ConditionContext ctx2 = new ConditionContext(
                        ch.cityLevel() + f, f, cellars, floors, resolved, belowPart,
                        buildingAsset.id(), coord, true, profile.isSpheres() || profile.isSpace(), biomeId);
                String overlay = BuildingPartSelector.selectOverlayPart2(buildingAsset, rand, ctx2);
                String resolved2 = overlay == null ? "" : overlay;
                allFloorParts.add(resolved);
                allFloorParts2.add(resolved2);
                if (f < 0) cellarParts.add(resolved);
                else if (f == floors) roofPart = resolved;
                else {
                    floorParts.add(resolved);
                    floorParts2.add(resolved2);
                }
                belowPart = resolved;
            }
        }

        String frontPart = (hasBuilding && rand.nextFloat() < profile.buildingFrontChance)
                ? CityStyleResolver.selectRandomFront(registry, ch.cityStyleId(), rand) : "";
        if (frontPart == null) frontPart = "";

        float ruinHeight = -1.0f;
        if (profile.ruinChance > 0.0f && rand.nextFloat() < profile.ruinChance) {
            ruinHeight = profile.ruinMinlevelPercent
                    + rand.nextFloat() * Math.max(0.0f, profile.ruinMaxlevelPercent - profile.ruinMinlevelPercent);
        }
        boolean hasLoot = profile.generateLoot && rand.nextFloat() >= profile.buildingWithoutLootChance;
        String outsideStyleId = WorldStyleResolver.getOutsideStyle(registry, profile.getWorldStyle());
        DamageArea damageArea = new DamageArea(
                worldSeed, coord.dimensionId(), coord.chunkX(), coord.chunkZ(), profile,
                c -> city.isCityChunk(c, k -> 1.0),
                c -> computeCityLevel(c, worldSeed, profile, heightField.sampleChunkCenterHeight(c)),
                null
        );
        long paletteSeed = rand.nextLong();

        return new Staged<>(new BuildingInfo(
                coord, profile, ch.isCity(), hasBuilding, ch.cityLevel(),
                profile.groundLevel, heightField.seaLevel(), floors, cellars,
                ch.buildingId(), ch.multiBuildingId(), ch.multiRelX(), ch.multiRelZ(), ch.multiDimX(), ch.multiDimZ(),
                ch.cityStyleId(), outsideStyleId, frontPart, largeBridgePartId,
                doorBlock, allowDoors, fillerChar, Transform.ROTATE_NONE,
                allFloorParts, allFloorParts2, floorParts, floorParts2, cellarParts, roofPart,
                ruinHeight, hasLoot, sample.waterBiome(), ch.plannedRoadType(),
                highwayInfo == null ? -1 : highwayInfo.xLevel(),
                highwayInfo == null ? -1 : highwayInfo.zLevel(),
                railInfo == null ? Railway.RailChunkInfo.NOTHING : railInfo,
                xRailCorridor, zRailCorridor, xBridge, zBridge, stairPriority, damageArea, paletteSeed
        ), true);
    }
}
