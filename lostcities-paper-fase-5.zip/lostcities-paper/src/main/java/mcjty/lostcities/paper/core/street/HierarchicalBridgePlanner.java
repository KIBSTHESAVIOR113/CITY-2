/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.street;

import mcjty.lostcities.paper.config.LostCityProfile;

/**
 * Evaluates whether a planned primary road spans a water/valley gap requiring a bridge.
 */
public final class HierarchicalBridgePlanner {

    private final LostCityProfile profile;

    public HierarchicalBridgePlanner(LostCityProfile profile) {
        this.profile = profile;
    }

    public boolean shouldBuildBridge(PlannedStreetInfo street, int terrainHeight, int cityGroundLevel) {
        if (!street.isRoad()) {
            return false;
        }
        return terrainHeight < cityGroundLevel - 3 && profile.plannedPrimaryBridgeChance > 0.0f;
    }
}
