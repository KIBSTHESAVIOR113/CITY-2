/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.loot;

import mcjty.lostcities.paper.LostCitiesPlugin;
import mcjty.lostcities.paper.core.BuildingInfo;
import mcjty.lostcities.paper.util.DeterministicRandom;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.LootGenerateEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.loot.LootTable;

import java.util.Locale;
import java.util.Random;
import java.util.UUID;

/**
 * Main-thread bridge for binding LostCities chest loot tables and mob spawners via
 * {@link mcjty.lostcities.paper.core.GlobalTodo} with safe fallback when datapack
 * loot tables are unavailable (Risk R-22).
 */
public final class LootBridge implements Listener {

    private final LostCitiesPlugin plugin;

    public LootBridge(LostCitiesPlugin plugin) {
        this.plugin = plugin;
    }

    public void scheduleChestLoot(UUID worldId, int x, int y, int z, String conditionName, BuildingInfo info) {
        plugin.getGlobalTodo().enqueue(worldId, x >> 4, z >> 4, world -> {
            if (y < world.getMinHeight() || y >= world.getMaxHeight()) return;
            Block block = world.getBlockAt(x, y, z);
            BlockState state = block.getState();
            if (!(state instanceof Chest chest)) return;

            Random rand = DeterministicRandom.buildingRandom(x, z, world.getSeed() ^ y);
            if (rand.nextFloat() < info.profile.chestWithoutLootChance) return;

            int floorOffset = (y - info.getCityGroundLevel()) / BuildingInfo.FLOOR_HEIGHT;
            String tableId = ConditionEvaluator.evaluate(plugin.getAssetRegistry(), conditionName, info, floorOffset, rand);
            if (tableId == null || tableId.isBlank()) {
                tableId = "lostcities:chests/lostcitychest";
            }
            NamespacedKey key = NamespacedKey.fromString(tableId.toLowerCase(Locale.ROOT));
            LootTable table = key == null ? null : plugin.getApiAdapter().lookupLootTable(key);
            if (table != null) {
                chest.setLootTable(table);
                chest.update(false, false);
            } else {
                populateFallbackChest(chest.getBlockInventory(), rand);
            }
        });
    }

    public void scheduleSpawner(UUID worldId, int x, int y, int z, String conditionName, BuildingInfo info) {
        plugin.getGlobalTodo().enqueue(worldId, x >> 4, z >> 4, world -> {
            if (y < world.getMinHeight() || y >= world.getMaxHeight()) return;
            Block block = world.getBlockAt(x, y, z);
            BlockState state = block.getState();
            if (!(state instanceof CreatureSpawner spawner)) return;

            Random rand = DeterministicRandom.buildingRandom(x, z, world.getSeed() ^ (y * 31L));
            int floorOffset = (y - info.getCityGroundLevel()) / BuildingInfo.FLOOR_HEIGHT;
            String mobId = ConditionEvaluator.evaluate(plugin.getAssetRegistry(), conditionName, info, floorOffset, rand);
            EntityType type = resolveMob(mobId);
            spawner.setSpawnedType(type);
            spawner.update(false, false);
        });
    }

    @EventHandler
    public void onLootGenerate(LootGenerateEvent event) {
        // Hook reserved for metrics & future custom loot table overrides
        if (plugin.getPluginConfig().debug() && event.getLootTable() != null) {
            plugin.getLogger().fine("Generated loot for table " + event.getLootTable().getKey());
        }
    }

    private static void populateFallbackChest(Inventory inv, Random rand) {
        Material[] fallbackPool = new Material[]{
                Material.BREAD, Material.IRON_INGOT, Material.TORCH, Material.COAL,
                Material.ARROW, Material.BOOK, Material.REDSTONE, Material.GOLD_INGOT
        };
        int items = 2 + rand.nextInt(4);
        for (int i = 0; i < items; i++) {
            Material m = fallbackPool[rand.nextInt(fallbackPool.length)];
            inv.setItem(rand.nextInt(inv.getSize()), new ItemStack(m, 1 + rand.nextInt(3)));
        }
    }

    private static EntityType resolveMob(String mobId) {
        if (mobId == null || mobId.isBlank()) {
            return EntityType.ZOMBIE;
        }
        String normalized = mobId.toUpperCase(Locale.ROOT).replace("MINECRAFT:", "");
        try {
            return EntityType.valueOf(normalized);
        } catch (IllegalArgumentException ex) {
            return EntityType.ZOMBIE;
        }
    }
}
