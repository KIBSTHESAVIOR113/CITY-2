/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

import com.google.gson.JsonObject;
import mcjty.lostcities.paper.assets.AssetModels;
import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.gen.Doors;
import mcjty.lostcities.paper.core.highway.HighwayModels.HighwayInfo;
import mcjty.lostcities.paper.core.lost.City;
import mcjty.lostcities.paper.core.lost.CityStyleResolver;
import mcjty.lostcities.paper.core.lost.MultiChunk;
import mcjty.lostcities.paper.core.lost.Railway;
import mcjty.lostcities.paper.core.plan.ChunkPlanner;
import mcjty.lostcities.paper.core.terrain.TerrainHeightField;
import mcjty.lostcities.paper.util.BoundedCache;
import mcjty.lostcities.paper.util.DeterministicRandom;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.Function;

/**
 * Fase 3 + Fase 5 port of {@code LostCityTerrainFeature} from LostCities 26.3-12.0.2:
 * - C1 strict single-pass terrain shaping: {@code correctTerrainShape}, {@code makeRoomForBuilding},
 *   {@code clearToMax}, {@code fillToGround} run ONLY ONCE in {@link #shapeChunkSurface} during
 *   {@code generateSurface} ({@code ChunkData}), NEVER in {@code BlockPopulator} ({@code LimitedRegion}).
 * - Fase 5 building pipeline: {@code generateBuilding}, {@code generatePart} ({@link HardAirSetting},
 *   {@code parts2} second pass, full {@link Transform#transformBlockState}, layered {@link #computePalette}),
 *   {@code handleLoot}, {@code handleSpawner}, {@code handleBlockEntity}, {@code handleTodo}, {@code fixTorches}.
 */
public final class LostCityTerrainFeature {

    public static final int FLOOR_HEIGHT = BuildingInfo.FLOOR_HEIGHT;
    private static final String AIR = "minecraft:air";
    private static final String WATER = "minecraft:water";
    private static final String HARD_AIR = "minecraft:structure_void";
    private static final int SURFACE_PRESERVE_LAYERS = 6;

    /** Port of {@code LostCityTerrainFeature.HardAirSetting} (source L1781-1783). */
    public enum HardAirSetting {
        AIR, WATERLEVEL, VOID
    }

    private record OverlayEntry(int height, AssetModels.PartAsset part) {}

    private static final ThreadLocal<Random> COORDINATE_RANDOM = ThreadLocal.withInitial(Random::new);

    private final long worldSeed;
    private final String dimensionId;
    private final LostCityProfile profile;
    private final DeterministicRandom.PerlinNoise2D rubbleNoise;
    private final DeterministicRandom.PerlinNoise2D leavesNoise;
    private final DeterministicRandom.PerlinNoise2D ruinNoise;
    private final DeterministicRandom.PerlinNoise2D bottomLayerNoise;
    private final DeterministicRandom.PerlinNoise2D terrainTransitionNoise;
    private final BoundedCache<ChunkCoord, ChunkHeightmap> heightmapCache;

    public LostCityTerrainFeature(long worldSeed, String dimensionId, LostCityProfile profile) {
        this.worldSeed = worldSeed;
        this.dimensionId = dimensionId;
        this.profile = profile;
        // Invariant #1: exact construction order of all 4 Perlin noises from one Random(worldSeed)
        Random shared = new Random(worldSeed);
        this.rubbleNoise = new DeterministicRandom.PerlinNoise2D(shared, 4);
        this.leavesNoise = new DeterministicRandom.PerlinNoise2D(shared, 4);
        this.ruinNoise = new DeterministicRandom.PerlinNoise2D(shared, 4);
        this.bottomLayerNoise = new DeterministicRandom.PerlinNoise2D(shared, 4);
        // Invariant #2: exact transition seed formula
        this.terrainTransitionNoise = new DeterministicRandom.PerlinNoise2D(
                new Random(DeterministicRandom.transitionSeed(worldSeed, dimensionId)), 2);
        this.heightmapCache = new BoundedCache<>(4096, 300);
    }

    public static int getRandomizedOffset(int chunkX, int chunkZ, int min, int max) {
        Random random = COORDINATE_RANDOM.get();
        random.setSeed(chunkZ * 256203221L + chunkX * 899809363L);
        return random.nextInt(Math.max(1, max - min + 1)) + min;
    }

    public static int getHeightOffsetL1(int chunkX, int chunkZ) {
        Random random = COORDINATE_RANDOM.get();
        random.setSeed(chunkZ * 341873128712L + chunkX * 132897987541L);
        return random.nextInt(5);
    }

    public static int getHeightOffsetL2(int chunkX, int chunkZ) {
        Random random = COORDINATE_RANDOM.get();
        random.setSeed(chunkZ * 132897987541L + chunkX * 341873128712L);
        return random.nextInt(5);
    }

    public ChunkHeightmap getHeightmap(ChunkCoord coord, TerrainHeightField heightField) {
        return heightmapCache.computeIfAbsent(coord, c -> {
            ChunkHeightmap hm = new ChunkHeightmap();
            int bx = c.chunkX() << 4;
            int bz = c.chunkZ() << 4;
            for (int x = 0; x < 16; x++) {
                for (int z = 0; z < 16; z++) {
                    hm.set(x, z, heightField.sample(bx + x, bz + z).height());
                }
            }
            hm.finish();
            return hm;
        });
    }

    public double getTerrainTransitionNoise(int worldX, int worldZ) {
        double broad = terrainTransitionNoise.sample(worldX / 28.0, worldZ / 28.0) * 3.0;
        double detail = terrainTransitionNoise.sample((worldX + 10000) / 11.0, (worldZ - 10000) / 11.0);
        return broad + detail;
    }

    public static float bipolate(float h00, float h10, float h01, float h11, int dx, int dz) {
        float factor = (15.0f - dx) / 15.0f;
        float h0 = h00 + (h10 - h00) * factor;
        float h1 = h01 + (h11 - h01) * factor;
        return h0 + (h1 - h0) * (15.0f - dz) / 15.0f;
    }

    public float getInterpolatedHeight(BuildingInfo info, int x, int z, Function<ChunkCoord, BuildingInfo> lookup) {
        if (x < 8 && z < 8) {
            return bipolate(info.getCityGroundLevelOutsideLower(),
                    lookup.apply(info.coord.west()).getCityGroundLevelOutsideLower(),
                    lookup.apply(info.coord.north()).getCityGroundLevelOutsideLower(),
                    lookup.apply(info.coord.northWest()).getCityGroundLevelOutsideLower(), x + 8, z + 8);
        } else if (x >= 8 && z < 8) {
            return bipolate(lookup.apply(info.coord.east()).getCityGroundLevelOutsideLower(),
                    info.getCityGroundLevelOutsideLower(),
                    lookup.apply(info.coord.northEast()).getCityGroundLevelOutsideLower(),
                    lookup.apply(info.coord.north()).getCityGroundLevelOutsideLower(), x - 8, z + 8);
        } else if (x < 8) {
            return bipolate(lookup.apply(info.coord.south()).getCityGroundLevelOutsideLower(),
                    lookup.apply(info.coord.southWest()).getCityGroundLevelOutsideLower(),
                    info.getCityGroundLevelOutsideLower(),
                    lookup.apply(info.coord.west()).getCityGroundLevelOutsideLower(), x + 8, z - 8);
        } else {
            return bipolate(lookup.apply(info.coord.southEast()).getCityGroundLevelOutsideLower(),
                    lookup.apply(info.coord.south()).getCityGroundLevelOutsideLower(),
                    lookup.apply(info.coord.east()).getCityGroundLevelOutsideLower(),
                    info.getCityGroundLevelOutsideLower(), x - 8, z - 8);
        }
    }

    public int getMinHeightAt(BuildingInfo info, int x, int z, ChunkHeightmap heightmap, TerrainHeightField heightField) {
        int height = heightmap.getHeight();
        int adjacent;
        if (x == 0) {
            if (z == 0) adjacent = getHeightmap(info.coord.northWest(), heightField).getHeight();
            else if (z == 15) adjacent = getHeightmap(info.coord.southWest(), heightField).getHeight();
            else adjacent = getHeightmap(info.coord.west(), heightField).getHeight();
        } else if (x == 15) {
            if (z == 0) adjacent = getHeightmap(info.coord.northEast(), heightField).getHeight();
            else if (z == 15) adjacent = getHeightmap(info.coord.southEast(), heightField).getHeight();
            else adjacent = getHeightmap(info.coord.east(), heightField).getHeight();
        } else if (z == 0) {
            adjacent = getHeightmap(info.coord.north(), heightField).getHeight();
        } else if (z == 15) {
            adjacent = getHeightmap(info.coord.south(), heightField).getHeight();
        } else {
            return height;
        }
        return Math.min(height, adjacent);
    }

    /**
     * C1 SINGLE-PASS TERRAIN SHAPING: runs ONLY ONCE during {@code generateSurface} on {@code ChunkData}.
     * Non-city chunks blend smoothly via {@code correctTerrainShape}; city chunks clear/fill via
     * {@code makeRoomForBuilding}/{@code fillToGround} + {@code clearToMax} BEFORE vanilla decorations run.
     */
    public void shapeChunkSurface(
            BlockSurface surface,
            int chunkX,
            int chunkZ,
            AssetRegistry registry,
            ChunkPlanner planner,
            City city,
            TerrainHeightField heightField
    ) {
        shapeChunkSurface(surface, chunkX, chunkZ, registry, planner, city, heightField, null);
    }

    public void shapeChunkSurface(
            BlockSurface surface,
            int chunkX,
            int chunkZ,
            AssetRegistry registry,
            ChunkPlanner planner,
            City city,
            TerrainHeightField heightField,
            MultiChunk.Cache multiChunkCache
    ) {
        try (GenerationContext.Scope ignored = GenerationContext.open(worldSeed, dimensionId, chunkX, chunkZ)) {
            ChunkDriver driver = GenerationContext.current().driver();
            driver.begin(surface, chunkX, chunkZ);

            ChunkCoord coord = new ChunkCoord(dimensionId, chunkX, chunkZ);
            Function<ChunkCoord, BuildingInfo> lookup = c -> BuildingInfo.get(
                    c, worldSeed, profile, registry, planner, city, heightField, multiChunkCache,
                    HighwayInfo.NONE, Railway.RailChunkInfo.NOTHING);
            BuildingInfo info = lookup.apply(coord);
            ChunkHeightmap heightmap = getHeightmap(coord, heightField);

            if (info.isCity) {
                int cityGround = Math.max(driver.minY() + profile.bedrockLayer,
                        Math.min(driver.maxY() - 16, info.getCityGroundLevel()));
                int lowestLevel = Math.max(driver.minY() + profile.bedrockLayer,
                        cityGround - info.cellars * FLOOR_HEIGHT);
                if (info.hasBuilding) {
                    CompiledPalette palette = info.getCompiledPalette(registry, lookup);
                    makeRoomForBuilding(driver, info, lowestLevel, heightmap, palette, heightField, registry);
                } else {
                    String borderBlock = CityStyleResolver.resolveBorderBlock(registry, info.cityStyleId, "minecraft:stone_bricks");
                    fillToGround(driver, info, cityGround, borderBlock);
                }
                clearToMax(driver, info, heightmap, cityGround + 1, driver.maxY() - 1);
            } else {
                correctTerrainShape(driver, info, heightmap, heightField, planner, lookup);
            }
            driver.flush();
        }
    }

    /** Port of {@code LostCityTerrainFeature.correctTerrainShape} (source L598-683, C2 verified). */
    public void correctTerrainShape(
            ChunkDriver driver,
            BuildingInfo info,
            ChunkHeightmap heightmap,
            TerrainHeightField heightField,
            ChunkPlanner planner,
            Function<ChunkCoord, BuildingInfo> lookup
    ) {
        BuildingInfo.MinMax mm00 = planner.minMaxL2(info.coord, () -> info.getDesiredMaxHeightL2(lookup));
        BuildingInfo.MinMax mm10 = planner.minMaxL2(info.coord.east(), () -> lookup.apply(info.coord.east()).getDesiredMaxHeightL2(lookup));
        BuildingInfo.MinMax mm01 = planner.minMaxL2(info.coord.south(), () -> lookup.apply(info.coord.south()).getDesiredMaxHeightL2(lookup));
        BuildingInfo.MinMax mm11 = planner.minMaxL2(info.coord.southEast(), () -> lookup.apply(info.coord.southEast()).getDesiredMaxHeightL2(lookup));

        float min00 = mm00.min, min10 = mm10.min, min01 = mm01.min, min11 = mm11.min;
        float max00 = mm00.max, max10 = mm10.max, max01 = mm01.max, max11 = mm11.max;

        int max = driver.maxY() - 1;
        if (max00 < max || max10 < max || max01 < max || max11 < max ||
                min00 < max || min10 < max || min01 < max || min11 < max) {
            // Exact source formula (LostCityTerrainFeature.java:620-621): heightmap.getHeight() +/- 90
            int maxHeightP = heightmap.getHeight() + 90;
            int minHeightP = heightmap.getHeight() - 90;
            if (max00 >= max) max00 = maxHeightP;
            if (max10 >= max) max10 = maxHeightP;
            if (max01 >= max) max01 = maxHeightP;
            if (max11 >= max) max11 = maxHeightP;
            if (min00 >= max) min00 = minHeightP;
            if (min10 >= max) min10 = minHeightP;
            if (min01 >= max) min01 = minHeightP;
            if (min11 >= max) min11 = minHeightP;

            int baseX = info.coord.chunkX() << 4;
            int baseZ = info.coord.chunkZ() << 4;
            boolean dowater = info.waterLevel > info.groundLevel && !profile.avoidWater;

            for (int x = 0; x < 16; x++) {
                float factor = (15.0f - x) / 15.0f;
                float maxh0 = max11 + (max01 - max11) * factor;
                float maxh1 = max10 + (max00 - max10) * factor;
                float minh0 = min11 + (min01 - min11) * factor;
                float minh1 = min10 + (min00 - min10) * factor;
                for (int z = 0; z < 16; z++) {
                    float maxheight = maxh0 + (maxh1 - maxh0) * (15.0f - z) / 15.0f;
                    float minheight = minh0 + (minh1 - minh0) * (15.0f - z) / 15.0f;
                    float transitionFreedom = Math.max(0.0f, maxheight - minheight - 4.0f);
                    float noiseStrength = Math.min(1.0f, transitionFreedom / 20.0f);
                    double noiseOffset = getTerrainTransitionNoise(baseX + x, baseZ + z) * noiseStrength;
                    maxheight += (float) noiseOffset;
                    minheight += (float) noiseOffset;

                    int targetMax = Math.max(driver.minY() + 1, Math.min(max, (int) maxheight));
                    int targetMin = Math.max(driver.minY() + 1, Math.min(targetMax, (int) minheight));

                    if (!moveDown(driver, info, x, z, targetMax, max)) {
                        TerrainHeightField.Sample s = heightField.sample(baseX + x, baseZ + z);
                        moveUp(driver, info, x, z, targetMin, dowater, s.topBlock(), s.fillerBlock());
                    }
                }
            }
        }
    }

    public boolean moveDown(ChunkDriver driver, BuildingInfo info, int x, int z, int height, int max) {
        int y = Math.min(max, driver.maxY() - 1);
        int minY = driver.minY();
        while (y > height && isAirOrWater(driver.getBlock(x, y, z))) y--;
        if (y <= height) return false;
        String[] saved = new String[SURFACE_PRESERVE_LAYERS];
        int savedCount = 0;
        for (int i = 0; i < SURFACE_PRESERVE_LAYERS && (y - i) >= minY; i++) {
            String b = driver.getBlock(x, y - i, z);
            if (isAirOrWater(b)) break;
            saved[savedCount++] = b;
        }
        driver.setBlockRange(x, height + 1, z, y + 1, AIR);
        for (int i = 0; i < savedCount && (height - i) >= minY; i++) {
            driver.setBlock(x, height - i, z, saved[i]);
        }
        return true;
    }

    public void moveUp(ChunkDriver driver, BuildingInfo info, int x, int z, int height, boolean dowater, String topBlock, String fillerBlock) {
        int minY = driver.minY();
        int y = Math.min(driver.maxY() - 1, Math.max(height, info.waterLevel + 16));
        while (y > minY && isAirOrWater(driver.getBlock(x, y, z))) y--;
        if (y >= height) return;
        int fillTop = Math.max(y + 1, height - 3);
        if (y + 1 < fillTop) driver.setBlockRange(x, y + 1, z, fillTop, profile.baseBlock);
        if (fillTop < height) driver.setBlockRange(x, fillTop, z, height, fillerBlock);
        driver.setBlock(x, height, z, topBlock);
        if (dowater && height < info.waterLevel) {
            driver.setBlockRange(x, height + 1, z, info.waterLevel + 1, WATER);
        }
    }

    public void clearRange(ChunkDriver driver, BuildingInfo info, int x, int z, int height1, int height2, boolean dowater) {
        if (height1 >= height2) return;
        if (dowater && info.waterLevel >= height1) {
            int waterTop = Math.min(height2, info.waterLevel + 1);
            driver.setBlockRange(x, height1, z, waterTop, WATER);
            if (waterTop < height2) driver.setBlockRange(x, waterTop, z, height2, AIR);
        } else {
            driver.setBlockRange(x, height1, z, height2, AIR);
        }
    }

    public void clearToMax(ChunkDriver driver, BuildingInfo info, ChunkHeightmap heightmap, int height, int max) {
        int maximumHeight = Math.min(max, Math.max(heightmap.getMaximumHeight(), heightmap.getHeight()) + 10);
        if (height < maximumHeight) {
            boolean dowater = info.waterLevel > info.groundLevel && !profile.avoidWater;
            for (int x = 0; x < 16; x++) {
                for (int z = 0; z < 16; z++) {
                    clearRange(driver, info, x, z, height, maximumHeight, dowater);
                }
            }
        }
    }

    public void fillToGround(ChunkDriver driver, BuildingInfo info, int lowestLevel, String borderBlock) {
        int deepestY = Math.max(driver.minY() + profile.bedrockLayer, lowestLevel - 10);
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                int y = lowestLevel - 1;
                while (y >= deepestY && isAirOrWater(driver.getBlock(x, y, z))) {
                    driver.setBlock(x, y, z, isSide(x, z) ? borderBlock : profile.baseBlock);
                    y--;
                }
                if (isAirOrWater(driver.getBlock(x, lowestLevel, z))) {
                    driver.setBlock(x, lowestLevel, z, borderBlock);
                }
            }
        }
    }

    public void makeRoomForBuilding(
            ChunkDriver driver, BuildingInfo info, int lowestLevel, ChunkHeightmap heightmap,
            CompiledPalette palette, TerrainHeightField heightField, AssetRegistry registry
    ) {
        String borderBlock = CityStyleResolver.resolveBorderBlock(registry, info.cityStyleId, "minecraft:stone_bricks");
        String fillerBlock = palette.getBlock(info.fillerChar);
        if (fillerBlock == null || fillerBlock.isBlank()) fillerBlock = profile.baseBlock;
        int clearTop = Math.min(driver.maxY() - 1, info.getCityGroundLevel() + info.floors * FLOOR_HEIGHT);
        boolean dowater = info.waterLevel > info.groundLevel && !profile.avoidWater;

        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                if (isSide(x, z)) {
                    int y = getMinHeightAt(info, x, z, heightmap, heightField);
                    if (y >= lowestLevel) y = lowestLevel - 3;
                    int startY = Math.max(driver.minY() + profile.bedrockLayer, y);
                    if (startY < lowestLevel) driver.setBlockRange(x, startY, z, lowestLevel, borderBlock);
                }
                if (isAirOrWater(driver.getBlock(x, lowestLevel, z))) {
                    driver.setBlock(x, lowestLevel, z, fillerBlock);
                }
                clearRange(driver, info, x, z, lowestLevel + 1, clearTop, dowater);
            }
        }
    }

    /**
     * C1 POST-PASS ONLY (runs in {@code BlockPopulator} on {@code LimitedRegion}):
     * NEVER modifies terrain via {@code correctTerrainShape}/{@code makeRoomForBuilding}/{@code clearToMax}/{@code fillToGround}.
     * Only places buildings, doors, streets, torches, ruins, rubble, and explosion damage.
     */
    public Map<Long, String> generateChunk(
            BlockSurface surface, int chunkX, int chunkZ, AssetRegistry registry,
            ChunkPlanner planner, City city, TerrainHeightField heightField, LootSpawnerSink lootSpawnerSink
    ) {
        return generateChunk(surface, chunkX, chunkZ, registry, planner, city, heightField, null, lootSpawnerSink);
    }

    public Map<Long, String> generateChunk(
            BlockSurface surface, int chunkX, int chunkZ, AssetRegistry registry,
            ChunkPlanner planner, City city, TerrainHeightField heightField,
            MultiChunk.Cache multiChunkCache, LootSpawnerSink lootSpawnerSink
    ) {
        try (GenerationContext.Scope ignored = GenerationContext.open(worldSeed, dimensionId, chunkX, chunkZ)) {
            ChunkDriver driver = GenerationContext.current().driver();
            driver.begin(surface, chunkX, chunkZ);

            ChunkCoord coord = new ChunkCoord(dimensionId, chunkX, chunkZ);
            Function<ChunkCoord, BuildingInfo> lookup = c -> BuildingInfo.get(
                    c, worldSeed, profile, registry, planner, city, heightField, multiChunkCache,
                    HighwayInfo.NONE, Railway.RailChunkInfo.NOTHING);
            BuildingInfo info = lookup.apply(coord);

            if (info.isCity) {
                int ground = Math.max(driver.minY() + profile.bedrockLayer,
                        Math.min(driver.maxY() - 16, info.getCityGroundLevel()));
                if (info.hasBuilding) {
                    generateBuilding(driver, info, registry, lootSpawnerSink, lookup);
                    if (info.ruinHeight >= 0.0f) {
                        applyRuins(driver, info, ground);
                    }
                } else {
                    generateStreetSurface(driver, info, ground, registry);
                }
                fixTorches(driver, info);
                if (profile.rubbleLayer) {
                    generateRubble(driver, info, ground);
                }
            }

            // Invariant #5: deterministic reseed immediately before explosions & debris
            GenerationContext.current().reseedForDamage(chunkX, chunkZ);
            applyDamageAndDebris(driver, info, chunkX, chunkZ);

            return driver.flush();
        }
    }

    /** Port of {@code LostCityTerrainFeature.computePalette} (source L1887-1895). */
    public CompiledPalette computePalette(BuildingInfo info, AssetModels.PartAsset part, AssetRegistry registry, Function<ChunkCoord, BuildingInfo> lookup) {
        CompiledPalette compiled = info.getCompiledPalette(registry, lookup);
        if (part != null) {
            if (part.refPaletteName() != null && !part.refPaletteName().isBlank()) {
                AssetModels.PaletteAsset ref = registry.getPalette(part.refPaletteName());
                if (ref != null) compiled = compiled.withPalette(registry, ref);
            }
            if (part.raw() != null && part.raw().has("palette") && part.raw().get("palette").isJsonArray()) {
                compiled = compiled.withInlinePalette(registry, part.raw().getAsJsonArray("palette"));
            }
        }
        return compiled;
    }

    /** Port of {@code LostCityTerrainFeature.generateBuilding} (source L2198-2261). */
    public void generateBuilding(
            ChunkDriver driver,
            BuildingInfo info,
            AssetRegistry registry,
            LootSpawnerSink sink,
            Function<ChunkCoord, BuildingInfo> lookup
    ) {
        int lowestLevel = Math.max(driver.minY() + profile.bedrockLayer, info.getBuildingBottomHeight());
        int cellars = info.cellars;
        int floors = info.floors;
        CompiledPalette buildingPalette = info.getCompiledPalette(registry, lookup);
        List<OverlayEntry> part2Map = new ArrayList<>();

        int height = lowestLevel;
        for (int f = -cellars; f <= floors; f++) {
            String partId = info.getFloorByLevel(f);
            AssetModels.PartAsset part = (partId == null || partId.isBlank()) ? null : registry.getPart(partId);
            if (part != null) {
                generatePart(driver, info, part, Transform.ROTATE_NONE, 0, height, 0, HardAirSetting.AIR, registry, lookup, sink);
            }
            String part2Id = info.getFloorPart2ByLevel(f);
            AssetModels.PartAsset part2 = (part2Id == null || part2Id.isBlank()) ? null : registry.getPart(part2Id);
            if (part2 != null) {
                part2Map.add(new OverlayEntry(height, part2));
            }
            boolean isTop = (f == floors);
            if (!isTop && info.allowDoors) {
                Doors.generateDoors(driver, info, buildingPalette, info.fillerChar, height + 1, f, lookup);
            }
            height += FLOOR_HEIGHT;
        }

        // Underground cellar perimeter: replace exposed glass/air with building filler (source L2235-2246)
        if (cellars > 0) {
            String filler = buildingPalette.getBlock(info.fillerChar);
            if (filler == null || filler.isBlank()) filler = profile.baseBlock;
            int cityG = info.getCityGroundLevel();
            int zMinTop = Math.min(cityG, lookup.apply(info.coord.north()).getCityGroundLevel()) + 1;
            int zMaxTop = Math.min(cityG, lookup.apply(info.coord.south()).getCityGroundLevel()) + 1;
            int xMinTop = Math.min(cityG, lookup.apply(info.coord.west()).getCityGroundLevel()) + 1;
            int xMaxTop = Math.min(cityG, lookup.apply(info.coord.east()).getCityGroundLevel()) + 1;
            for (int x = 0; x < 16; x++) {
                driver.setBlockRange(x, lowestLevel, 0, zMinTop, filler);
                driver.setBlockRange(x, lowestLevel, 15, zMaxTop, filler);
            }
            for (int z = 1; z < 15; z++) {
                driver.setBlockRange(0, lowestLevel, z, xMinTop, filler);
                driver.setBlockRange(15, lowestLevel, z, xMaxTop, filler);
            }
        }

        // Second pass for parts2 overlays (source L2253-2260)
        for (OverlayEntry entry : part2Map) {
            generatePart(driver, info, entry.part(), Transform.ROTATE_NONE, 0, entry.height(), 0, HardAirSetting.AIR, registry, lookup, sink);
        }
    }

    /** Port of {@code LostCityTerrainFeature.generatePart} (source L1789-1885). */
    public int generatePart(
            ChunkDriver driver,
            BuildingInfo info,
            AssetModels.PartAsset part,
            Transform transform,
            int ox, int oy, int oz,
            HardAirSetting airWaterLevel,
            AssetRegistry registry,
            Function<ChunkCoord, BuildingInfo> lookup,
            LootSpawnerSink sink
    ) {
        if (part == null || part.slices().isEmpty()) return oy;
        CompiledPalette compiledPalette = computePalette(info, part, registry, lookup);
        boolean nowater = Boolean.TRUE.equals(part.metadata().get("nowater"));
        boolean forcedAir = Boolean.TRUE.equals(part.metadata().get("forcedair"));

        int sliceCount = part.slices().size();
        int maxY = driver.maxY();
        int minY = driver.minY();

        for (int dy = 0; dy < sliceCount; dy++) {
            int y = oy + dy;
            if (y < minY || y >= maxY) continue;
            List<String> rows = part.slices().get(dy);
            for (int z = 0; z < Math.min(part.zSize(), rows.size()); z++) {
                String row = rows.get(z);
                for (int x = 0; x < Math.min(part.xSize(), row.length()); x++) {
                    char c = row.charAt(x);
                    CompiledPalette.Entry entry = compiledPalette.getEntry(c);
                    String b = (entry != null) ? entry.sample() : compiledPalette.getBlock(c);
                    if (b == null || AIR.equals(b)) continue;

                    if (transform != Transform.ROTATE_NONE) {
                        b = transform.transformBlockState(b);
                    }

                    int rx = ox + transform.rotateX(x, z);
                    int rz = oz + transform.rotateZ(x, z);
                    if (rx < 0 || rx >= 16 || rz < 0 || rz >= 16) continue;

                    if (WATER.equals(b) || b.startsWith("minecraft:water[")) {
                        if (profile.avoidWater) b = AIR;
                    } else if (HARD_AIR.equals(b)) {
                        if (forcedAir) {
                            b = AIR;
                        } else {
                            switch (airWaterLevel) {
                                case AIR -> b = AIR;
                                case WATERLEVEL -> b = (!profile.avoidFoliage && !nowater && y < info.waterLevel) ? WATER : AIR;
                                case VOID -> { continue; } // leave existing block untouched
                            }
                        }
                    } else if (entry != null) {
                        if (entry.isTorch()) {
                            if (profile.generateLighting) {
                                info.addTorchTodo(info.getRelativePos(rx, y, rz));
                            } else {
                                b = AIR;
                            }
                        } else if (entry.lootCondition() != null && !entry.lootCondition().isEmpty()) {
                            handleLoot(info, rx, y, rz, entry.lootCondition(), sink);
                        } else if (entry.mobCondition() != null && !entry.mobCondition().isEmpty()) {
                            b = handleSpawner(info, rx, y, rz, b, entry.mobCondition(), sink);
                        } else if (entry.blockEntityTag() != null) {
                            b = handleBlockEntity(info, rx, y, rz, b, entry.blockEntityTag());
                        }
                    }

                    b = handleTodo(b);
                    driver.setBlock(rx, y, rz, b);
                }
            }
        }
        return oy + sliceCount;
    }

    /** Port of {@code LostCityTerrainFeature.handleLoot} (source L1954-1965). */
    private void handleLoot(BuildingInfo info, int rx, int y, int rz, String lootCondition, LootSpawnerSink sink) {
        if (info.hasLoot && sink != null) {
            BuildingInfo.BlockPos3D pos = info.getRelativePos(rx, y, rz);
            sink.onLootBlock(pos.x(), pos.y(), pos.z(), lootCondition, info);
        }
    }

    /** Port of {@code LostCityTerrainFeature.handleSpawner} (source L1931-1952). */
    private String handleSpawner(BuildingInfo info, int rx, int y, int rz, String blockId, String mobCondition, LootSpawnerSink sink) {
        if (profile.generateSpawners && info.hasLoot) {
            if (sink != null) {
                BuildingInfo.BlockPos3D pos = info.getRelativePos(rx, y, rz);
                sink.onSpawnerBlock(pos.x(), pos.y(), pos.z(), mobCondition, info);
            }
            return blockId;
        }
        return AIR;
    }

    /** Port of {@code LostCityTerrainFeature.handleBlockEntity} (source L1908-1929). */
    private String handleBlockEntity(BuildingInfo info, int rx, int y, int rz, String blockId, JsonObject tag) {
        // Block entity blockstate is placed; NBT tag hook preserved for Fase 6/7 tile entity adapter
        return blockId;
    }

    /** Port of {@code LostCityTerrainFeature.handleTodo} (source L1967-1988). */
    private String handleTodo(String blockId) {
        if (profile.avoidFoliage && (blockId.contains("sapling") || blockId.contains("flower")
                || blockId.contains("leaves") || blockId.contains("vine") || blockId.contains("poppy")
                || blockId.contains("dandelion"))) {
            return AIR;
        }
        return blockId;
    }

    /** Port of {@code LostCityTerrainFeature.fixTorches} (source L398-423). */
    public void fixTorches(ChunkDriver driver, BuildingInfo info) {
        List<BuildingInfo.BlockPos3D> torches = info.getTorchTodo();
        if (torches.isEmpty()) return;
        for (BuildingInfo.BlockPos3D pos : torches) {
            int x = pos.x() & 15;
            int z = pos.z() & 15;
            int y = pos.y();
            if (y <= driver.minY() || y >= driver.maxY()) continue;
            if (!isAirOrWater(driver.getBlock(x, y - 1, z))) {
                driver.setBlock(x, y, z, "minecraft:torch");
            } else if (x > 0 && !isAirOrWater(driver.getBlock(x - 1, y, z))) {
                driver.setBlock(x, y, z, "minecraft:wall_torch[facing=east]");
            } else if (x < 15 && !isAirOrWater(driver.getBlock(x + 1, y, z))) {
                driver.setBlock(x, y, z, "minecraft:wall_torch[facing=west]");
            } else if (z > 0 && !isAirOrWater(driver.getBlock(x, y, z - 1))) {
                driver.setBlock(x, y, z, "minecraft:wall_torch[facing=south]");
            } else if (z < 15 && !isAirOrWater(driver.getBlock(x, y, z + 1))) {
                driver.setBlock(x, y, z, "minecraft:wall_torch[facing=north]");
            }
        }
        info.clearTorchTodo();
    }

    /** CityStyle-driven street surface pass (full street/park/slope/border parts completed in Fase 6). */
    private void generateStreetSurface(ChunkDriver driver, BuildingInfo info, int ground, AssetRegistry registry) {
        AssetModels.CityStyleAsset cs = registry.getCityStyle(info.cityStyleId);
        String streetBlock = (cs != null && cs.streetBlock() != null && !cs.streetBlock().isBlank())
                ? cs.streetBlock() : "minecraft:stone_bricks";
        String baseBlock = (cs != null && cs.streetBaseBlock() != null && !cs.streetBaseBlock().isBlank())
                ? cs.streetBaseBlock() : profile.baseBlock;
        String borderBlock = CityStyleResolver.resolveBorderBlock(registry, info.cityStyleId, "minecraft:smooth_stone_slab");
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                boolean border = x < 2 || x > 13 || z < 2 || z > 13;
                driver.setBlock(x, ground - 1, z, baseBlock);
                driver.setBlock(x, ground, z, border ? borderBlock : streetBlock);
            }
        }
    }

    private void applyRuins(ChunkDriver driver, BuildingInfo info, int ground) {
        int maxH = Math.min(driver.maxY() - 1, info.getMaxHeight());
        int ruinY = ground + Math.max(2, Math.round((maxH - ground) * info.ruinHeight));
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                double n = ruinNoise.sample(((info.coord.chunkX() << 4) + x) * 0.12, ((info.coord.chunkZ() << 4) + z) * 0.12);
                int cutY = ruinY + (int) Math.round(n * 4.0);
                driver.setBlockRange(x, Math.max(ground + 1, cutY), z, maxH + 1, AIR);
            }
        }
    }

    private void generateRubble(ChunkDriver driver, BuildingInfo info, int ground) {
        Random rand = GenerationContext.current().random();
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                double r = rubbleNoise.sample(((info.coord.chunkX() << 4) + x) * 0.15, ((info.coord.chunkZ() << 4) + z) * 0.15);
                if (r > 0.35 && rand.nextFloat() < 0.25f) {
                    String block = (profile.rubbleDirtScale > 0 && rand.nextFloat() < 0.5f)
                            ? "minecraft:coarse_dirt" : "minecraft:cobblestone";
                    if (AIR.equals(driver.getBlock(x, ground + 1, z))) {
                        driver.setBlock(x, ground + 1, z, block);
                    }
                }
            }
        }
    }

    private void applyDamageAndDebris(ChunkDriver driver, BuildingInfo info, int chunkX, int chunkZ) {
        if (!info.damageArea.hasExplosions()) return;
        Random rand = GenerationContext.current().random();
        int baseX = chunkX << 4;
        int baseZ = chunkZ << 4;
        int minY = Math.max(driver.minY() + profile.bedrockLayer, info.groundLevel - 16);
        int maxY = Math.min(driver.maxY() - 1, info.getMaxHeight() + 8);
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                for (int y = minY; y <= maxY; y++) {
                    float dmg = info.damageArea.getDamage(baseX + x, y, baseZ + z);
                    if (dmg >= 0.7f) {
                        driver.setBlock(x, y, z, AIR);
                    } else if (dmg >= 0.35f && rand.nextFloat() < dmg && !AIR.equals(driver.getBlock(x, y, z))) {
                        driver.setBlock(x, y, z, "minecraft:cracked_stone_bricks");
                    }
                }
            }
        }
    }

    private static boolean isSide(int x, int z) { return x == 0 || x == 15 || z == 0 || z == 15; }

    private static boolean isAirOrWater(String blockId) {
        return blockId == null || AIR.equals(blockId) || "minecraft:cave_air".equals(blockId)
                || "minecraft:void_air".equals(blockId) || WATER.equals(blockId) || blockId.startsWith("minecraft:water[");
    }

    public double sampleBottomLayerNoise(int worldX, int worldZ) {
        return bottomLayerNoise.sample(worldX * 0.08, worldZ * 0.08);
    }

    public interface LootSpawnerSink {
        void onLootBlock(int worldX, int y, int worldZ, String conditionName, BuildingInfo info);
        void onSpawnerBlock(int worldX, int y, int worldZ, String conditionName, BuildingInfo info);
    }
}
