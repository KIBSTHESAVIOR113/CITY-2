/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

/**
 * Immutable chunk coordinate scoped to a dimension identifier.
 */
public record ChunkCoord(String dimensionId, int chunkX, int chunkZ) {

    public ChunkCoord west() { return new ChunkCoord(dimensionId, chunkX - 1, chunkZ); }
    public ChunkCoord east() { return new ChunkCoord(dimensionId, chunkX + 1, chunkZ); }
    public ChunkCoord north() { return new ChunkCoord(dimensionId, chunkX, chunkZ - 1); }
    public ChunkCoord south() { return new ChunkCoord(dimensionId, chunkX, chunkZ + 1); }
    public ChunkCoord offset(int dx, int dz) { return new ChunkCoord(dimensionId, chunkX + dx, chunkZ + dz); }

    public long pack() {
        return pack(chunkX, chunkZ);
    }

    public static long pack(int cx, int cz) {
        return (((long) cx) << 32) | (cz & 0xffffffffL);
    }
}
