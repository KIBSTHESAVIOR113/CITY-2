/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.lost;

/**
 * Direct port of {@code mcjty.lostcities.worldgen.lost.Explosion}.
 */
public record Explosion(int radius, int centerX, int centerY, int centerZ) {

    public int sqRadius() {
        return radius * radius;
    }

    public double distSqToCenter(double x, double y, double z) {
        double dx = (centerX + 0.5) - x;
        double dy = (centerY + 0.5) - y;
        double dz = (centerZ + 0.5) - z;
        return dx * dx + dy * dy + dz * dz;
    }
}
