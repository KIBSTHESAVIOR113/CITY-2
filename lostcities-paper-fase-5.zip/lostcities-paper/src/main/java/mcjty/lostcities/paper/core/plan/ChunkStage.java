/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.plan;

public enum ChunkStage {
    BASE,
    INFRASTRUCTURE,
    CHARACTERISTICS,
    CHUNK
}
