/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.lost;

import mcjty.lostcities.paper.config.HighwayGenerationMode;
import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.core.highway.HighwayModels.HighwayInfo;
import mcjty.lostcities.paper.core.highway.HighwayPlanningService;
import mcjty.lostcities.paper.util.BoundedCache;
import mcjty.lostcities.paper.util.DeterministicRandom;

import java.util.Random;
import java.util.function.Predicate;
import java.util.function.ToIntFunction;

/**
 * Full port of {@code mcjty.lostcities.worldgen.lost.Highway} (L1-180) including legacy
 * Perlin span scanning (minimum length 5, {@code HIGHWAY_REQUIRES_TWO_CITIES}, and
 * {@code HIGHWAY_LEVEL_FROM_CITIES_MODE} 0..4) plus {@code INTERCITY_NETWORK_V1} mode.
 */
public final class Highway {

    private static final int MAX_SCAN_STEPS = 256;

    private final DeterministicRandom.PerlinNoise2D noiseX;
    private final DeterministicRandom.PerlinNoise2D noiseZ;
    private final BoundedCache<ChunkCoord, Integer> xLevelCache;
    private final BoundedCache<ChunkCoord, Integer> zLevelCache;

    public Highway(long seed, int maxCacheEntries, int ttlSeconds) {
        this.noiseX = new DeterministicRandom.PerlinNoise2D(new Random(seed), 4);
        this.noiseZ = new DeterministicRandom.PerlinNoise2D(new Random(seed), 4);
        this.xLevelCache = new BoundedCache<>(maxCacheEntries, ttlSeconds);
        this.zLevelCache = new BoundedCache<>(maxCacheEntries, ttlSeconds);
    }

    public HighwayInfo computeHighwayInfo(
            ChunkCoord coord,
            LostCityProfile profile,
            HighwayPlanningService service,
            Predicate<ChunkCoord> isCityRaw,
            ToIntFunction<ChunkCoord> cityLevelProvider,
            Predicate<ChunkCoord> intersectsSphere
    ) {
        if (profile.highwayGenerationMode == HighwayGenerationMode.INTERCITY_NETWORK_V1 && service != null) {
            if ((profile.isSpace() || profile.isSpheres()) && intersectsSphere != null && intersectsSphere.test(coord)) {
                return HighwayInfo.NONE;
            }
            return service.getHighwayInfo(coord.chunkX(), coord.chunkZ());
        }
        int xLevel = getHighwayLevel(coord, profile, xLevelCache, Orientation.X, isCityRaw, cityLevelProvider, intersectsSphere);
        int zLevel = getHighwayLevel(coord, profile, zLevelCache, Orientation.Z, isCityRaw, cityLevelProvider, intersectsSphere);
        return (xLevel < 0 && zLevel < 0) ? HighwayInfo.NONE : new HighwayInfo(xLevel, zLevel);
    }

    private int getHighwayLevel(
            ChunkCoord cp,
            LostCityProfile profile,
            BoundedCache<ChunkCoord, Integer> cache,
            Orientation orientation,
            Predicate<ChunkCoord> isCityRaw,
            ToIntFunction<ChunkCoord> cityLevelProvider,
            Predicate<ChunkCoord> intersectsSphere
    ) {
        Integer cached = cache.get(cp);
        if (cached != null) return cached;

        int mask = profile.highwayDistanceMask;
        if (mask <= 0) {
            cache.put(cp, -1);
            return -1;
        }
        int oppositeCoord = orientation == Orientation.X ? cp.chunkZ() : cp.chunkX();
        if ((oppositeCoord & mask) != 0) {
            cache.put(cp, -1);
            return -1;
        }
        if ((profile.isSpace() || profile.isSpheres()) && intersectsSphere != null && intersectsSphere.test(cp)) {
            cache.put(cp, -1);
            return -1;
        }

        if (hasLegacyHighway(cp, orientation, profile)) {
            ChunkCoord lower = step(cp, orientation, -1);
            int steps = 0;
            while (steps < MAX_SCAN_STEPS && hasLegacyHighway(lower, orientation, profile)) {
                lower = step(lower, orientation, -1);
                steps++;
            }
            lower = step(lower, orientation, 1);

            ChunkCoord higher = step(cp, orientation, 1);
            steps = 0;
            while (steps < MAX_SCAN_STEPS && hasLegacyHighway(higher, orientation, profile)) {
                higher = step(higher, orientation, 1);
                steps++;
            }
            higher = step(higher, orientation, -1);

            int level = -1;
            int span = axisCoord(higher, orientation) - axisCoord(lower, orientation);
            if (span >= 5) {
                boolean valid = profile.highwayRequiresTwoCities
                        ? (isCityRaw.test(lower) && isCityRaw.test(higher))
                        : (isCityRaw.test(lower) || isCityRaw.test(higher));
                if (valid) {
                    int lowLvl = cityLevelProvider.applyAsInt(lower);
                    int highLvl = cityLevelProvider.applyAsInt(higher);
                    level = switch (profile.highwayLevelFromCities) {
                        case 0 -> lowLvl;
                        case 1 -> Math.min(lowLvl, highLvl);
                        case 2 -> Math.max(lowLvl, highLvl);
                        case 3 -> (lowLvl + highLvl) / 2;
                        case 4 -> profile.highwayNetworkLevel;
                        default -> throw new IllegalArgumentException("Bad value for highwayLevelFromCities: " + profile.highwayLevelFromCities);
                    };
                    for (ChunkCoord cc = lower; axisCoord(cc, orientation) <= axisCoord(higher, orientation); cc = step(cc, orientation, 1)) {
                        cache.put(cc, level);
                    }
                }
            }
            if (level < 0) {
                cache.put(cp, -1);
            }
            return level;
        }

        cache.put(cp, -1);
        return -1;
    }

    private boolean hasLegacyHighway(ChunkCoord cp, Orientation orientation, LostCityProfile profile) {
        if (orientation == Orientation.X) {
            return noiseX.sample(cp.chunkX() / (double) profile.highwayMainPerlinScale,
                    cp.chunkZ() / (double) profile.highwaySecondaryPerlinScale) > profile.highwayPerlinFactor;
        }
        return noiseZ.sample(cp.chunkX() / (double) profile.highwaySecondaryPerlinScale,
                cp.chunkZ() / (double) profile.highwayMainPerlinScale) > profile.highwayPerlinFactor;
    }

    private static int axisCoord(ChunkCoord c, Orientation o) {
        return o == Orientation.X ? c.chunkX() : c.chunkZ();
    }

    private static ChunkCoord step(ChunkCoord c, Orientation o, int delta) {
        return o == Orientation.X ? c.offset(delta, 0) : c.offset(0, delta);
    }

    public void clearCache() {
        xLevelCache.clear();
        zLevelCache.clear();
    }
}
