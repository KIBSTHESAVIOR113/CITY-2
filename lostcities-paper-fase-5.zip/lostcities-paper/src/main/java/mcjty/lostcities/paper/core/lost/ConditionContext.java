/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.lost;

import mcjty.lostcities.paper.core.ChunkCoord;

/**
 * Port of {@code mcjty.lostcities.worldgen.lost.cityassets.ConditionContext} used to evaluate
 * {@code Building.parts}, {@code Building.parts2}, and loot/mob condition assets.
 */
public record ConditionContext(
        int level,
        int floor,
        int cellars,
        int floors,
        String part,
        String belowPart,
        String building,
        ChunkCoord coord,
        boolean isBuilding,
        boolean isSphere,
        String biomeId
) {
    public boolean isTop() { return floor == floors; }
    public boolean isGround() { return floor == 0; }
    public boolean isCellar() { return floor < 0; }
    public boolean isBelowTop() { return floor == floors - 1; }
}
