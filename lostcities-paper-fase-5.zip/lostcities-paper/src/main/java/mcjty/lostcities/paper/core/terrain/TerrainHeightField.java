/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.terrain;

import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.util.DeterministicRandom;

import java.util.Random;

/**
 * Single deterministic terrain + climate + biome field (K1 / DEC-12, C6 enriched).
 * Evaluable in O(1) at any (blockX, blockZ) without loading or generating neighbor chunks,
 * guaranteeing 100% agreement between planner heights, ChunkData blocks, and BiomeProvider.
 * Includes ridge mountains (peaks ~150-190), valleys/cliffs, and climate-driven biomes.
 */
public final class TerrainHeightField {

    public record Sample(
            int height,
            double temperature,
            double humidity,
            String biomeId,
            String topBlock,
            String fillerBlock,
            boolean waterBiome
    ) {}

    private final int seaLevel;
    private final int groundLevel;
    private final DeterministicRandom.PerlinNoise2D continentalNoise;
    private final DeterministicRandom.PerlinNoise2D ridgeNoise;
    private final DeterministicRandom.PerlinNoise2D mountainMaskNoise;
    private final DeterministicRandom.PerlinNoise2D detailNoise;
    private final DeterministicRandom.PerlinNoise2D riverNoise;
    private final DeterministicRandom.PerlinNoise2D temperatureNoise;
    private final DeterministicRandom.PerlinNoise2D humidityNoise;

    public TerrainHeightField(long worldSeed, LostCityProfile profile) {
        this.seaLevel = profile.seaLevel == -1 ? 63 : profile.seaLevel;
        this.groundLevel = profile.groundLevel;
        Random r = new Random(worldSeed ^ 0x243f6a8885a308d3L);
        this.continentalNoise = new DeterministicRandom.PerlinNoise2D(r, 4);
        this.ridgeNoise = new DeterministicRandom.PerlinNoise2D(r, 4);
        this.mountainMaskNoise = new DeterministicRandom.PerlinNoise2D(r, 2);
        this.detailNoise = new DeterministicRandom.PerlinNoise2D(r, 3);
        this.riverNoise = new DeterministicRandom.PerlinNoise2D(r, 2);
        this.temperatureNoise = new DeterministicRandom.PerlinNoise2D(r, 2);
        this.humidityNoise = new DeterministicRandom.PerlinNoise2D(r, 2);
    }

    public int seaLevel() { return seaLevel; }

    public int sampleChunkCenterHeight(ChunkCoord coord) {
        return sample((coord.chunkX() << 4) + 8, (coord.chunkZ() << 4) + 8).height();
    }

    public String sampleChunkCenterBiome(ChunkCoord coord) {
        return sample((coord.chunkX() << 4) + 8, (coord.chunkZ() << 4) + 8).biomeId();
    }

    public Sample sample(int blockX, int blockZ) {
        double cont = continentalNoise.sample(blockX * 0.0019, blockZ * 0.0019);
        double detail = detailNoise.sample(blockX * 0.011, blockZ * 0.011);
        double riverVal = Math.abs(riverNoise.sample(blockX * 0.0032, blockZ * 0.0032));

        // Mountain/ridge uplift: peaks reach ~150-190 in inland mountain belts while keeping valleys & cliffs natural
        double mMaskRaw = mountainMaskNoise.sample(blockX * 0.0014 + 31.7, blockZ * 0.0014 - 19.3);
        double mMask = clamp01((mMaskRaw - 0.05) / 0.50);
        double inlandMask = clamp01((cont + 0.05) / 0.45);
        double ridgeRaw = 1.0 - Math.abs(ridgeNoise.sample(blockX * 0.0042, blockZ * 0.0042));
        double ridge = ridgeRaw * ridgeRaw;
        double mountainLift = mMask * inlandMask * (18.0 + ridge * 102.0);

        // Mild valley carving where ridgeRaw is low in hilly areas
        double valleyCarve = (1.0 - ridgeRaw) * inlandMask * 9.0;

        double rawHeight = groundLevel + cont * 26.0 + detail * 8.5 + mountainLift - valleyCarve;

        boolean isRiver = riverVal < 0.030 && cont > -0.18 && mountainLift < 24.0;
        if (isRiver) {
            double depthFactor = 1.0 - (riverVal / 0.030);
            rawHeight = Math.min(rawHeight, seaLevel - 2.0 - depthFactor * 6.0);
        }
        int height = Math.max(12, Math.min(205, (int) Math.round(rawHeight)));

        double temp = temperatureNoise.sample(blockX * 0.0016, blockZ * 0.0016);
        double humid = humidityNoise.sample(blockX * 0.0016, blockZ * 0.0016);

        // Strictly consistent height <-> biome <-> surface block mapping (zero underwater dry biomes)
        if (isRiver && height <= seaLevel) {
            return new Sample(height, temp, humid, "minecraft:river", "minecraft:sand", "minecraft:dirt", true);
        }
        if (height < seaLevel - 10) {
            return new Sample(height, temp, humid, "minecraft:deep_ocean", "minecraft:gravel", "minecraft:gravel", true);
        }
        if (height < seaLevel) {
            return new Sample(height, temp, humid, "minecraft:ocean", "minecraft:sand", "minecraft:gravel", true);
        }
        if (height <= seaLevel + 2) {
            if (humid > 0.22 && temp > -0.10 && temp < 0.35) {
                return new Sample(height, temp, humid, "minecraft:swamp", "minecraft:grass_block", "minecraft:dirt", false);
            }
            return new Sample(height, temp, humid, "minecraft:beach", "minecraft:sand", "minecraft:sandstone", false);
        }
        if (height >= 145) {
            if (temp < 0.10) {
                return new Sample(height, temp, humid, "minecraft:jagged_peaks", "minecraft:snow_block", "minecraft:stone", false);
            }
            return new Sample(height, temp, humid, "minecraft:stony_peaks", "minecraft:stone", "minecraft:stone", false);
        }
        if (height >= 112) {
            if (temp < 0.05) {
                return new Sample(height, temp, humid, "minecraft:snowy_slopes", "minecraft:snow_block", "minecraft:stone", false);
            }
            return new Sample(height, temp, humid, "minecraft:stony_peaks", "minecraft:stone", "minecraft:stone", false);
        }
        if (height <= seaLevel + 6 && humid > 0.28 && temp > -0.05 && temp < 0.35) {
            return new Sample(height, temp, humid, "minecraft:swamp", "minecraft:grass_block", "minecraft:dirt", false);
        }
        if (temp > 0.32 && humid < -0.22) {
            return new Sample(height, temp, humid, "minecraft:badlands", "minecraft:terracotta", "minecraft:red_sand", false);
        }
        if (temp > 0.22 && humid < -0.08) {
            return new Sample(height, temp, humid, "minecraft:desert", "minecraft:sand", "minecraft:sandstone", false);
        }
        if (temp > 0.20 && humid > 0.22) {
            return new Sample(height, temp, humid, "minecraft:jungle", "minecraft:grass_block", "minecraft:dirt", false);
        }
        if (temp > 0.16 && humid <= 0.10) {
            return new Sample(height, temp, humid, "minecraft:savanna", "minecraft:grass_block", "minecraft:dirt", false);
        }
        if (temp < -0.26) {
            return new Sample(height, temp, humid, "minecraft:snowy_plains", "minecraft:snow_block", "minecraft:dirt", false);
        }
        if (temp < -0.14) {
            return new Sample(height, temp, humid, "minecraft:taiga", "minecraft:grass_block", "minecraft:dirt", false);
        }
        if (humid > 0.14) {
            return new Sample(height, temp, humid, "minecraft:forest", "minecraft:grass_block", "minecraft:dirt", false);
        }
        return new Sample(height, temp, humid, "minecraft:plains", "minecraft:grass_block", "minecraft:dirt", false);
    }

    private static double clamp01(double v) {
        return v <= 0.0 ? 0.0 : (v >= 1.0 ? 1.0 : v);
    }
}
