/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.lost;

import mcjty.lostcities.paper.assets.AssetModels;
import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.util.BoundedCache;

import java.util.Random;

/**
 * Port of {@code mcjty.lostcities.worldgen.lost.CitySphere} preserving exact seeds
 * (961744153L, 837971201L), 16/32 grid rules, 8-neighbor overlap suppression,
 * monorail candidates, and border/containment checks.
 */
public final class CitySphere {

    public static final CitySphere EMPTY = new CitySphere(new ChunkCoord("minecraft:overworld", 0, 0), 0.0f, 0, 0, 0, false);

    private final ChunkCoord center;
    private final int centerX;
    private final int centerY;
    private final int centerZ;
    private final float radius;
    private final boolean enabled;

    private boolean monorailNorthCandidate;
    private boolean monorailSouthCandidate;
    private boolean monorailWestCandidate;
    private boolean monorailEastCandidate;

    private CitySphere(ChunkCoord center, float radius, int centerX, int centerY, int centerZ, boolean enabled) {
        this.center = center;
        this.radius = radius;
        this.centerX = centerX;
        this.centerY = centerY;
        this.centerZ = centerZ;
        this.enabled = enabled;
    }

    public ChunkCoord getCenter() { return center; }
    public int getCenterX() { return centerX; }
    public int getCenterY() { return centerY; }
    public int getCenterZ() { return centerZ; }
    public float getRadius() { return radius; }
    public boolean isEnabled() { return enabled; }
    public boolean isMonorailNorthCandidate() { return monorailNorthCandidate; }
    public boolean isMonorailSouthCandidate() { return monorailSouthCandidate; }
    public boolean isMonorailWestCandidate() { return monorailWestCandidate; }
    public boolean isMonorailEastCandidate() { return monorailEastCandidate; }

    /**
     * Exact seed from {@code CitySphere.initSphere} (L60).
     */
    public static Random createBlockInitRandom(long worldSeed, ChunkCoord center) {
        return new Random(worldSeed + center.chunkX() * 837971201L + center.chunkZ() * 961744153L);
    }

    public static double squaredDistance(int cx, int cz, int x, int z) {
        return (double) (cx - x) * (cx - x) + (double) (cz - z) * (cz - z);
    }

    public static boolean isOnSphereGrid(LostCityProfile profile, int chunkX, int chunkZ) {
        if (profile.grid32) {
            return (chunkX & 0x1f) == 8 && (chunkZ & 0x1f) == 8;
        }
        return (chunkX & 0xf) == 8 && (chunkZ & 0xf) == 8;
    }

    private static float getSphereRadius(ChunkCoord center, LostCityProfile profile, Random rand, AssetModels.PredefinedCityAsset predefCity) {
        if (predefCity != null) {
            return predefCity.radius() * profile.citySphereFactor;
        }
        int range = Math.max(1, profile.cityMaxRadius - profile.cityMinRadius);
        return profile.cityMinRadius + rand.nextInt(range) * profile.citySphereFactor;
    }

    private static int[] getSphereCenterPosition(ChunkCoord center, LostCityProfile profile, Random rand) {
        int cx = (center.chunkX() << 4) + rand.nextInt(16) - 8;
        int cz = (center.chunkZ() << 4) + rand.nextInt(16) - 8;
        return new int[]{cx, profile.groundLevel, cz};
    }

    public static boolean intersectChunkWithSphere(int chunkX, int chunkZ, float radius, int ccX, int ccZ) {
        double sqradiusOffset = (double) radius * radius;
        if (squaredDistance(ccX, ccZ, chunkX * 16, chunkZ * 16) <= sqradiusOffset) return true;
        if (squaredDistance(ccX, ccZ, chunkX * 16 + 15, chunkZ * 16) <= sqradiusOffset) return true;
        if (squaredDistance(ccX, ccZ, chunkX * 16, chunkZ * 16 + 15) <= sqradiusOffset) return true;
        if (squaredDistance(ccX, ccZ, chunkX * 16 + 15, chunkZ * 16 + 15) <= sqradiusOffset) return true;
        return false;
    }

    public boolean fullyContainsChunk(int chunkX, int chunkZ) {
        if (!enabled) return false;
        double sqradiusOffset = (double) (radius - 2.0f) * (radius - 2.0f);
        if (squaredDistance(centerX, centerZ, chunkX * 16, chunkZ * 16) > sqradiusOffset) return false;
        if (squaredDistance(centerX, centerZ, chunkX * 16 + 15, chunkZ * 16) > sqradiusOffset) return false;
        if (squaredDistance(centerX, centerZ, chunkX * 16, chunkZ * 16 + 15) > sqradiusOffset) return false;
        if (squaredDistance(centerX, centerZ, chunkX * 16 + 15, chunkZ * 16 + 15) > sqradiusOffset) return false;
        return true;
    }

    public boolean isOnBorder(int chunkX, int chunkZ) {
        if (!enabled) return false;
        double sqradiusOffset = (double) radius * radius;
        int cnt = 0;
        if (squaredDistance(centerX, centerZ, chunkX * 16, chunkZ * 16) <= sqradiusOffset) cnt++;
        if (squaredDistance(centerX, centerZ, chunkX * 16 + 15, chunkZ * 16) <= sqradiusOffset) cnt++;
        if (squaredDistance(centerX, centerZ, chunkX * 16, chunkZ * 16 + 15) <= sqradiusOffset) cnt++;
        if (squaredDistance(centerX, centerZ, chunkX * 16 + 15, chunkZ * 16 + 15) <= sqradiusOffset) cnt++;
        return cnt > 0 && cnt < 4;
    }

    public boolean isInside(int blockX, int blockZ) {
        return enabled && squaredDistance(centerX, centerZ, blockX, blockZ) <= (double) radius * radius;
    }

    public float getRelativeDistance(ChunkCoord coord) {
        int cx = coord.chunkX() * 16 + 8;
        int cz = coord.chunkZ() * 16 + 8;
        double sqdist = squaredDistance(centerX, centerZ, cx, cz);
        return radius <= 0.0f ? 1.0f : (float) (Math.sqrt(sqdist) / radius);
    }

    public static final class Cache {
        private final long worldSeed;
        private final LostCityProfile profile;
        private final AssetRegistry registry;
        private final BoundedCache<ChunkCoord, CitySphere> cache;

        public Cache(long worldSeed, LostCityProfile profile, AssetRegistry registry, int maxEntries, int ttlSeconds) {
            this.worldSeed = worldSeed;
            this.profile = profile;
            this.registry = registry;
            this.cache = new BoundedCache<>(maxEntries, ttlSeconds);
        }

        public CitySphere getCitySphere(ChunkCoord coord) {
            CitySphere cached = cache.get(coord);
            if (cached != null) {
                return cached;
            }
            if (registry != null) {
                for (AssetModels.PredefinedSphereAsset predef : registry.predefinedSpheres().values()) {
                    if (predef.dimension().equals(coord.dimensionId())) {
                        int px = (predef.chunkX() << 4) + 8;
                        int pz = (predef.chunkZ() << 4) + 8;
                        if (intersectChunkWithSphere(coord.chunkX(), coord.chunkZ(), predef.radius(), px, pz)) {
                            ChunkCoord center = new ChunkCoord(coord.dimensionId(), predef.chunkX(), predef.chunkZ());
                            CitySphere s = computeAtCenter(center, predef);
                            cache.put(coord, s);
                            return s;
                        }
                    }
                }
            }
            CitySphere sphere;
            if (profile.onlyPredefined) {
                sphere = EMPTY;
            } else {
                int cx = (coord.chunkX() & ~0xf) + 8;
                int cz = (coord.chunkZ() & ~0xf) + 8;
                sphere = computeAtCenter(new ChunkCoord(coord.dimensionId(), cx, cz), null);
            }
            cache.put(coord, sphere);
            return sphere;
        }

        private CitySphere computeAtCenter(ChunkCoord center, AssetModels.PredefinedSphereAsset predef) {
            int chunkX = center.chunkX();
            int chunkZ = center.chunkZ();
            // Exact seed from CitySphere.java:381
            Random rand = new Random(worldSeed + chunkX * 961744153L + chunkZ * 837971201L);

            boolean baseEnabled = predef != null || (rand.nextFloat() < profile.citySphereChance && isOnSphereGrid(profile, chunkX, chunkZ));
            float radius = predef != null ? predef.radius() : getSphereRadius(center, profile, rand, null);
            int[] pos = predef != null
                    ? new int[]{(predef.chunkX() << 4) + 8, profile.groundLevel, (predef.chunkZ() << 4) + 8}
                    : getSphereCenterPosition(center, profile, rand);

            boolean finalEnabled = baseEnabled;
            if (predef == null && baseEnabled && !profile.grid32) {
                for (int dx = -16; dx <= 16 && finalEnabled; dx += 16) {
                    for (int dz = -16; dz <= 16 && finalEnabled; dz += 16) {
                        if (dx == 0 && dz == 0) continue;
                        int nx = chunkX + dx;
                        int nz = chunkZ + dz;
                        Random nrand = new Random(worldSeed + nx * 961744153L + nz * 837971201L);
                        boolean nEnabled = nrand.nextFloat() < profile.citySphereChance && isOnSphereGrid(profile, nx, nz);
                        if (!nEnabled) continue;
                        ChunkCoord adjacent = new ChunkCoord(center.dimensionId(), nx, nz);
                        float nRadius = getSphereRadius(adjacent, profile, nrand, null);
                        int[] nPos = getSphereCenterPosition(adjacent, profile, nrand);
                        double dist = Math.hypot((double) pos[0] - nPos[0], (double) pos[2] - nPos[2]);
                        if (dist <= (radius + nRadius) && nRadius > radius) {
                            finalEnabled = false;
                        }
                    }
                }
            }

            CitySphere sphere = new CitySphere(center, radius, pos[0], pos[1], pos[2], finalEnabled);
            if (finalEnabled) {
                sphere.monorailNorthCandidate = rand.nextFloat() < profile.monorailChance;
                sphere.monorailSouthCandidate = rand.nextFloat() < profile.monorailChance;
                sphere.monorailWestCandidate = rand.nextFloat() < profile.monorailChance;
                sphere.monorailEastCandidate = rand.nextFloat() < profile.monorailChance;
            }
            return sphere;
        }

        public boolean hasHorizontalMonorail(ChunkCoord coord) {
            int chunkX = coord.chunkX();
            int chunkZ = coord.chunkZ();
            if ((chunkZ & 0xf) != 8) return false;
            boolean rightOk = false;
            for (int cx = chunkX + 1; cx < chunkX + 64; cx++) {
                if ((cx & 0xf) == 8) {
                    CitySphere s = getCitySphere(new ChunkCoord(coord.dimensionId(), cx, chunkZ));
                    if (s.isEnabled()) {
                        if (!s.monorailWestCandidate) return false;
                        rightOk = true;
                        break;
                    }
                }
            }
            if (!rightOk) return false;
            for (int cx = chunkX - 1; cx > chunkX - 64; cx--) {
                if ((cx & 0xf) == 8) {
                    CitySphere s = getCitySphere(new ChunkCoord(coord.dimensionId(), cx, chunkZ));
                    if (s.isEnabled()) {
                        return s.monorailEastCandidate;
                    }
                }
            }
            return false;
        }

        public boolean hasVerticalMonorail(ChunkCoord coord) {
            int chunkX = coord.chunkX();
            int chunkZ = coord.chunkZ();
            if ((chunkX & 0xf) != 8) return false;
            boolean southOk = false;
            for (int cz = chunkZ + 1; cz < chunkZ + 64; cz++) {
                if ((cz & 0xf) == 8) {
                    CitySphere s = getCitySphere(new ChunkCoord(coord.dimensionId(), chunkX, cz));
                    if (s.isEnabled()) {
                        if (!s.monorailNorthCandidate) return false;
                        southOk = true;
                        break;
                    }
                }
            }
            if (!southOk) return false;
            for (int cz = chunkZ - 1; cz > chunkZ - 64; cz--) {
                if ((cz & 0xf) == 8) {
                    CitySphere s = getCitySphere(new ChunkCoord(coord.dimensionId(), chunkX, cz));
                    if (s.isEnabled()) {
                        return s.monorailSouthCandidate;
                    }
                }
            }
            return false;
        }

        public boolean hasMonorailStation(ChunkCoord coord) {
            CitySphere s = getCitySphere(coord);
            if (!s.fullyContainsChunk(coord.chunkX(), coord.chunkZ())) return false;
            return isNonStationMonorail(coord.west()) || isNonStationMonorail(coord.east())
                    || isNonStationMonorail(coord.north()) || isNonStationMonorail(coord.south());
        }

        private boolean isNonStationMonorail(ChunkCoord coord) {
            CitySphere s = getCitySphere(coord);
            if (s.fullyContainsChunk(coord.chunkX(), coord.chunkZ())) return false;
            return hasHorizontalMonorail(coord) || hasVerticalMonorail(coord);
        }

        public void clear() { cache.clear(); }
    }
}
