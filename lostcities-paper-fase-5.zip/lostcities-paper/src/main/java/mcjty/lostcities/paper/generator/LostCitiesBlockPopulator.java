/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.generator;

import mcjty.lostcities.paper.LostCitiesPlugin;
import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.core.BuildingInfo;
import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.core.ChunkDriver;
import mcjty.lostcities.paper.core.GenerationContext;
import mcjty.lostcities.paper.core.gen.StructureGenerators;
import mcjty.lostcities.paper.core.highway.HighwayModels.HighwayInfo;
import org.bukkit.generator.BlockPopulator;
import org.bukkit.generator.LimitedRegion;
import org.bukkit.generator.WorldInfo;
import org.jetbrains.annotations.NotNull;

import java.util.Map;
import java.util.Random;

/**
 * Primary Paper {@link BlockPopulator} executing LostCities city, building, street,
 * railway, corridor, and highway synthesis inside {@link LimitedRegion} (DEC-01).
 */
public final class LostCitiesBlockPopulator extends BlockPopulator {

    private final LostCitiesPlugin plugin;
    private final String profileName;

    public LostCitiesBlockPopulator(LostCitiesPlugin plugin, String profileName) {
        this.plugin = plugin;
        this.profileName = profileName;
    }

    @Override
    public void populate(@NotNull WorldInfo worldInfo, @NotNull Random random, int chunkX, int chunkZ, @NotNull LimitedRegion limitedRegion) {
        long start = System.nanoTime();
        try {
            WorldDimensionState state = plugin.getOrCreateDimensionState(worldInfo, profileName);
            AssetRegistry registry = plugin.getAssetRegistry();
            LimitedRegionSurface surface = new LimitedRegionSurface(worldInfo, limitedRegion);

            Map<Long, String> crossChunk = state.terrainFeature().generateChunk(
                    surface, chunkX, chunkZ, registry, state.chunkPlanner(), state.city(), state.heightField(), state.multiChunkCache(),
                    new mcjty.lostcities.paper.core.LostCityTerrainFeature.LootSpawnerSink() {
                        @Override
                        public void onLootBlock(int worldX, int y, int worldZ, String conditionName, BuildingInfo info) {
                            plugin.getLootBridge().scheduleChestLoot(worldInfo.getUID(), worldX, y, worldZ, conditionName, info);
                        }

                        @Override
                        public void onSpawnerBlock(int worldX, int y, int worldZ, String conditionName, BuildingInfo info) {
                            plugin.getLootBridge().scheduleSpawner(worldInfo.getUID(), worldX, y, worldZ, conditionName, info);
                        }
                    }
            );

            // Overlay highways, railways, and corridors using the same deterministic context
            try (GenerationContext.Scope ignored = GenerationContext.open(
                    worldInfo.getSeed(), "lostcities:" + worldInfo.getName(), chunkX, chunkZ)) {
                ChunkDriver driver = GenerationContext.current().driver();
                driver.begin(surface, chunkX, chunkZ);
                ChunkCoord coord = new ChunkCoord("lostcities:" + worldInfo.getName(), chunkX, chunkZ);
                BuildingInfo info = state.getBuildingInfo(chunkX, chunkZ, registry);

                if (state.highwayService() != null) {
                    HighwayInfo hw = state.highwayService().getHighwayInfo(chunkX, chunkZ);
                    StructureGenerators.generateHighways(driver, info, hw);
                }
                if (info.isCity && info.getRailInfo().type() != mcjty.lostcities.paper.core.lost.RailChunkType.NONE) {
                    StructureGenerators.generateRailways(driver, info);
                }
                if (info.isCity) {
                    StructureGenerators.generateCorridors(driver, info);
                }
                StructureGenerators.generateStuff(driver, info);
                Map<Long, String> extraCross = driver.flush();
                crossChunk.putAll(extraCross);
            }

            // Enqueue any out-of-bounds writes into GlobalTodo (never load neighbor chunks!)
            for (Map.Entry<Long, String> e : crossChunk.entrySet()) {
                long p = e.getKey();
                int wx = ChunkDriver.unpackX(p);
                int wy = ChunkDriver.unpackY(p);
                int wz = ChunkDriver.unpackZ(p);
                String blockId = e.getValue();
                plugin.getGlobalTodo().enqueue(worldInfo.getUID(), wx >> 4, wz >> 4, world -> {
                    if (wy >= world.getMinHeight() && wy < world.getMaxHeight()) {
                        world.getBlockAt(wx, wy, wz).setBlockData(LimitedRegionSurface.parseBlockData(blockId), false);
                    }
                });
            }
        } finally {
            plugin.getMetrics().recordChunkNanos(System.nanoTime() - start);
        }
    }
}
