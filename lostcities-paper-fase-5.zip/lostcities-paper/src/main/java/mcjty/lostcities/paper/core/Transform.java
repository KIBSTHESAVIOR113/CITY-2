/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 16x16 building part coordinate & blockstate transformations (port of LostCities {@code Transform}).
 * Supports rotation and mirroring of Directional, Stairs, Door (facing + hinge), Rail, Wall,
 * Fence/MultipleFacing, Orientable (axis), and Rotatable (0..15) blockstate properties.
 */
public enum Transform {
    ROTATE_NONE(0, false, false),
    ROTATE_90(90, false, false),
    ROTATE_180(180, false, false),
    ROTATE_270(270, false, false),
    MIRROR_X(0, true, false),
    MIRROR_Z(0, false, true),
    MIRROR_90_X(90, true, false);

    private final int degrees;
    private final boolean mirrorX;
    private final boolean mirrorZ;

    Transform(int degrees, boolean mirrorX, boolean mirrorZ) {
        this.degrees = degrees;
        this.mirrorX = mirrorX;
        this.mirrorZ = mirrorZ;
    }

    public int degrees() { return degrees; }
    public boolean isMirrored() { return mirrorX || mirrorZ; }

    public int rotateX(int x, int z) {
        return switch (this) {
            case ROTATE_NONE -> x;
            case ROTATE_90 -> 15 - z;
            case ROTATE_180 -> 15 - x;
            case ROTATE_270 -> z;
            case MIRROR_X -> 15 - x;
            case MIRROR_Z -> x;
            case MIRROR_90_X -> z;
        };
    }

    public int rotateZ(int x, int z) {
        return switch (this) {
            case ROTATE_NONE -> z;
            case ROTATE_90 -> x;
            case ROTATE_180 -> 15 - z;
            case ROTATE_270 -> 15 - x;
            case MIRROR_X -> z;
            case MIRROR_Z -> 15 - z;
            case MIRROR_90_X -> x;
        };
    }

    public int mapX(int x, int z) { return rotateX(x, z); }
    public int mapZ(int x, int z) { return rotateZ(x, z); }

    public static Transform fromIndex(int idx) {
        return switch (Math.floorMod(idx, 4)) {
            case 0 -> ROTATE_NONE;
            case 1 -> ROTATE_90;
            case 2 -> ROTATE_180;
            default -> ROTATE_270;
        };
    }

    /**
     * Transforms a Minecraft blockstate string (e.g. {@code minecraft:oak_stairs[facing=north,half=bottom]})
     * according to this rotation/mirror.
     */
    public String transformBlockState(String blockId) {
        if (this == ROTATE_NONE || blockId == null) return blockId;
        int lb = blockId.indexOf('[');
        int rb = blockId.lastIndexOf(']');
        if (lb < 0 || rb <= lb) return blockId;

        String base = blockId.substring(0, lb);
        String propsRaw = blockId.substring(lb + 1, rb);
        Map<String, String> props = new LinkedHashMap<>();
        for (String token : propsRaw.split(",")) {
            int eq = token.indexOf('=');
            if (eq > 0) {
                props.put(token.substring(0, eq).trim(), token.substring(eq + 1).trim());
            }
        }
        if (props.isEmpty()) return blockId;

        // 1. Directional facing (Stairs, Door, Furnace, WallTorch, TrapDoor, Chest, Ladder, etc.)
        if (props.containsKey("facing")) {
            props.put("facing", mapFacing(props.get("facing")));
        }

        // 2. Door hinge flips when mirrored
        if (isMirrored() && props.containsKey("hinge")) {
            String h = props.get("hinge");
            if ("left".equals(h)) props.put("hinge", "right");
            else if ("right".equals(h)) props.put("hinge", "left");
        }

        // 3. Orientable axis (x <-> z on 90/270/MIRROR_90_X)
        if (props.containsKey("axis")) {
            String axis = props.get("axis");
            if (degrees == 90 || degrees == 270) {
                if ("x".equals(axis)) props.put("axis", "z");
                else if ("z".equals(axis)) props.put("axis", "x");
            }
        }

        // 4. Rail shape
        if (props.containsKey("shape") && base.contains("rail")) {
            props.put("shape", mapRailShape(props.get("shape")));
        }

        // 5. MultipleFacing / Wall (north/east/south/west keys)
        if (props.containsKey("north") || props.containsKey("east") || props.containsKey("south") || props.containsKey("west")) {
            Map<String, String> remapped = new LinkedHashMap<>();
            for (String dir : new String[]{"north", "east", "south", "west"}) {
                if (props.containsKey(dir)) {
                    remapped.put(mapFacing(dir), props.get(dir));
                }
            }
            for (Map.Entry<String, String> e : remapped.entrySet()) {
                props.put(e.getKey(), e.getValue());
            }
        }

        // 6. Rotatable (0..15)
        if (props.containsKey("rotation")) {
            try {
                int rot = Integer.parseInt(props.get("rotation"));
                props.put("rotation", Integer.toString(mapRotation16(rot)));
            } catch (NumberFormatException ignored) {
            }
        }

        StringBuilder sb = new StringBuilder(base).append('[');
        boolean first = true;
        for (Map.Entry<String, String> e : props.entrySet()) {
            if (!first) sb.append(',');
            first = false;
            sb.append(e.getKey()).append('=').append(e.getValue());
        }
        sb.append(']');
        return sb.toString();
    }

    public String mapFacing(String dir) {
        if (dir == null) return null;
        return switch (this) {
            case ROTATE_NONE -> dir;
            case ROTATE_90 -> switch (dir) {
                case "north" -> "east";
                case "east" -> "south";
                case "south" -> "west";
                case "west" -> "north";
                default -> dir;
            };
            case ROTATE_180 -> switch (dir) {
                case "north" -> "south";
                case "east" -> "west";
                case "south" -> "north";
                case "west" -> "east";
                default -> dir;
            };
            case ROTATE_270 -> switch (dir) {
                case "north" -> "west";
                case "west" -> "south";
                case "south" -> "east";
                case "east" -> "north";
                default -> dir;
            };
            case MIRROR_X -> switch (dir) {
                case "east" -> "west";
                case "west" -> "east";
                default -> dir;
            };
            case MIRROR_Z -> switch (dir) {
                case "north" -> "south";
                case "south" -> "north";
                default -> dir;
            };
            case MIRROR_90_X -> switch (dir) {
                case "north" -> "west";
                case "west" -> "north";
                case "south" -> "east";
                case "east" -> "south";
                default -> dir;
            };
        };
    }

    private String mapRailShape(String shape) {
        if (shape == null) return null;
        if (shape.startsWith("ascending_")) {
            return "ascending_" + mapFacing(shape.substring("ascending_".length()));
        }
        if ("north_south".equals(shape) || "east_west".equals(shape)) {
            return (degrees == 90 || degrees == 270)
                    ? ("north_south".equals(shape) ? "east_west" : "north_south")
                    : shape;
        }
        String[] parts = shape.split("_");
        if (parts.length == 2) {
            String a = mapFacing(parts[0]);
            String b = mapFacing(parts[1]);
            // Canonical Minecraft rail corner order: (north|south)_(east|west)
            if ("east".equals(a) || "west".equals(a)) {
                return b + "_" + a;
            }
            return a + "_" + b;
        }
        return shape;
    }

    private int mapRotation16(int rot) {
        int r = Math.floorMod(rot, 16);
        return switch (this) {
            case ROTATE_NONE -> r;
            case ROTATE_90 -> (r + 4) & 15;
            case ROTATE_180 -> (r + 8) & 15;
            case ROTATE_270 -> (r + 12) & 15;
            case MIRROR_X -> (16 - r) & 15;
            case MIRROR_Z -> (8 - r) & 15;
            case MIRROR_90_X -> (12 - r) & 15;
        };
    }
}
