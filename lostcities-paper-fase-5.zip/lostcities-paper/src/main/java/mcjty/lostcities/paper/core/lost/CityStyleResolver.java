/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.lost;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import mcjty.lostcities.paper.assets.AssetModels;
import mcjty.lostcities.paper.assets.AssetRegistry;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * Resolves {@link AssetModels.CityStyleAsset} inheritance chains and weighted building /
 * multibuilding / front-part selectors and style overrides from JSON.
 */
public final class CityStyleResolver {

    private CityStyleResolver() {
    }

    public record WeightedEntry(float factor, String value) {}

    public static String selectRandomBuilding(AssetRegistry registry, String cityStyleId, Random rand) {
        List<WeightedEntry> entries = collectSelector(registry, cityStyleId, "buildings");
        String picked = pickWeighted(entries, rand);
        if (picked != null) return picked;
        return registry.buildings().isEmpty() ? "" : registry.buildings().keySet().iterator().next();
    }

    public static List<String> listAllowedMultiBuildings(AssetRegistry registry, String cityStyleId) {
        List<WeightedEntry> entries = collectSelector(registry, cityStyleId, "multibuildings");
        List<String> out = new ArrayList<>();
        for (WeightedEntry e : entries) {
            out.add(e.value());
        }
        return out;
    }

    public static String selectRandomFront(AssetRegistry registry, String cityStyleId, Random rand) {
        return pickWeighted(collectSelector(registry, cityStyleId, "fronts"), rand);
    }

    public static float resolveCorridorChance(AssetRegistry registry, String cityStyleId, float defaultChance) {
        Set<String> visited = new LinkedHashSet<>();
        String cur = cityStyleId;
        while (cur != null && !cur.isBlank() && visited.add(cur)) {
            AssetModels.CityStyleAsset cs = registry.getCityStyle(cur);
            if (cs == null) break;
            JsonObject raw = cs.raw();
            if (raw != null) {
                if (raw.has("corridorchance") && raw.get("corridorchance").isJsonPrimitive()) {
                    return raw.get("corridorchance").getAsFloat();
                }
                if (raw.has("corridorblocks") && raw.get("corridorblocks").isJsonObject()) {
                    JsonObject cb = raw.getAsJsonObject("corridorblocks");
                    if (cb.has("corridorchance") && cb.get("corridorchance").isJsonPrimitive()) {
                        return cb.get("corridorchance").getAsFloat();
                    }
                }
            }
            cur = cs.inherit();
        }
        return defaultChance;
    }

    public static String resolveBorderBlock(AssetRegistry registry, String cityStyleId, String fallback) {
        Set<String> visited = new LinkedHashSet<>();
        String cur = cityStyleId;
        while (cur != null && !cur.isBlank() && visited.add(cur)) {
            AssetModels.CityStyleAsset cs = registry.getCityStyle(cur);
            if (cs == null) break;
            JsonObject raw = cs.raw();
            if (raw != null && raw.has("streetblocks") && raw.get("streetblocks").isJsonObject()) {
                JsonObject sb = raw.getAsJsonObject("streetblocks");
                if (sb.has("border") && sb.get("border").isJsonPrimitive()) {
                    String b = sb.get("border").getAsString();
                    if (!b.isBlank()) return b;
                }
            }
            cur = cs.inherit();
        }
        return fallback;
    }

    public static String resolveStyleId(AssetRegistry registry, String cityStyleId) {
        Set<String> visited = new LinkedHashSet<>();
        String cur = cityStyleId;
        while (cur != null && !cur.isBlank() && visited.add(cur)) {
            AssetModels.CityStyleAsset cs = registry.getCityStyle(cur);
            if (cs == null) break;
            if (cs.style() != null && !cs.style().isBlank()) return cs.style();
            cur = cs.inherit();
        }
        return registry.styles().isEmpty() ? "" : registry.styles().keySet().iterator().next();
    }

    public static List<WeightedEntry> collectSelector(AssetRegistry registry, String cityStyleId, String selectorKey) {
        List<WeightedEntry> result = new ArrayList<>();
        Set<String> visited = new LinkedHashSet<>();
        String cur = cityStyleId;
        while (cur != null && !cur.isBlank() && visited.add(cur)) {
            AssetModels.CityStyleAsset cs = registry.getCityStyle(cur);
            if (cs == null) break;
            JsonObject raw = cs.raw();
            if (raw != null && raw.has("selectors") && raw.get("selectors").isJsonObject()) {
                JsonObject sel = raw.getAsJsonObject("selectors");
                if (sel.has(selectorKey) && sel.get(selectorKey).isJsonArray()) {
                    for (JsonElement el : sel.getAsJsonArray(selectorKey)) {
                        if (!el.isJsonObject()) continue;
                        JsonObject item = el.getAsJsonObject();
                        float factor = item.has("factor") ? item.get("factor").getAsFloat() : 1.0f;
                        String val = item.has("value") ? item.get("value").getAsString() : "";
                        if (!val.isBlank() && factor > 0.0f) {
                            result.add(new WeightedEntry(factor, val));
                        }
                    }
                }
            }
            cur = cs.inherit();
        }
        return result;
    }

    private static String pickWeighted(List<WeightedEntry> list, Random rand) {
        if (list.isEmpty()) return null;
        float total = 0.0f;
        for (WeightedEntry e : list) total += e.factor();
        if (total <= 0.0f) return list.get(0).value();
        float roll = rand.nextFloat() * total;
        float acc = 0.0f;
        for (WeightedEntry e : list) {
            acc += e.factor();
            if (roll <= acc) return e.value();
        }
        return list.get(list.size() - 1).value();
    }
}
