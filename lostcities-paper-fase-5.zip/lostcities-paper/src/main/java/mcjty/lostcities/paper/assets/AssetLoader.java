/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.assets;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import mcjty.lostcities.paper.assets.AssetModels.*;
import mcjty.lostcities.paper.util.PathSecurity;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Logger;
import java.util.stream.Stream;

/**
 * Loads all 13 LostCities JSON asset registries from a base directory (built-in resources
 * extracted to disk) overlaid by admin overrides (DEC-06: admin folder wins).
 * Corrupted files are logged with file+field context and skipped without crashing.
 */
public final class AssetLoader {

    private final Path assetsRoot;
    private final long maxJsonBytes;
    private final Logger logger;

    public AssetLoader(Path assetsRoot, long maxJsonBytes, Logger logger) {
        this.assetsRoot = assetsRoot.toAbsolutePath().normalize();
        this.maxJsonBytes = maxJsonBytes;
        this.logger = logger;
    }

    public AssetRegistry loadAll() {
        Map<String, PartAsset> parts = loadCategory("parts", this::parsePart);
        Map<String, BuildingAsset> buildings = loadCategory("buildings", this::parseBuilding);
        Map<String, MultiBuildingAsset> multiBuildings = loadCategory("multibuildings", this::parseMultiBuilding);
        Map<String, VariantAsset> variants = loadCategory("variants", this::parseVariant);
        Map<String, PaletteAsset> palettes = loadCategory("palettes", this::parsePalette);
        Map<String, StyleAsset> styles = loadCategory("styles", this::parseStyle);
        Map<String, CityStyleAsset> cityStyles = loadCategory("citystyles", this::parseCityStyle);
        Map<String, ScatteredAsset> scattered = loadCategory("scattered", this::parseScattered);
        Map<String, StuffAsset> stuff = loadCategory("stuff", this::parseStuff);
        Map<String, ConditionAsset> conditions = loadCategory("conditions", this::parseCondition);
        Map<String, WorldStyleAsset> worldStyles = loadCategory("worldstyles", this::parseWorldStyle);
        Map<String, PredefinedCityAsset> predefinedCities = loadCategory("predefinedcities", this::parsePredefinedCity);
        Map<String, PredefinedSphereAsset> predefinedSpheres = loadCategory("predefinedspheres", this::parsePredefinedSphere);

        AssetRegistry registry = new AssetRegistry(
                parts, buildings, multiBuildings, variants, palettes, styles, cityStyles,
                scattered, stuff, conditions, worldStyles, predefinedCities, predefinedSpheres
        );
        for (String w : AssetValidator.validateCrossReferences(registry)) {
            logger.warning(w);
        }
        return registry;
    }

    @FunctionalInterface
    private interface AssetParser<T> {
        T parse(String id, JsonObject obj, String fileCtx);
    }

    private <T> Map<String, T> loadCategory(String folderName, AssetParser<T> parser) {
        Map<String, T> result = new LinkedHashMap<>();
        Path dir = PathSecurity.resolveInside(assetsRoot, folderName);
        if (!Files.isDirectory(dir)) {
            return result;
        }
        List<Path> files;
        try (Stream<Path> stream = Files.list(dir)) {
            files = stream
                    .filter(p -> Files.isRegularFile(p) && p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".json"))
                    .sorted()
                    .toList();
        } catch (IOException ex) {
            logger.warning("Failed to scan asset directory '" + folderName + "': " + ex.getMessage());
            return result;
        }

        for (Path file : files) {
            String fileName = file.getFileName().toString();
            String baseName = fileName.substring(0, fileName.length() - 5);
            String fileCtx = folderName + "/" + fileName;
            try {
                String safeName = PathSecurity.validateSafeName(baseName, folderName);
                String id = "lostcities:" + safeName;
                String json = PathSecurity.readBoundedUtf8(file, maxJsonBytes);
                JsonElement el = JsonParser.parseString(json);
                if (!el.isJsonObject()) {
                    throw new AssetValidator.ValidationException(fileCtx, "<root>", "expected JSON object");
                }
                T parsed = parser.parse(id, el.getAsJsonObject(), fileCtx);
                result.put(id, parsed);
            } catch (Exception ex) {
                logger.warning("Skipping invalid asset [" + fileCtx + "]: " + ex.getMessage());
            }
        }
        return result;
    }

    private PartAsset parsePart(String id, JsonObject obj, String fileCtx) {
        int xSize = AssetValidator.requirePositiveInt(obj, "xsize", fileCtx, 16);
        int zSize = AssetValidator.requirePositiveInt(obj, "zsize", fileCtx, 16);
        AssetValidator.requireArray(obj, "slices", fileCtx);
        List<List<String>> slices = new ArrayList<>();
        for (JsonElement sliceEl : obj.getAsJsonArray("slices")) {
            if (!sliceEl.isJsonArray()) {
                throw new AssetValidator.ValidationException(fileCtx, "slices", "each slice must be an array of strings");
            }
            List<String> rows = new ArrayList<>();
            for (JsonElement rowEl : sliceEl.getAsJsonArray()) {
                rows.add(rowEl.getAsString());
            }
            slices.add(List.copyOf(rows));
        }
        Map<String, Object> meta = new LinkedHashMap<>();
        if (obj.has("meta") && obj.get("meta").isJsonArray()) {
            for (JsonElement mEl : obj.getAsJsonArray("meta")) {
                if (mEl.isJsonObject()) {
                    JsonObject mo = mEl.getAsJsonObject();
                    String key = optStr(mo, "key", "");
                    if (!key.isEmpty()) {
                        if (mo.has("boolean")) meta.put(key, mo.get("boolean").getAsBoolean());
                        else if (mo.has("chr")) meta.put(key, mo.get("chr").getAsString());
                        else if (mo.has("str")) meta.put(key, mo.get("str").getAsString());
                        else if (mo.has("integer")) meta.put(key, mo.get("integer").getAsInt());
                        else if (mo.has("float")) meta.put(key, mo.get("float").getAsFloat());
                    }
                }
            }
        }
        String refPal = optStr(obj, "refpalette", "");
        return new PartAsset(id, xSize, slices.size(), zSize, refPal, List.copyOf(slices), Map.copyOf(meta), obj);
    }

    private BuildingAsset parseBuilding(String id, JsonObject obj, String fileCtx) {
        String filler = optStr(obj, "filler", "#");
        String rubble = optStr(obj, "rubble", "}");
        String refPal = optStr(obj, "refpalette", "");
        int minFloors = optInt(obj, "minfloors", -1);
        int maxFloors = optInt(obj, "maxfloors", -1);
        int minCellars = optInt(obj, "mincellars", -1);
        int maxCellars = optInt(obj, "maxcellars", -1);
        float prefersLonely = optFloat(obj, "preferslonely", 0.0f);
        boolean allowDoors = optBool(obj, "allowdoors", true);
        List<JsonObject> parts = readObjList(obj, "parts");
        List<JsonObject> parts2 = readObjList(obj, "parts2");
        if (parts.isEmpty()) {
            throw new AssetValidator.ValidationException(fileCtx, "parts", "building must declare at least one part rule");
        }
        return new BuildingAsset(id, filler, rubble, refPal, minFloors, maxFloors, minCellars, maxCellars,
                prefersLonely, allowDoors, parts, parts2, obj);
    }

    private MultiBuildingAsset parseMultiBuilding(String id, JsonObject obj, String fileCtx) {
        int dimX = AssetValidator.requirePositiveInt(obj, "dimx", fileCtx, 2);
        int dimZ = AssetValidator.requirePositiveInt(obj, "dimz", fileCtx, 2);
        AssetValidator.requireArray(obj, "buildings", fileCtx);
        List<List<String>> grid = new ArrayList<>();
        for (JsonElement rowEl : obj.getAsJsonArray("buildings")) {
            List<String> row = new ArrayList<>();
            if (rowEl.isJsonArray()) {
                for (JsonElement cell : rowEl.getAsJsonArray()) {
                    row.add(cell.getAsString());
                }
            }
            grid.add(List.copyOf(row));
        }
        return new MultiBuildingAsset(id, dimX, dimZ, List.copyOf(grid), obj);
    }

    private VariantAsset parseVariant(String id, JsonObject obj, String fileCtx) {
        AssetValidator.requireArray(obj, "blocks", fileCtx);
        List<WeightedBlock> blocks = new ArrayList<>();
        for (JsonElement el : obj.getAsJsonArray("blocks")) {
            if (el.isJsonObject()) {
                JsonObject bo = el.getAsJsonObject();
                blocks.add(new WeightedBlock(optInt(bo, "random", 1), optStr(bo, "block", "minecraft:stone")));
            }
        }
        return new VariantAsset(id, List.copyOf(blocks), obj);
    }

    private PaletteAsset parsePalette(String id, JsonObject obj, String fileCtx) {
        AssetValidator.requireArray(obj, "palette", fileCtx);
        List<PaletteEntryModel> entries = new ArrayList<>();
        for (JsonElement el : obj.getAsJsonArray("palette")) {
            if (!el.isJsonObject()) continue;
            JsonObject eo = el.getAsJsonObject();
            String chStr = optStr(eo, "char", "");
            if (chStr.isEmpty()) {
                throw new AssetValidator.ValidationException(fileCtx, "palette[].char", "missing palette character");
            }
            List<WeightedBlock> randBlocks = new ArrayList<>();
            if (eo.has("blocks") && eo.get("blocks").isJsonArray()) {
                for (JsonElement bEl : eo.getAsJsonArray("blocks")) {
                    if (bEl.isJsonObject()) {
                        JsonObject bo = bEl.getAsJsonObject();
                        randBlocks.add(new WeightedBlock(optInt(bo, "random", 1), optStr(bo, "block", "minecraft:stone")));
                    }
                }
            }
            entries.add(new PaletteEntryModel(
                    chStr.charAt(0),
                    optStr(eo, "block", ""),
                    optStr(eo, "variant", ""),
                    optStr(eo, "frompalette", ""),
                    optStr(eo, "loot", ""),
                    optStr(eo, "mob", ""),
                    optBool(eo, "torch", false),
                    eo.has("damaged"),
                    List.copyOf(randBlocks)
            ));
        }
        return new PaletteAsset(id, List.copyOf(entries), obj);
    }

    private StyleAsset parseStyle(String id, JsonObject obj, String fileCtx) {
        List<List<WeightedRef>> groups = new ArrayList<>();
        if (obj.has("randompalettes") && obj.get("randompalettes").isJsonArray()) {
            for (JsonElement grpEl : obj.getAsJsonArray("randompalettes")) {
                List<WeightedRef> group = new ArrayList<>();
                if (grpEl.isJsonArray()) {
                    for (JsonElement item : grpEl.getAsJsonArray()) {
                        if (item.isJsonObject()) {
                            JsonObject io = item.getAsJsonObject();
                            group.add(new WeightedRef(optFloat(io, "factor", 1.0f), optStr(io, "palette", "")));
                        }
                    }
                }
                groups.add(List.copyOf(group));
            }
        }
        return new StyleAsset(id, List.copyOf(groups), obj);
    }

    private CityStyleAsset parseCityStyle(String id, JsonObject obj, String fileCtx) {
        JsonObject streetBlocks = obj.has("streetblocks") && obj.get("streetblocks").isJsonObject()
                ? obj.getAsJsonObject("streetblocks") : new JsonObject();
        JsonObject parkBlocks = obj.has("parkblocks") && obj.get("parkblocks").isJsonObject()
                ? obj.getAsJsonObject("parkblocks") : new JsonObject();
        JsonObject corridorBlocks = obj.has("corridorblocks") && obj.get("corridorblocks").isJsonObject()
                ? obj.getAsJsonObject("corridorblocks") : new JsonObject();
        return new CityStyleAsset(
                id,
                optStr(obj, "inherit", ""),
                optStr(obj, "style", ""),
                optStr(streetBlocks, "street", ""),
                optStr(streetBlocks, "streetbase", ""),
                optStr(parkBlocks, "elevation", ""),
                optStr(corridorBlocks, "roof", ""),
                optStr(corridorBlocks, "glass", ""),
                obj
        );
    }

    private ScatteredAsset parseScattered(String id, JsonObject obj, String fileCtx) {
        List<String> bList = new ArrayList<>();
        if (obj.has("buildings") && obj.get("buildings").isJsonArray()) {
            for (JsonElement el : obj.getAsJsonArray("buildings")) {
                bList.add(el.getAsString());
            }
        }
        return new ScatteredAsset(
                id,
                List.copyOf(bList),
                optStr(obj, "multibuilding", ""),
                optStr(obj, "terrainheight", "average"),
                optStr(obj, "terrainfix", "none"),
                optInt(obj, "heightoffset", 0),
                obj
        );
    }

    private StuffAsset parseStuff(String id, JsonObject obj, String fileCtx) {
        List<String> tags = new ArrayList<>();
        if (obj.has("tags") && obj.get("tags").isJsonArray()) {
            for (JsonElement el : obj.getAsJsonArray("tags")) {
                tags.add(el.getAsString());
            }
        }
        return new StuffAsset(id, List.copyOf(tags), optInt(obj, "mincount", 1),
                optInt(obj, "maxcount", 1), optInt(obj, "attempts", 1), obj);
    }

    private ConditionAsset parseCondition(String id, JsonObject obj, String fileCtx) {
        AssetValidator.requireArray(obj, "values", fileCtx);
        List<ConditionRule> rules = new ArrayList<>();
        for (JsonElement el : obj.getAsJsonArray("values")) {
            if (!el.isJsonObject()) continue;
            JsonObject ro = el.getAsJsonObject();
            Integer rMin = null;
            Integer rMax = null;
            if (ro.has("range") && ro.get("range").isJsonPrimitive()) {
                String[] parts = ro.get("range").getAsString().split(",");
                if (parts.length == 2) {
                    rMin = Integer.parseInt(parts[0].trim());
                    rMax = Integer.parseInt(parts[1].trim());
                }
            }
            rules.add(new ConditionRule(
                    optFloat(ro, "factor", 1.0f),
                    optStr(ro, "value", ""),
                    ro.has("top") ? ro.get("top").getAsBoolean() : null,
                    ro.has("ground") ? ro.get("ground").getAsBoolean() : null,
                    ro.has("cellar") ? ro.get("cellar").getAsBoolean() : null,
                    ro.has("isbuilding") ? ro.get("isbuilding").getAsBoolean() : null,
                    ro.has("issphere") ? ro.get("issphere").getAsBoolean() : null,
                    rMin, rMax,
                    optStr(ro, "inpart", ""),
                    optStr(ro, "inbuilding", ""),
                    optStr(ro, "inbiome", "")
            ));
        }
        return new ConditionAsset(id, List.copyOf(rules), obj);
    }

    private WorldStyleAsset parseWorldStyle(String id, JsonObject obj, String fileCtx) {
        return new WorldStyleAsset(
                id,
                optStr(obj, "outsidestyle", ""),
                readObjList(obj, "citystyles"),
                readObjList(obj, "citybiomemultipliers"),
                obj
        );
    }

    private PredefinedCityAsset parsePredefinedCity(String id, JsonObject obj, String fileCtx) {
        return new PredefinedCityAsset(
                id,
                optStr(obj, "dimension", "minecraft:overworld"),
                optInt(obj, "chunkx", 0),
                optInt(obj, "chunkz", 0),
                optInt(obj, "radius", 50),
                optStr(obj, "citystyle", ""),
                obj
        );
    }

    private PredefinedSphereAsset parsePredefinedSphere(String id, JsonObject obj, String fileCtx) {
        return new PredefinedSphereAsset(
                id,
                optStr(obj, "dimension", "minecraft:overworld"),
                optInt(obj, "chunkx", 0),
                optInt(obj, "chunkz", 0),
                optInt(obj, "centery", 65),
                optInt(obj, "radius", 50),
                optBool(obj, "usable", true),
                obj
        );
    }

    private static List<JsonObject> readObjList(JsonObject obj, String field) {
        List<JsonObject> list = new ArrayList<>();
        if (obj.has(field) && obj.get(field).isJsonArray()) {
            JsonArray arr = obj.getAsJsonArray(field);
            for (JsonElement el : arr) {
                if (el.isJsonObject()) {
                    list.add(el.getAsJsonObject());
                }
            }
        }
        return List.copyOf(list);
    }

    private static String optStr(JsonObject o, String k, String def) {
        return o.has(k) && o.get(k).isJsonPrimitive() ? o.get(k).getAsString() : def;
    }

    private static int optInt(JsonObject o, String k, int def) {
        return o.has(k) && o.get(k).isJsonPrimitive() ? o.get(k).getAsInt() : def;
    }

    private static float optFloat(JsonObject o, String k, float def) {
        return o.has(k) && o.get(k).isJsonPrimitive() ? o.get(k).getAsFloat() : def;
    }

    private static boolean optBool(JsonObject o, String k, boolean def) {
        return o.has(k) && o.get(k).isJsonPrimitive() ? o.get(k).getAsBoolean() : def;
    }
}
