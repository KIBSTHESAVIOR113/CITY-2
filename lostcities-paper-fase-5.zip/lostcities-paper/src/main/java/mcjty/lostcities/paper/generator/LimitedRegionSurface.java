/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.generator;

import mcjty.lostcities.paper.core.BlockSurface;
import mcjty.lostcities.paper.util.BoundedCache;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.data.BlockData;
import org.bukkit.generator.LimitedRegion;
import org.bukkit.generator.WorldInfo;

/**
 * Thread-safe {@link BlockSurface} backed exclusively by Paper's {@link LimitedRegion}
 * with a bounded {@link BlockData} parse cache (Invariant #13, Risk R-10).
 */
public final class LimitedRegionSurface implements BlockSurface {

    private static final BoundedCache<String, BlockData> BLOCK_DATA_CACHE = new BoundedCache<>(2048, 3600);

    private final LimitedRegion region;
    private final int minY;
    private final int maxY;

    public LimitedRegionSurface(WorldInfo worldInfo, LimitedRegion region) {
        this.region = region;
        this.minY = worldInfo.getMinHeight();
        this.maxY = worldInfo.getMaxHeight();
    }

    @Override
    public int minY() { return minY; }

    @Override
    public int maxY() { return maxY; }

    @Override
    public boolean isInBounds(int worldX, int y, int worldZ) {
        return y >= minY && y < maxY && region.isInRegion(worldX, y, worldZ);
    }

    @Override
    public String getBlockId(int worldX, int y, int worldZ) {
        if (!isInBounds(worldX, y, worldZ)) {
            return "minecraft:air";
        }
        return region.getBlockData(worldX, y, worldZ).getAsString();
    }

    @Override
    public void setBlockId(int worldX, int y, int worldZ, String blockId) {
        if (!isInBounds(worldX, y, worldZ)) {
            return;
        }
        region.setBlockData(worldX, y, worldZ, parseBlockData(blockId));
    }

    public static BlockData parseBlockData(String blockId) {
        if (blockId == null || blockId.isBlank()) {
            return Material.AIR.createBlockData();
        }
        return BLOCK_DATA_CACHE.computeIfAbsent(blockId, id -> {
            try {
                return Bukkit.createBlockData(id);
            } catch (IllegalArgumentException ex) {
                return Material.STONE_BRICKS.createBlockData();
            }
        });
    }

    public static void clearCache() {
        BLOCK_DATA_CACHE.clear();
    }
}
