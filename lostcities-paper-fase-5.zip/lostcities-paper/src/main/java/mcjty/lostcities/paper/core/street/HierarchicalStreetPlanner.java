/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.street;

import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.config.StreetGenerationMode;
import mcjty.lostcities.paper.util.DeterministicRandom;

import java.util.Random;

/**
 * Deterministic hierarchical street grid planner (Primary / Secondary / Tertiary)
 * ported from LostCities 26.3 {@code HierarchicalStreetPlanner}.
 */
public final class HierarchicalStreetPlanner {

    private final long worldSeed;
    private final String dimensionId;
    private final LostCityProfile profile;

    public HierarchicalStreetPlanner(long worldSeed, String dimensionId, LostCityProfile profile) {
        this.worldSeed = worldSeed;
        this.dimensionId = dimensionId;
        this.profile = profile;
    }

    public PlannedStreetInfo getStreetInfo(int chunkX, int chunkZ) {
        if (profile.streetGenerationMode == StreetGenerationMode.LEGACY) {
            return PlannedStreetInfo.NONE;
        }
        PlannedRoadType type = classify(chunkX, chunkZ);
        if (type == PlannedRoadType.NONE) {
            return PlannedStreetInfo.NONE;
        }
        boolean n = classify(chunkX, chunkZ - 1) != PlannedRoadType.NONE;
        boolean s = classify(chunkX, chunkZ + 1) != PlannedRoadType.NONE;
        boolean w = classify(chunkX - 1, chunkZ) != PlannedRoadType.NONE;
        boolean e = classify(chunkX + 1, chunkZ) != PlannedRoadType.NONE;
        return new PlannedStreetInfo(type, n, s, w, e);
    }

    public PlannedRoadType classify(int chunkX, int chunkZ) {
        int sx = Math.max(4, profile.primaryRoadSpacingX);
        int sz = Math.max(4, profile.primaryRoadSpacingZ);
        boolean onPrimaryX = Math.floorMod(chunkX, sx) == 0 && isPrimaryLineActive(true, Math.floorDiv(chunkX, sx));
        boolean onPrimaryZ = Math.floorMod(chunkZ, sz) == 0 && isPrimaryLineActive(false, Math.floorDiv(chunkZ, sz));
        if (onPrimaryX || onPrimaryZ) {
            return PlannedRoadType.PRIMARY;
        }

        int sep = Math.max(2, profile.minimumRoadSeparation);
        int relX = Math.floorMod(chunkX, sx);
        int relZ = Math.floorMod(chunkZ, sz);
        if (relX == sx / 2 && relX >= profile.minimumRoadEdgeDistance && (sx - relX) >= sep) {
            Random r = DeterministicRandom.buildingRandom(Math.floorDiv(chunkX, sx), Math.floorDiv(chunkZ, sz), worldSeed ^ 0x13579bdfL);
            if (r.nextInt(Math.max(1, profile.secondaryRoadMaxCountX + 1)) >= Math.max(1, profile.secondaryRoadMinCountX)) {
                return PlannedRoadType.SECONDARY;
            }
        }
        if (relZ == sz / 2 && relZ >= profile.minimumRoadEdgeDistance && (sz - relZ) >= sep) {
            Random r = DeterministicRandom.buildingRandom(Math.floorDiv(chunkX, sx) + 17, Math.floorDiv(chunkZ, sz) + 17, worldSeed ^ 0x2468ace0L);
            if (r.nextInt(Math.max(1, profile.secondaryRoadMaxCountZ + 1)) >= Math.max(1, profile.secondaryRoadMinCountZ)) {
                return PlannedRoadType.SECONDARY;
            }
        }
        return PlannedRoadType.NONE;
    }

    private boolean isPrimaryLineActive(boolean xAxis, int lineIndex) {
        int forceEvery = Math.max(1, profile.primaryRoadForceEvery);
        if (Math.floorMod(lineIndex, forceEvery) == 0) {
            return true;
        }
        long salt = (xAxis ? 0x1111_2222L : 0x3333_4444L) ^ dimensionId.hashCode();
        Random r = DeterministicRandom.buildingRandom(lineIndex, xAxis ? 1 : 2, worldSeed ^ salt);
        return r.nextFloat() < profile.primaryRoadOptionalChance;
    }
}
