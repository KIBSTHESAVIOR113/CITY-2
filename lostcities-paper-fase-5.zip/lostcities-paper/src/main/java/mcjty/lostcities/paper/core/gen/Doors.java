/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.gen;

import mcjty.lostcities.paper.core.BuildingInfo;
import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.core.ChunkDriver;
import mcjty.lostcities.paper.core.CompiledPalette;
import mcjty.lostcities.paper.core.lost.Orientation;

import java.util.function.Function;

/**
 * Port of {@code mcjty.lostcities.worldgen.gen.Doors}: places paired upper/lower door halves
 * with exact {@code facing} and {@code hinge} properties or open archways between connected buildings.
 */
public final class Doors {

    private static final String AIR = "minecraft:air";

    private Doors() {
    }

    public static String doorState(String doorBlock, boolean upper, boolean leftHinge, String facing) {
        return doorBlock
                + "[facing=" + facing
                + ",half=" + (upper ? "upper" : "lower")
                + ",hinge=" + (leftHinge ? "left" : "right")
                + ",open=false,powered=false]";
    }

    public static void generateDoors(
            ChunkDriver driver,
            BuildingInfo info,
            CompiledPalette palette,
            char fillerChar,
            int height,
            int floor,
            Function<ChunkCoord, BuildingInfo> lookup
    ) {
        String filler = palette.getBlock(fillerChar);
        if (filler == null || filler.isBlank()) filler = info.profile.baseBlock;
        int y0 = height - 1; // One below for filler threshold

        BuildingInfo xmin = lookup.apply(info.coord.west());
        BuildingInfo xmax = lookup.apply(info.coord.east());
        BuildingInfo zmin = lookup.apply(info.coord.north());
        BuildingInfo zmax = lookup.apply(info.coord.south());

        // West wall (x = 0)
        if (info.hasConnectionAtX(floor + info.cellars)) {
            if (hasConnectionWithBuilding(floor, info, xmin)) {
                placeArchwayX(driver, 0, y0, filler);
            } else if (hasConnectionToTopOrOutside(floor, info, xmin)) {
                placeDoubleDoorX(driver, 0, y0, filler, info.doorBlock, "east", true);
            }
        }

        // East wall (x = 15)
        if (hasConnectionWithBuildingMax(floor, info, xmax, Orientation.X)) {
            placeArchwayX(driver, 15, y0, filler);
        } else if (hasConnectionToTopOrOutside(floor, info, xmax) && xmax.hasConnectionAtX(floor + xmax.cellars)) {
            placeDoubleDoorX(driver, 15, y0, filler, info.doorBlock, "west", false);
        }

        // North wall (z = 0)
        if (info.hasConnectionAtZ(floor + info.cellars)) {
            if (hasConnectionWithBuilding(floor, info, zmin)) {
                placeArchwayZ(driver, 0, y0, filler);
            } else if (hasConnectionToTopOrOutside(floor, info, zmin)) {
                placeDoubleDoorZ(driver, 0, y0, filler, info.doorBlock, "north", true);
            }
        }

        // South wall (z = 15)
        if (hasConnectionWithBuildingMax(floor, info, zmax, Orientation.Z)) {
            placeArchwayZ(driver, 15, y0, filler);
        } else if (hasConnectionToTopOrOutside(floor, info, zmax) && zmax.hasConnectionAtZ(floor + zmax.cellars)) {
            placeDoubleDoorZ(driver, 15, y0, filler, info.doorBlock, "south", false);
        }
    }

    private static void placeArchwayX(ChunkDriver driver, int x, int y0, String filler) {
        driver.setBlockRange(x, y0, 6, y0 + 4, filler);
        driver.setBlockRange(x, y0, 9, y0 + 4, filler);
        for (int z = 7; z <= 8; z++) {
            driver.setBlock(x, y0, z, filler);
            driver.setBlock(x, y0 + 1, z, AIR);
            driver.setBlock(x, y0 + 2, z, AIR);
            driver.setBlock(x, y0 + 3, z, filler);
        }
    }

    private static void placeDoubleDoorX(ChunkDriver driver, int x, int y0, String filler, String doorBlock, String facing, boolean z7Left) {
        driver.setBlockRange(x, y0, 6, y0 + 4, filler);
        driver.setBlockRange(x, y0, 9, y0 + 4, filler);
        driver.setBlock(x, y0, 7, filler);
        driver.setBlock(x, y0 + 1, 7, doorState(doorBlock, false, z7Left, facing));
        driver.setBlock(x, y0 + 2, 7, doorState(doorBlock, true, z7Left, facing));
        driver.setBlock(x, y0 + 3, 7, filler);

        driver.setBlock(x, y0, 8, filler);
        driver.setBlock(x, y0 + 1, 8, doorState(doorBlock, false, !z7Left, facing));
        driver.setBlock(x, y0 + 2, 8, doorState(doorBlock, true, !z7Left, facing));
        driver.setBlock(x, y0 + 3, 8, filler);
    }

    private static void placeArchwayZ(ChunkDriver driver, int z, int y0, String filler) {
        driver.setBlockRange(6, y0, z, y0 + 4, filler);
        driver.setBlockRange(9, y0, z, y0 + 4, filler);
        for (int x = 7; x <= 8; x++) {
            driver.setBlock(x, y0, z, filler);
            driver.setBlock(x, y0 + 1, z, AIR);
            driver.setBlock(x, y0 + 2, z, AIR);
            driver.setBlock(x, y0 + 3, z, filler);
        }
    }

    private static void placeDoubleDoorZ(ChunkDriver driver, int z, int y0, String filler, String doorBlock, String facing, boolean x7Left) {
        driver.setBlockRange(6, y0, z, y0 + 4, filler);
        driver.setBlockRange(9, y0, z, y0 + 4, filler);
        driver.setBlock(7, y0, z, filler);
        driver.setBlock(7, y0 + 1, z, doorState(doorBlock, false, x7Left, facing));
        driver.setBlock(7, y0 + 2, z, doorState(doorBlock, true, x7Left, facing));
        driver.setBlock(7, y0 + 3, z, filler);

        driver.setBlock(8, y0, z, filler);
        driver.setBlock(8, y0 + 1, z, doorState(doorBlock, false, !x7Left, facing));
        driver.setBlock(8, y0 + 2, z, doorState(doorBlock, true, !x7Left, facing));
        driver.setBlock(8, y0 + 3, z, filler);
    }

    private static boolean hasConnectionWithBuilding(int f, BuildingInfo info, BuildingInfo adj) {
        if (!adj.hasBuilding) return false;
        int adjFloor = info.localToGlobal(f) - adj.cityLevel;
        return adjFloor >= -adj.cellars && adjFloor < adj.floors;
    }

    private static boolean hasConnectionWithBuildingMax(int f, BuildingInfo info, BuildingInfo adj, Orientation orient) {
        if (!adj.hasBuilding) return false;
        int adjFloor = info.localToGlobal(f) - adj.cityLevel;
        if (adjFloor < -adj.cellars || adjFloor >= adj.floors) return false;
        return adj.hasConnectionAt(adjFloor + adj.cellars, orient);
    }

    private static boolean hasConnectionToTopOrOutside(int f, BuildingInfo info, BuildingInfo adj) {
        int globalLevel = info.localToGlobal(f);
        if (!adj.hasBuilding) {
            return globalLevel == adj.cityLevel;
        }
        return globalLevel == adj.cityLevel + adj.floors;
    }
}
