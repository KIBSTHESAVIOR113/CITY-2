/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.lost;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import mcjty.lostcities.paper.assets.AssetModels;
import mcjty.lostcities.paper.util.PathSecurity;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Evaluates {@code BuildingAsset.parts} and {@code BuildingAsset.parts2} rules strictly
 * against {@link ConditionContext} (eliminating global random part selection).
 */
public final class BuildingPartSelector {

    private BuildingPartSelector() {
    }

    public static String selectPart(List<JsonObject> rules, Random rand, ConditionContext ctx) {
        if (rules == null || rules.isEmpty()) {
            return null;
        }
        List<String> matching = new ArrayList<>();
        for (JsonObject rule : rules) {
            if (matchesRule(rule, ctx)) {
                String partName = rule.has("part") && rule.get("part").isJsonPrimitive()
                        ? rule.get("part").getAsString() : null;
                if (partName != null && !partName.isBlank()) {
                    matching.add(partName);
                }
            }
        }
        if (matching.isEmpty()) {
            return null;
        }
        return matching.get(rand.nextInt(matching.size()));
    }

    public static String selectPrimaryPart(AssetModels.BuildingAsset building, Random rand, ConditionContext ctx) {
        if (building == null) return null;
        return selectPart(building.parts(), rand, ctx);
    }

    public static String selectOverlayPart2(AssetModels.BuildingAsset building, Random rand, ConditionContext ctx) {
        if (building == null) return null;
        return selectPart(building.parts2(), rand, ctx);
    }

    private static boolean matchesRule(JsonObject rule, ConditionContext ctx) {
        if (hasBool(rule, "top") && rule.get("top").getAsBoolean() != ctx.isTop()) return false;
        if (hasBool(rule, "ground") && rule.get("ground").getAsBoolean() != ctx.isGround()) return false;
        if (hasBool(rule, "cellar") && rule.get("cellar").getAsBoolean() != ctx.isCellar()) return false;
        if (hasBool(rule, "isbuilding") && rule.get("isbuilding").getAsBoolean() != ctx.isBuilding()) return false;
        if (hasBool(rule, "issphere") && rule.get("issphere").getAsBoolean() != ctx.isSphere()) return false;
        if (rule.has("range") && rule.get("range").isJsonPrimitive()) {
            String[] parts = rule.get("range").getAsString().split(",");
            if (parts.length == 2) {
                int min = Integer.parseInt(parts[0].trim());
                int max = Integer.parseInt(parts[1].trim());
                if (ctx.floor() < min || ctx.floor() > max) return false;
            }
        }
        if (rule.has("inpart") && rule.get("inpart").isJsonPrimitive()) {
            String req = PathSecurity.normalizeResourceId(rule.get("inpart").getAsString(), "lostcities");
            if (!req.equals(PathSecurity.normalizeResourceId(ctx.part(), "lostcities"))) return false;
        }
        if (rule.has("belowpart") && rule.get("belowpart").isJsonPrimitive()) {
            String req = PathSecurity.normalizeResourceId(rule.get("belowpart").getAsString(), "lostcities");
            if (!req.equals(PathSecurity.normalizeResourceId(ctx.belowPart(), "lostcities"))) return false;
        }
        return true;
    }

    private static boolean hasBool(JsonObject o, String key) {
        JsonElement el = o.get(key);
        return el != null && el.isJsonPrimitive() && el.getAsJsonPrimitive().isBoolean();
    }
}
