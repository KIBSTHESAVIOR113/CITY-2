/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.street;

public record PlannedStreetInfo(
        PlannedRoadType roadType,
        boolean north,
        boolean south,
        boolean west,
        boolean east
) {
    public static final PlannedStreetInfo NONE = new PlannedStreetInfo(PlannedRoadType.NONE, false, false, false, false);

    public boolean isRoad() {
        return roadType != PlannedRoadType.NONE;
    }
}
