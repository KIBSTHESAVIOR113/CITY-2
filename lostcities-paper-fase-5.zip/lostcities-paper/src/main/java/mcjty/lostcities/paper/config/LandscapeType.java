/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.config;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public enum LandscapeType {
    DEFAULT("default"),
    FLOATING("floating"),
    SPACE("space"),
    CAVERN("cavern"),
    SPHERES("spheres"),
    CAVERNSPHERES("cavernspheres");

    private final String id;
    private static final Map<String, LandscapeType> BY_NAME = new LinkedHashMap<>();

    static {
        for (LandscapeType type : values()) {
            BY_NAME.put(type.id, type);
        }
    }

    LandscapeType(String id) {
        this.id = id;
    }

    public String getName() {
        return id;
    }

    public static LandscapeType getTypeByName(String name) {
        if (name == null) {
            return null;
        }
        return BY_NAME.get(name.trim().toLowerCase(Locale.ROOT));
    }
}
