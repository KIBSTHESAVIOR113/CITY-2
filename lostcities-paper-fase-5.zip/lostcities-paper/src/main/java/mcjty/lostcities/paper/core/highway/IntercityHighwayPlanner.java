/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.highway;

import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.core.highway.HighwayModels.*;
import mcjty.lostcities.paper.core.lost.City;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Deterministic inter-city highway hub selector and L-shaped orthogonal route planner.
 * Uses the single per-world {@link City} instance injected by {@code WorldDimensionState} (C3).
 */
public final class IntercityHighwayPlanner {

    private final long worldSeed;
    private final String dimensionId;
    private final LostCityProfile profile;
    private final HighwayStore store;
    private final City city;

    public IntercityHighwayPlanner(long worldSeed, String dimensionId, LostCityProfile profile, HighwayStore store, City city) {
        this.worldSeed = worldSeed;
        this.dimensionId = dimensionId;
        this.profile = profile;
        this.store = store;
        this.city = Objects.requireNonNull(city, "city");
    }

    public HubKey getPlanningCell(int chunkX, int chunkZ) {
        int cell = Math.max(32, profile.highwayPlanningCellSize);
        return new HubKey(Math.floorDiv(chunkX, cell), Math.floorDiv(chunkZ, cell));
    }

    public Optional<HighwayHub> getHub(HubKey key) {
        if (store != null) {
            Optional<Optional<HighwayHub>> persisted = store.lookup(key);
            if (persisted.isPresent()) {
                return persisted.get();
            }
        }
        int cell = Math.max(32, profile.highwayPlanningCellSize);
        int step = Math.max(4, profile.highwayHubSampleSpacing);
        int startX = key.planningCellX() * cell;
        int startZ = key.planningCellZ() * cell;
        HighwayHub best = null;
        for (int dx = 0; dx < cell; dx += step) {
            for (int dz = 0; dz < cell; dz += step) {
                int cx = startX + dx;
                int cz = startZ + dz;
                float pot = city.getCityFactor(new ChunkCoord(dimensionId, cx, cz), c -> 1.0);
                if (pot >= profile.highwayHubMinimumPotential) {
                    int score = Math.round(pot * 1000.0f);
                    if (best == null || score > best.potentialScore()) {
                        best = new HighwayHub(key, cx, cz, score, profile.highwayNetworkLevel);
                    }
                }
            }
        }
        Optional<HighwayHub> result = Optional.ofNullable(best);
        if (store != null) {
            store.store(key, result);
        }
        return result;
    }

    public List<HighwayRoute> getRoutesForCell(HubKey center) {
        Optional<HighwayHub> srcOpt = getHub(center);
        if (srcOpt.isEmpty()) return List.of();
        HighwayHub src = srcOpt.get();

        int radius = Math.max(1, profile.highwayHubSearchRadiusCells);
        List<HighwayHub> candidates = new ArrayList<>();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                if (dx == 0 && dz == 0) continue;
                HubKey nk = new HubKey(center.planningCellX() + dx, center.planningCellZ() + dz);
                if (nk.compareTo(center) <= 0) continue;
                getHub(nk).ifPresent(nh -> {
                    double dist = Math.hypot(nh.chunkX() - src.chunkX(), nh.chunkZ() - src.chunkZ());
                    if (dist >= profile.highwayMinimumHubDistance && dist <= profile.highwayMaximumHubDistance) {
                        candidates.add(nh);
                    }
                });
            }
        }
        candidates.sort(Comparator
                .comparingDouble((HighwayHub h) -> Math.hypot(h.chunkX() - src.chunkX(), h.chunkZ() - src.chunkZ()))
                .thenComparing(HighwayHub::key));

        List<HighwayRoute> routes = new ArrayList<>();
        int maxConn = Math.max(1, profile.highwayMaximumConnectionsPerHub);
        for (int i = 0; i < Math.min(maxConn, candidates.size()); i++) {
            HighwayHub dst = candidates.get(i);
            HighwaySegment segX = new HighwaySegment(src.chunkX(), src.chunkZ(), dst.chunkX(), src.chunkZ(), HighwayAxis.X);
            HighwaySegment segZ = new HighwaySegment(dst.chunkX(), src.chunkZ(), dst.chunkX(), dst.chunkZ(), HighwayAxis.Z);
            routes.add(new HighwayRoute(src, dst, List.of(segX, segZ), profile.highwayNetworkLevel));
        }
        return List.copyOf(routes);
    }

    public HighwayInfo getHighwayInfo(int chunkX, int chunkZ) {
        HubKey center = getPlanningCell(chunkX, chunkZ);
        int radius = Math.max(1, profile.highwayHubSearchRadiusCells);
        int xLevel = -1;
        int zLevel = -1;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                HubKey owner = new HubKey(center.planningCellX() + dx, center.planningCellZ() + dz);
                for (HighwayRoute r : getRoutesForCell(owner)) {
                    for (HighwaySegment seg : r.segments()) {
                        if (seg.contains(chunkX, chunkZ)) {
                            if (seg.axis() == HighwayAxis.X) xLevel = Math.max(xLevel, r.level());
                            else zLevel = Math.max(zLevel, r.level());
                        }
                    }
                }
            }
        }
        return (xLevel < 0 && zLevel < 0) ? HighwayInfo.NONE : new HighwayInfo(xLevel, zLevel);
    }

    public int searchRadiusCells() {
        return Math.max(1, profile.highwayHubSearchRadiusCells);
    }
}
