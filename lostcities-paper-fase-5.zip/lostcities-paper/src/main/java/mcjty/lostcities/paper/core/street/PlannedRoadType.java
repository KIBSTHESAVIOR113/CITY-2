/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.street;

public enum PlannedRoadType {
    NONE,
    PRIMARY,
    SECONDARY,
    TERTIARY
}
