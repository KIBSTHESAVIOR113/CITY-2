/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.lost;

public enum Orientation {
    X,
    Z;

    public Orientation getOpposite() {
        return this == X ? Z : X;
    }
}
