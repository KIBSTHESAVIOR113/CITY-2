/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.lost;

/**
 * Exact port of {@code mcjty.lostcities.api.RailChunkType}.
 */
public enum RailChunkType {
    NONE(false, false),
    STATION_SURFACE(true, true),
    STATION_UNDERGROUND(true, false),
    STATION_EXTENSION_SURFACE(true, true),
    STATION_EXTENSION_UNDERGROUND(true, false),
    GOING_DOWN_TWO_FROM_SURFACE(false, true),
    GOING_DOWN_ONE_FROM_SURFACE(false, true),
    GOING_DOWN_FURTHER(false, false),
    HORIZONTAL(false, false),
    VERTICAL(false, false),
    DOUBLE_BEND(false, false),
    THREE_SPLIT(false, false),
    RAILS_END_HERE(false, false);

    private final boolean station;
    private final boolean surface;

    RailChunkType(boolean station, boolean surface) {
        this.station = station;
        this.surface = surface;
    }

    public boolean isStation() { return station; }
    public boolean isSurface() { return surface; }
}
