/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.assets;

import com.google.gson.JsonObject;

import java.util.List;
import java.util.Map;

/**
 * Immutable data models for all 13 LostCities JSON asset registries.
 */
public final class AssetModels {

    private AssetModels() {
    }

    public record PartAsset(
            String id,
            int xSize,
            int ySize,
            int zSize,
            String refPaletteName,
            List<List<String>> slices,
            Map<String, Object> metadata,
            JsonObject raw
    ) {}

    public record BuildingAsset(
            String id,
            String filler,
            String rubble,
            String refPaletteName,
            int minFloors,
            int maxFloors,
            int minCellars,
            int maxCellars,
            float prefersLonely,
            boolean allowDoors,
            List<JsonObject> parts,
            List<JsonObject> parts2,
            JsonObject raw
    ) {}

    public record MultiBuildingAsset(
            String id,
            int dimX,
            int dimZ,
            List<List<String>> buildings,
            JsonObject raw
    ) {}

    public record VariantAsset(
            String id,
            List<WeightedBlock> blocks,
            JsonObject raw
    ) {}

    public record WeightedBlock(int weight, String block) {}

    public record PaletteAsset(
            String id,
            List<PaletteEntryModel> entries,
            JsonObject raw
    ) {}

    public record PaletteEntryModel(
            char symbol,
            String block,
            String variant,
            String fromPalette,
            String loot,
            String mob,
            boolean torch,
            boolean damaged,
            List<WeightedBlock> randomBlocks
    ) {}

    public record StyleAsset(
            String id,
            List<List<WeightedRef>> randomPalettes,
            JsonObject raw
    ) {}

    public record WeightedRef(float factor, String value) {}

    public record CityStyleAsset(
            String id,
            String inherit,
            String style,
            String streetBlock,
            String streetBaseBlock,
            String parkElevationBlock,
            String corridorRoofBlock,
            String corridorGlassBlock,
            JsonObject raw
    ) {}

    public record ScatteredAsset(
            String id,
            List<String> buildings,
            String multiBuilding,
            String terrainHeight,
            String terrainFix,
            int heightOffset,
            JsonObject raw
    ) {}

    public record StuffAsset(
            String id,
            List<String> tags,
            int minCount,
            int maxCount,
            int attempts,
            JsonObject raw
    ) {}

    public record ConditionAsset(
            String id,
            List<ConditionRule> rules,
            JsonObject raw
    ) {}

    public record ConditionRule(
            float factor,
            String value,
            Boolean top,
            Boolean ground,
            Boolean cellar,
            Boolean isBuilding,
            Boolean isSphere,
            Integer rangeMin,
            Integer rangeMax,
            String inPart,
            String inBuilding,
            String inBiome
    ) {}

    public record WorldStyleAsset(
            String id,
            String outsideStyle,
            List<JsonObject> cityStyleSelectors,
            List<JsonObject> cityBiomeMultipliers,
            JsonObject raw
    ) {}

    public record PredefinedCityAsset(
            String id,
            String dimension,
            int chunkX,
            int chunkZ,
            int radius,
            String cityStyle,
            JsonObject raw
    ) {}

    public record PredefinedSphereAsset(
            String id,
            String dimension,
            int chunkX,
            int chunkZ,
            int centerY,
            int radius,
            boolean usable,
            JsonObject raw
    ) {}
}
