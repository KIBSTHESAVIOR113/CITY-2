/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.config;

import java.util.Locale;

public enum StreetGenerationMode {
    LEGACY,
    HIERARCHICAL_GRID_V1;

    public static StreetGenerationMode byName(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Street generation mode cannot be blank");
        }
        return valueOf(name.trim().toUpperCase(Locale.ROOT));
    }
}
