/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.command;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import io.papermc.paper.command.brigadier.CommandSourceStack;
import io.papermc.paper.command.brigadier.Commands;
import io.papermc.paper.plugin.lifecycle.event.types.LifecycleEvents;
import mcjty.lostcities.paper.LostCitiesPlugin;
import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.BuildingInfo;
import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.generator.WorldDimensionState;
import mcjty.lostcities.paper.util.PathSecurity;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Registers {@code /lostcities} and alias {@code /lc} via Paper 26.3 Brigadier
 * {@link LifecycleEvents#COMMANDS} covering all PRD F11 subcommands.
 */
public final class CommandRegistrar {

    private final LostCitiesPlugin plugin;

    public CommandRegistrar(LostCitiesPlugin plugin) {
        this.plugin = plugin;
    }

    public void register() {
        plugin.getLifecycleManager().registerEventHandler(LifecycleEvents.COMMANDS, event -> {
            LiteralArgumentBuilder<CommandSourceStack> root = buildRoot("lostcities");
            event.registrar().register(root.build(), "LostCities worldgen management commands", List.of("lc"));
        });
    }

    private LiteralArgumentBuilder<CommandSourceStack> buildRoot(String literal) {
        return Commands.literal(literal)
                .executes(ctx -> {
                    ctx.getSource().getSender().sendMessage("Usage: /lostcities <world|locate|locatepart|listparts|map|stats|debug|saveprofile|reload|createbuilding|createpart|exportpart|editpart|resumeedit>");
                    return Command.SINGLE_SUCCESS;
                })
                .then(Commands.literal("world")
                        .requires(s -> s.getSender().hasPermission("lostcities.admin"))
                        .then(Commands.literal("create")
                                .then(Commands.argument("name", StringArgumentType.word())
                                        .executes(ctx -> createWorld(ctx.getSource().getSender(),
                                                StringArgumentType.getString(ctx, "name"),
                                                plugin.getPluginConfig().defaultProfile(),
                                                ThreadLocalRandom.current().nextLong()))
                                        .then(Commands.argument("profile", StringArgumentType.word())
                                                .suggests((ctx, b) -> {
                                                    plugin.getProfiles().keySet().forEach(b::suggest);
                                                    return b.buildFuture();
                                                })
                                                .executes(ctx -> createWorld(ctx.getSource().getSender(),
                                                        StringArgumentType.getString(ctx, "name"),
                                                        StringArgumentType.getString(ctx, "profile"),
                                                        ThreadLocalRandom.current().nextLong()))
                                                .then(Commands.argument("seed", LongArgumentType.longArg())
                                                        .executes(ctx -> createWorld(ctx.getSource().getSender(),
                                                                StringArgumentType.getString(ctx, "name"),
                                                                StringArgumentType.getString(ctx, "profile"),
                                                                LongArgumentType.getLong(ctx, "seed"))))))))
                .then(Commands.literal("locate")
                        .requires(s -> s.getSender().hasPermission("lostcities.locate"))
                        .executes(ctx -> locate(ctx.getSource().getSender(), "city"))
                        .then(Commands.argument("type", StringArgumentType.word())
                                .suggests((ctx, b) -> {
                                    b.suggest("city");
                                    b.suggest("building");
                                    b.suggest("multibuilding");
                                    return b.buildFuture();
                                })
                                .executes(ctx -> locate(ctx.getSource().getSender(), StringArgumentType.getString(ctx, "type")))))
                .then(Commands.literal("locatepart")
                        .requires(s -> s.getSender().hasPermission("lostcities.locate"))
                        .then(Commands.argument("part", StringArgumentType.word())
                                .executes(ctx -> locatePart(ctx.getSource().getSender(), StringArgumentType.getString(ctx, "part")))))
                .then(Commands.literal("listparts")
                        .requires(s -> s.getSender().hasPermission("lostcities.admin"))
                        .executes(ctx -> listParts(ctx.getSource().getSender(), ""))
                        .then(Commands.argument("filter", StringArgumentType.word())
                                .executes(ctx -> listParts(ctx.getSource().getSender(), StringArgumentType.getString(ctx, "filter")))))
                .then(Commands.literal("map")
                        .requires(s -> s.getSender().hasPermission("lostcities.map"))
                        .executes(ctx -> showMap(ctx.getSource().getSender())))
                .then(Commands.literal("stats")
                        .requires(s -> s.getSender().hasPermission("lostcities.stats"))
                        .executes(ctx -> showStats(ctx.getSource().getSender())))
                .then(Commands.literal("debug")
                        .requires(s -> s.getSender().hasPermission("lostcities.admin"))
                        .executes(ctx -> toggleDebug(ctx.getSource().getSender(), null))
                        .then(Commands.argument("state", StringArgumentType.word())
                                .suggests((ctx, b) -> { b.suggest("on"); b.suggest("off"); return b.buildFuture(); })
                                .executes(ctx -> toggleDebug(ctx.getSource().getSender(), StringArgumentType.getString(ctx, "state")))))
                .then(Commands.literal("saveprofile")
                        .requires(s -> s.getSender().hasPermission("lostcities.admin"))
                        .then(Commands.argument("name", StringArgumentType.word())
                                .executes(ctx -> saveProfile(ctx.getSource().getSender(), StringArgumentType.getString(ctx, "name")))))
                .then(Commands.literal("reload")
                        .requires(s -> s.getSender().hasPermission("lostcities.admin"))
                        .executes(ctx -> reloadAssets(ctx.getSource().getSender())))
                .then(Commands.literal("createbuilding")
                        .requires(s -> s.getSender().hasPermission("lostcities.edit"))
                        .executes(ctx -> editStubInfo(ctx.getSource().getSender(), "createbuilding")))
                .then(Commands.literal("createpart")
                        .requires(s -> s.getSender().hasPermission("lostcities.edit"))
                        .executes(ctx -> editStubInfo(ctx.getSource().getSender(), "createpart")))
                .then(Commands.literal("exportpart")
                        .requires(s -> s.getSender().hasPermission("lostcities.edit"))
                        .executes(ctx -> editStubInfo(ctx.getSource().getSender(), "exportpart")))
                .then(Commands.literal("editpart")
                        .requires(s -> s.getSender().hasPermission("lostcities.edit"))
                        .executes(ctx -> editStubInfo(ctx.getSource().getSender(), "editpart")))
                .then(Commands.literal("resumeedit")
                        .requires(s -> s.getSender().hasPermission("lostcities.edit"))
                        .executes(ctx -> editStubInfo(ctx.getSource().getSender(), "resumeedit")));
    }

    private int createWorld(CommandSender sender, String rawName, String profileName, long seed) {
        try {
            String safeName = PathSecurity.validateSafeName(rawName, "world");
            if (Bukkit.getWorld(safeName) != null) {
                sender.sendMessage("World '" + safeName + "' already exists.");
                return 0;
            }
            World world = plugin.createLostCityWorld(safeName, profileName, seed);
            if (world == null) {
                sender.sendMessage("Failed to create world '" + safeName + "'. Check server log.");
                return 0;
            }
            sender.sendMessage("Created LostCities world '" + world.getName()
                    + "' (profile=" + profileName + ", seed=" + seed
                    + ", height=[" + world.getMinHeight() + ".." + world.getMaxHeight() + "])");
            return Command.SINGLE_SUCCESS;
        } catch (IllegalArgumentException ex) {
            sender.sendMessage("Invalid argument: " + ex.getMessage());
            return 0;
        }
    }

    private int locate(CommandSender sender, String type) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command must be run by a player.");
            return 0;
        }
        WorldDimensionState state = plugin.getDimensionState(player.getWorld().getUID());
        if (state == null) {
            sender.sendMessage("Current world is not a LostCities world.");
            return 0;
        }
        int cx = player.getLocation().getBlockX() >> 4;
        int cz = player.getLocation().getBlockZ() >> 4;
        int[] found = plugin.getSpawnHandler().findNearestCityChunk(state, cx, cz, 64);
        if (found == null) {
            sender.sendMessage("No " + type + " found within 64 chunks.");
            return 0;
        }
        sender.sendMessage(String.format(Locale.ROOT, "Nearest %s at block (%d, %d, %d) [chunk %d,%d]",
                type, (found[0] << 4) + 8, state.profile().groundLevel + 2, (found[1] << 4) + 8, found[0], found[1]));
        return Command.SINGLE_SUCCESS;
    }

    private int locatePart(CommandSender sender, String partName) {
        if (plugin.getAssetRegistry().getPart(partName) == null) {
            sender.sendMessage("Unknown part '" + partName + "'. Use /lc listparts to inspect available parts.");
            return 0;
        }
        return locate(sender, "part:" + partName);
    }

    private int listParts(CommandSender sender, String filter) {
        String f = filter.toLowerCase(Locale.ROOT);
        List<String> matches = plugin.getAssetRegistry().parts().keySet().stream()
                .filter(id -> f.isEmpty() || id.contains(f))
                .limit(30)
                .toList();
        sender.sendMessage("Parts (" + matches.size() + " shown / " + plugin.getAssetRegistry().parts().size() + " total): "
                + String.join(", ", matches));
        return Command.SINGLE_SUCCESS;
    }

    private int showMap(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command must be run by a player.");
            return 0;
        }
        WorldDimensionState state = plugin.getDimensionState(player.getWorld().getUID());
        if (state == null) {
            sender.sendMessage("Current world is not a LostCities world.");
            return 0;
        }
        int cx = player.getLocation().getBlockX() >> 4;
        int cz = player.getLocation().getBlockZ() >> 4;
        StringBuilder sb = new StringBuilder("LostCities ASCII Map (radius 5 chunks, @=you, #=building, .=street, ~=wild):\n");
        for (int dz = -5; dz <= 5; dz++) {
            for (int dx = -5; dx <= 5; dx++) {
                if (dx == 0 && dz == 0) {
                    sb.append('@');
                    continue;
                }
                ChunkCoord coord = new ChunkCoord("lostcities:" + state.worldName(), cx + dx, cz + dz);
                BuildingInfo info = state.getBuildingInfo(cx + dx, cz + dz, plugin.getAssetRegistry());
                sb.append(info.hasBuilding ? '#' : (info.isCity ? '.' : '~'));
            }
            sb.append('\n');
        }
        sender.sendMessage(sb.toString());
        return Command.SINGLE_SUCCESS;
    }

    private int showStats(CommandSender sender) {
        String msg = String.format(Locale.ROOT,
                "LostCities Stats | chunks=%d | avg=%.2fms | p95=%.2fms | noiseP95=%.2fms | surfaceP95=%.2fms | surfaceBI/chunk=%.2f | todoQueue=%d | worlds=%d | %s",
                plugin.getMetrics().chunksGenerated(),
                plugin.getMetrics().averageMs(),
                plugin.getMetrics().p95Ms(),
                plugin.getMetrics().noiseP95Ms(),
                plugin.getMetrics().surfaceP95Ms(),
                plugin.getMetrics().avgSurfaceBiPerChunk(),
                plugin.getGlobalTodo().pendingCount(),
                plugin.getActiveWorldCount(),
                plugin.getAssetRegistry().summaryLine());
        sender.sendMessage(msg);
        return Command.SINGLE_SUCCESS;
    }

    private int toggleDebug(CommandSender sender, String stateArg) {
        boolean next = stateArg == null ? !plugin.isDebugEnabled() : "on".equalsIgnoreCase(stateArg);
        plugin.setDebugEnabled(next);
        sender.sendMessage("LostCities debug logging: " + (next ? "ON" : "OFF"));
        return Command.SINGLE_SUCCESS;
    }

    private int saveProfile(CommandSender sender, String rawName) {
        try {
            LostCityProfile profile = (sender instanceof Player p && plugin.getDimensionState(p.getWorld().getUID()) != null)
                    ? plugin.getDimensionState(p.getWorld().getUID()).profile()
                    : plugin.resolveProfile(plugin.getPluginConfig().defaultProfile());
            Path saved = plugin.getConfigLoader().saveProfile(rawName, profile);
            sender.sendMessage("Saved profile to " + saved.getFileName());
            return Command.SINGLE_SUCCESS;
        } catch (Exception ex) {
            sender.sendMessage("Failed to save profile: " + ex.getMessage());
            return 0;
        }
    }

    private int reloadAssets(CommandSender sender) {
        AssetRegistry reg = plugin.reloadAllAssets();
        sender.sendMessage("Reloaded LostCities assets atomically: " + reg.summaryLine());
        return Command.SINGLE_SUCCESS;
    }

    private int editStubInfo(CommandSender sender, String action) {
        sender.sendMessage("Server-side JSON schema tool '" + action
                + "': edit JSON files directly under plugins/LostCities/data/lostcities/lostcities/ and run /lostcities reload.");
        return Command.SINGLE_SUCCESS;
    }
}
