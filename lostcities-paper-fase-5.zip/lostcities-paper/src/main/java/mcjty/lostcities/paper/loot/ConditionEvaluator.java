/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.loot;

import mcjty.lostcities.paper.assets.AssetModels;
import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.core.BuildingInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Evaluates LostCities JSON condition assets ({@code chestloot}, {@code easymobs}, {@code hardmobs}).
 */
public final class ConditionEvaluator {

    private ConditionEvaluator() {
    }

    public static String evaluate(AssetRegistry registry, String conditionName, BuildingInfo info, int floorOffset, Random rand) {
        AssetModels.ConditionAsset asset = registry.getCondition(conditionName);
        if (asset == null || asset.rules().isEmpty()) {
            return null;
        }
        List<AssetModels.ConditionRule> matching = new ArrayList<>();
        float totalWeight = 0.0f;
        for (AssetModels.ConditionRule rule : asset.rules()) {
            if (matches(rule, info, floorOffset)) {
                matching.add(rule);
                totalWeight += Math.max(0.01f, rule.factor());
            }
        }
        if (matching.isEmpty()) {
            return null;
        }
        float roll = rand.nextFloat() * totalWeight;
        float acc = 0.0f;
        for (AssetModels.ConditionRule r : matching) {
            acc += Math.max(0.01f, r.factor());
            if (roll <= acc) {
                return r.value();
            }
        }
        return matching.get(matching.size() - 1).value();
    }

    private static boolean matches(AssetModels.ConditionRule r, BuildingInfo info, int floorOffset) {
        if (r.isBuilding() != null && r.isBuilding() != info.hasBuilding) return false;
        if (r.cellar() != null && r.cellar() != (floorOffset < 0)) return false;
        if (r.ground() != null && r.ground() != (floorOffset == 0)) return false;
        if (r.top() != null && r.top() != (floorOffset >= info.floors)) return false;
        if (r.rangeMin() != null && floorOffset < r.rangeMin()) return false;
        if (r.rangeMax() != null && floorOffset > r.rangeMax()) return false;
        return true;
    }
}
