/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.lost;

import mcjty.lostcities.paper.core.ChunkCoord;

import java.util.function.Predicate;

/**
 * Paper-safe port of {@code mcjty.lostcities.worldgen.lost.StructureAvoidance} (K4).
 * Uses a 4-chunk buffer radius around city chunks to prevent vanilla structures from
 * expanding into city territory without querying NMS proto-chunk structure starts.
 */
public record StructureAvoidance(boolean avoidsCity, boolean isKnown) {

    public static final StructureAvoidance NONE = new StructureAvoidance(false, true);
    public static final StructureAvoidance UNKNOWN = new StructureAvoidance(false, false);

    public static boolean shouldAllowVanillaStructures(ChunkCoord coord, int bufferRadiusChunks, Predicate<ChunkCoord> isCityChunk) {
        int r = Math.max(0, bufferRadiusChunks);
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                if (isCityChunk.test(coord.offset(dx, dz))) {
                    return false;
                }
            }
        }
        return true;
    }
}
