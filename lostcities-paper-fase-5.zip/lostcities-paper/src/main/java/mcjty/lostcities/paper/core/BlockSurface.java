/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

/**
 * Thread-safe block read/write surface abstracting Paper's {@code LimitedRegion}
 * from pure-Java unit test grids. Implementations MUST NEVER touch live {@code World}
 * or trigger recursive chunk loading.
 */
public interface BlockSurface {

    int minY();

    int maxY();

    boolean isInBounds(int worldX, int y, int worldZ);

    String getBlockId(int worldX, int y, int worldZ);

    void setBlockId(int worldX, int y, int worldZ, String blockId);

    default int sampleSurfaceHeight(int worldX, int worldZ, int fallbackY) {
        for (int y = maxY() - 1; y >= minY(); y--) {
            String id = getBlockId(worldX, y, worldZ);
            if (id != null && !id.equals("minecraft:air") && !id.equals("minecraft:cave_air") && !id.equals("minecraft:void_air")) {
                return y;
            }
        }
        return fallbackY;
    }
}
