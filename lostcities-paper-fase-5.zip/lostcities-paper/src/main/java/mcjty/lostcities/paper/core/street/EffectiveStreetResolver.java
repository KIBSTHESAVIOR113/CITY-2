/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.street;

import mcjty.lostcities.paper.config.MultiBuildingStreetConflict;

/**
 * Resolves conflicts between planned hierarchical streets and multi-chunk buildings.
 */
public final class EffectiveStreetResolver {

    private EffectiveStreetResolver() {
    }

    public static boolean roadBlocksMultiBuilding(MultiBuildingStreetConflict policy, PlannedRoadType roadType) {
        return switch (policy) {
            case BLOCK_ALL -> roadType != PlannedRoadType.NONE;
            case OVERRIDE_MINOR -> roadType == PlannedRoadType.PRIMARY;
            case OVERRIDE_ALL -> false;
        };
    }
}
