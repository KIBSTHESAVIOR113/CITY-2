/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.lost;

import mcjty.lostcities.paper.util.DeterministicRandom;

import java.util.Random;

/**
 * Direct port of {@code mcjty.lostcities.worldgen.lost.CityRarityMap}.
 */
public final class CityRarityMap {

    private final DeterministicRandom.PerlinNoise2D perlinCity;
    private final double scale;
    private final double offset;
    private final double innerScale;

    public CityRarityMap(long seed, double scale, double offset, double innerScale) {
        this.perlinCity = new DeterministicRandom.PerlinNoise2D(new Random(seed), 4);
        this.scale = scale;
        this.offset = offset;
        this.innerScale = innerScale;
    }

    public float getCityFactor(int cx, int cz) {
        double factor = perlinCity.sample(cx / scale, cz / scale) * innerScale - offset;
        if (factor < 0.0) {
            factor = 0.0;
        }
        return (float) factor;
    }
}
