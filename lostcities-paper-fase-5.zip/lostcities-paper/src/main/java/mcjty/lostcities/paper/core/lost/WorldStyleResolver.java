/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.lost;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import mcjty.lostcities.paper.assets.AssetModels;
import mcjty.lostcities.paper.assets.AssetRegistry;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Resolves {@link AssetModels.WorldStyleAsset} citystyle selectors and biome multipliers.
 */
public final class WorldStyleResolver {

    private WorldStyleResolver() {
    }

    public static String selectRandomCityStyle(AssetRegistry registry, String worldStyleId, String biomeId, Random rand) {
        AssetModels.WorldStyleAsset ws = registry.getWorldStyle(worldStyleId);
        if (ws != null && !ws.cityStyleSelectors().isEmpty()) {
            List<CityStyleResolver.WeightedEntry> matching = new ArrayList<>();
            for (JsonObject sel : ws.cityStyleSelectors()) {
                if (matchesBiome(sel, biomeId)) {
                    float f = sel.has("factor") ? sel.get("factor").getAsFloat() : 1.0f;
                    String cs = sel.has("citystyle") ? sel.get("citystyle").getAsString() : "";
                    if (!cs.isBlank() && f > 0.0f) {
                        matching.add(new CityStyleResolver.WeightedEntry(f, cs));
                    }
                }
            }
            if (!matching.isEmpty()) {
                float total = 0.0f;
                for (CityStyleResolver.WeightedEntry e : matching) total += e.factor();
                float roll = rand.nextFloat() * total;
                float acc = 0.0f;
                for (CityStyleResolver.WeightedEntry e : matching) {
                    acc += e.factor();
                    if (roll <= acc) return e.value();
                }
                return matching.get(matching.size() - 1).value();
            }
        }
        return registry.cityStyles().isEmpty() ? "lostcities:citystyle_standard" : registry.cityStyles().keySet().iterator().next();
    }

    public static double getCityChanceMultiplier(AssetRegistry registry, String worldStyleId, String biomeId) {
        AssetModels.WorldStyleAsset ws = registry.getWorldStyle(worldStyleId);
        if (ws == null) return 1.0;
        for (JsonObject m : ws.cityBiomeMultipliers()) {
            if (matchesBiome(m, biomeId) && m.has("multiplier")) {
                return m.get("multiplier").getAsDouble();
            }
        }
        return 1.0;
    }

    public static String getOutsideStyle(AssetRegistry registry, String worldStyleId) {
        AssetModels.WorldStyleAsset ws = registry.getWorldStyle(worldStyleId);
        if (ws != null && ws.outsideStyle() != null && !ws.outsideStyle().isBlank()) {
            return ws.outsideStyle();
        }
        return "outside";
    }

    private static boolean matchesBiome(JsonObject obj, String biomeId) {
        if (obj == null || !obj.has("biomes") || !obj.get("biomes").isJsonObject()) {
            return true;
        }
        String normBiome = biomeId == null ? "minecraft:plains" : biomeId.toLowerCase(Locale.ROOT);
        JsonObject b = obj.getAsJsonObject("biomes");
        if (b.has("if_any") && b.get("if_any").isJsonArray()) {
            boolean any = false;
            for (JsonElement el : b.getAsJsonArray("if_any")) {
                String entry = el.getAsString().toLowerCase(Locale.ROOT);
                if (entry.equals(normBiome) || (entry.startsWith("#") && normBiome.contains(entry.substring(1).replace("minecraft:is_", "")))) {
                    any = true;
                    break;
                }
            }
            if (!any) return false;
        }
        if (b.has("excluding") && b.get("excluding").isJsonArray()) {
            for (JsonElement el : b.getAsJsonArray("excluding")) {
                String entry = el.getAsString().toLowerCase(Locale.ROOT);
                if (entry.equals(normBiome)) return false;
            }
        }
        return true;
    }
}
