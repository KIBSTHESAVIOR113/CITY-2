/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.util;

import org.bukkit.Bukkit;

/**
 * Runtime guard preventing accidental live-World Bukkit API calls from async worldgen threads.
 */
public final class ThreadGuard {

    private ThreadGuard() {
    }

    public static void requireMainThread(String operation) {
        try {
            if (Bukkit.getServer() != null && !Bukkit.isPrimaryThread()) {
                throw new IllegalStateException("Operation '" + operation
                        + "' MUST run on the server main thread, invoked on: " + Thread.currentThread().getName());
            }
        } catch (NullPointerException ignored) {
            // Unit test environment without Bukkit.server initialized
        }
    }
}
