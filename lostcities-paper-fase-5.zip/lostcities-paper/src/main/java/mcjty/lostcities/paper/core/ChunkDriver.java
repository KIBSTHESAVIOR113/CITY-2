/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Buffered per-chunk block writer inspired by LostCities' {@code ChunkDriver}.
 * Writes within the active chunk or {@link BlockSurface#isInBounds} are buffered
 * and flushed in one pass; out-of-bounds writes are queued into {@link GlobalTodo}
 * rather than loading neighbor chunks recursively (Invariant #13).
 */
public final class ChunkDriver {

    private BlockSurface surface;
    private int baseX;
    private int baseZ;
    private int minY;
    private int maxY;
    private final Map<Long, String> pendingLocal = new LinkedHashMap<>(4096);
    private final Map<Long, String> pendingCrossChunk = new LinkedHashMap<>();

    public void begin(BlockSurface surface, int chunkX, int chunkZ) {
        this.surface = surface;
        this.baseX = chunkX << 4;
        this.baseZ = chunkZ << 4;
        this.minY = surface.minY();
        this.maxY = surface.maxY();
        this.pendingLocal.clear();
        this.pendingCrossChunk.clear();
    }

    public void setBlockLocal(int lx, int y, int lz, String blockId) {
        if (blockId == null || y < minY || y >= maxY) {
            return;
        }
        int wx = baseX + lx;
        int wz = baseZ + lz;
        if (lx >= 0 && lx < 16 && lz >= 0 && lz < 16) {
            pendingLocal.put(packPos(wx, y, wz), blockId);
        } else if (surface.isInBounds(wx, y, wz)) {
            pendingLocal.put(packPos(wx, y, wz), blockId);
        } else {
            pendingCrossChunk.put(packPos(wx, y, wz), blockId);
        }
    }

    public void setBlockRange(int lx, int y1, int lz, int y2, String blockId) {
        int start = Math.max(minY, Math.min(y1, y2));
        int end = Math.min(maxY, Math.max(y1, y2));
        for (int y = start; y < end; y++) {
            setBlockLocal(lx, y, lz, blockId);
        }
    }

    public String getBlockLocal(int lx, int y, int lz) {
        if (y < minY || y >= maxY) {
            return "minecraft:air";
        }
        int wx = baseX + lx;
        int wz = baseZ + lz;
        String buffered = pendingLocal.get(packPos(wx, y, wz));
        if (buffered != null) {
            return buffered;
        }
        return surface.isInBounds(wx, y, wz) ? surface.getBlockId(wx, y, wz) : "minecraft:air";
    }

    public Map<Long, String> flush() {
        for (Map.Entry<Long, String> e : pendingLocal.entrySet()) {
            long p = e.getKey();
            int wx = unpackX(p);
            int y = unpackY(p);
            int wz = unpackZ(p);
            if (surface.isInBounds(wx, y, wz)) {
                surface.setBlockId(wx, y, wz, e.getValue());
            }
        }
        Map<Long, String> crossCopy = new LinkedHashMap<>(pendingCrossChunk);
        pendingLocal.clear();
        pendingCrossChunk.clear();
        return crossCopy;
    }

    public int minY() { return minY; }
    public int maxY() { return maxY; }

    public static long packPos(int x, int y, int z) {
        return (((long) (x & 0x3FFFFFF)) << 38) | (((long) (z & 0x3FFFFFF)) << 12) | (y & 0xFFFL);
    }

    public static int unpackX(long packed) {
        int v = (int) (packed >> 38);
        return (v << 6) >> 6;
    }

    public static int unpackZ(long packed) {
        int v = (int) ((packed >> 12) & 0x3FFFFFFL);
        return (v << 6) >> 6;
    }

    public static int unpackY(long packed) {
        int v = (int) (packed & 0xFFFL);
        return (v << 20) >> 20;
    }
}
