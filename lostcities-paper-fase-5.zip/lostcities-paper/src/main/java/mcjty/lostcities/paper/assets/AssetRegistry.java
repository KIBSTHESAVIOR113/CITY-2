/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.assets;

import mcjty.lostcities.paper.assets.AssetModels.*;
import mcjty.lostcities.paper.util.PathSecurity;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Immutable snapshot of all loaded LostCities JSON assets.
 * Swapped atomically via {@code AtomicReference<AssetRegistry>} on {@code /lostcities reload}
 * so active async chunk generation threads always observe a consistent asset view.
 */
public final class AssetRegistry {

    private final Map<String, PartAsset> parts;
    private final Map<String, BuildingAsset> buildings;
    private final Map<String, MultiBuildingAsset> multiBuildings;
    private final Map<String, VariantAsset> variants;
    private final Map<String, PaletteAsset> palettes;
    private final Map<String, StyleAsset> styles;
    private final Map<String, CityStyleAsset> cityStyles;
    private final Map<String, ScatteredAsset> scattered;
    private final Map<String, StuffAsset> stuff;
    private final Map<String, ConditionAsset> conditions;
    private final Map<String, WorldStyleAsset> worldStyles;
    private final Map<String, PredefinedCityAsset> predefinedCities;
    private final Map<String, PredefinedSphereAsset> predefinedSpheres;

    public AssetRegistry(
            Map<String, PartAsset> parts,
            Map<String, BuildingAsset> buildings,
            Map<String, MultiBuildingAsset> multiBuildings,
            Map<String, VariantAsset> variants,
            Map<String, PaletteAsset> palettes,
            Map<String, StyleAsset> styles,
            Map<String, CityStyleAsset> cityStyles,
            Map<String, ScatteredAsset> scattered,
            Map<String, StuffAsset> stuff,
            Map<String, ConditionAsset> conditions,
            Map<String, WorldStyleAsset> worldStyles,
            Map<String, PredefinedCityAsset> predefinedCities,
            Map<String, PredefinedSphereAsset> predefinedSpheres
    ) {
        this.parts = Collections.unmodifiableMap(new LinkedHashMap<>(parts));
        this.buildings = Collections.unmodifiableMap(new LinkedHashMap<>(buildings));
        this.multiBuildings = Collections.unmodifiableMap(new LinkedHashMap<>(multiBuildings));
        this.variants = Collections.unmodifiableMap(new LinkedHashMap<>(variants));
        this.palettes = Collections.unmodifiableMap(new LinkedHashMap<>(palettes));
        this.styles = Collections.unmodifiableMap(new LinkedHashMap<>(styles));
        this.cityStyles = Collections.unmodifiableMap(new LinkedHashMap<>(cityStyles));
        this.scattered = Collections.unmodifiableMap(new LinkedHashMap<>(scattered));
        this.stuff = Collections.unmodifiableMap(new LinkedHashMap<>(stuff));
        this.conditions = Collections.unmodifiableMap(new LinkedHashMap<>(conditions));
        this.worldStyles = Collections.unmodifiableMap(new LinkedHashMap<>(worldStyles));
        this.predefinedCities = Collections.unmodifiableMap(new LinkedHashMap<>(predefinedCities));
        this.predefinedSpheres = Collections.unmodifiableMap(new LinkedHashMap<>(predefinedSpheres));
    }

    public Map<String, PartAsset> parts() { return parts; }
    public Map<String, BuildingAsset> buildings() { return buildings; }
    public Map<String, MultiBuildingAsset> multiBuildings() { return multiBuildings; }
    public Map<String, VariantAsset> variants() { return variants; }
    public Map<String, PaletteAsset> palettes() { return palettes; }
    public Map<String, StyleAsset> styles() { return styles; }
    public Map<String, CityStyleAsset> cityStyles() { return cityStyles; }
    public Map<String, ScatteredAsset> scattered() { return scattered; }
    public Map<String, StuffAsset> stuff() { return stuff; }
    public Map<String, ConditionAsset> conditions() { return conditions; }
    public Map<String, WorldStyleAsset> worldStyles() { return worldStyles; }
    public Map<String, PredefinedCityAsset> predefinedCities() { return predefinedCities; }
    public Map<String, PredefinedSphereAsset> predefinedSpheres() { return predefinedSpheres; }

    public PartAsset getPart(String name) { return parts.get(norm(name)); }
    public BuildingAsset getBuilding(String name) { return buildings.get(norm(name)); }
    public MultiBuildingAsset getMultiBuilding(String name) { return multiBuildings.get(norm(name)); }
    public VariantAsset getVariant(String name) { return variants.get(norm(name)); }
    public PaletteAsset getPalette(String name) { return palettes.get(norm(name)); }
    public StyleAsset getStyle(String name) { return styles.get(norm(name)); }
    public CityStyleAsset getCityStyle(String name) { return cityStyles.get(norm(name)); }
    public ScatteredAsset getScattered(String name) { return scattered.get(norm(name)); }
    public StuffAsset getStuff(String name) { return stuff.get(norm(name)); }
    public ConditionAsset getCondition(String name) { return conditions.get(norm(name)); }
    public WorldStyleAsset getWorldStyle(String name) { return worldStyles.get(norm(name)); }

    public boolean hasCriticalAssets() {
        return !parts.isEmpty() && !buildings.isEmpty() && !palettes.isEmpty()
                && !cityStyles.isEmpty() && !worldStyles.isEmpty();
    }

    public String summaryLine() {
        return "parts=" + parts.size()
                + ", buildings=" + buildings.size()
                + ", palettes=" + palettes.size()
                + ", multibuildings=" + multiBuildings.size()
                + ", variants=" + variants.size()
                + ", citystyles=" + cityStyles.size()
                + ", scattered=" + scattered.size()
                + ", styles=" + styles.size()
                + ", stuff=" + stuff.size()
                + ", conditions=" + conditions.size()
                + ", worldstyles=" + worldStyles.size()
                + ", predefinedcities=" + predefinedCities.size()
                + ", predefinedspheres=" + predefinedSpheres.size();
    }

    private static String norm(String name) {
        return PathSecurity.normalizeResourceId(name, "lostcities");
    }
}
