/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.compat;

import io.papermc.paper.registry.RegistryAccess;
import io.papermc.paper.registry.RegistryKey;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.Biome;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.loot.LootTable;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.plugin.PluginManager;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Default Paper 26.3 implementation of {@link PaperApiAdapter}.
 */
public final class Paper263ApiAdapter implements PaperApiAdapter {

    @Override
    public @NotNull WorldCreator createWorldCreator(@NotNull String worldName,
                                                    @Nullable NamespacedKey worldKey,
                                                    long seed,
                                                    @NotNull ChunkGenerator generator,
                                                    @Nullable BiomeProvider biomeProvider) {
        NamespacedKey resolvedKey = worldKey != null
                ? worldKey
                : new NamespacedKey("lostcities", sanitizeKeyPath(worldName));
        WorldCreator creator = new WorldCreator(resolvedKey);
        creator.environment(World.Environment.NORMAL);
        creator.seed(seed);
        creator.generator(generator);
        if (biomeProvider != null) {
            creator.biomeProvider(biomeProvider);
        }
        return creator;
    }

    @Override
    public @NotNull Biome resolveBiome(@NotNull String namespacedId) {
        NamespacedKey key = NamespacedKey.fromString(namespacedId.toLowerCase(Locale.ROOT));
        if (key == null) {
            return Biome.PLAINS;
        }
        try {
            Registry<Biome> registry = RegistryAccess.registryAccess().getRegistry(RegistryKey.BIOME);
            Biome found = registry.get(key);
            if (found != null) {
                return found;
            }
        } catch (Throwable ignored) {
            // Safe fallback when invoked outside a running Paper server
        }
        return Biome.PLAINS;
    }

    @Override
    public @NotNull String getBiomeKey(@NotNull Biome biome) {
        try {
            return biome.getKey().asString();
        } catch (Throwable ignored) {
            return "minecraft:plains";
        }
    }

    @Override
    public @NotNull List<Biome> getAvailableBiomes() {
        List<Biome> result = new ArrayList<>();
        try {
            Registry<Biome> registry = RegistryAccess.registryAccess().getRegistry(RegistryKey.BIOME);
            for (Biome biome : registry) {
                if (biome != null && !"minecraft:custom".equals(getBiomeKey(biome))) {
                    result.add(biome);
                }
            }
        } catch (Throwable ignored) {
            result.add(Biome.PLAINS);
        }
        if (result.isEmpty()) {
            result.add(Biome.PLAINS);
        }
        return Collections.unmodifiableList(result);
    }

    @Override
    public @Nullable LootTable lookupLootTable(@NotNull NamespacedKey key) {
        try {
            return Bukkit.getLootTable(key);
        } catch (Throwable ignored) {
            return null;
        }
    }

    @Override
    public void registerPermission(@NotNull String node, @NotNull String description, @NotNull PermissionDefault defaultValue) {
        PluginManager pm = Bukkit.getPluginManager();
        if (pm.getPermission(node) == null) {
            pm.addPermission(new Permission(node, description, defaultValue));
        }
    }

    @Override
    public @NotNull String getAdapterName() {
        return "Paper263ApiAdapter";
    }

    private static String sanitizeKeyPath(String raw) {
        String lower = raw.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_./-]", "_");
        return lower.isEmpty() ? "lostcity" : lower;
    }
}
