/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper;

import mcjty.lostcities.paper.assets.AssetLoader;
import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.command.CommandRegistrar;
import mcjty.lostcities.paper.compat.Paper263ApiAdapter;
import mcjty.lostcities.paper.compat.PaperApiAdapter;
import mcjty.lostcities.paper.config.ConfigLoader;
import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.config.PluginConfig;
import mcjty.lostcities.paper.core.GlobalTodo;
import mcjty.lostcities.paper.generator.LostCitiesChunkGenerator;
import mcjty.lostcities.paper.generator.WorldDimensionState;
import mcjty.lostcities.paper.loot.LootBridge;
import mcjty.lostcities.paper.spawn.BedTeleportListener;
import mcjty.lostcities.paper.spawn.SpawnHandler;
import mcjty.lostcities.paper.util.Metrics;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.WorldUnloadEvent;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.net.JarURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * Main Paper 26.3 plugin entrypoint wiring assets, profiles, chunk generation,
 * main-thread GlobalTodo draining, spawn handling, loot bridging, and Brigadier commands.
 */
public final class LostCitiesPlugin extends JavaPlugin implements Listener {

    private final PaperApiAdapter apiAdapter = new Paper263ApiAdapter();
    private final AtomicReference<PluginConfig> pluginConfig = new AtomicReference<>(PluginConfig.defaults());
    private final AtomicReference<Map<String, LostCityProfile>> profiles = new AtomicReference<>(Collections.emptyMap());
    private final AtomicReference<AssetRegistry> assetRegistry = new AtomicReference<>();
    private final ConcurrentHashMap<UUID, WorldDimensionState> dimensions = new ConcurrentHashMap<>();
    private final GlobalTodo globalTodo = new GlobalTodo();
    private final Metrics metrics = new Metrics();
    private final AtomicBoolean debugEnabled = new AtomicBoolean(false);

    private ConfigLoader configLoader;
    private SpawnHandler spawnHandler;
    private LootBridge lootBridge;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        reloadConfig();
        PluginConfig cfg = PluginConfig.fromYaml(getConfig());
        pluginConfig.set(cfg);
        debugEnabled.set(cfg.debug());

        registerPermissions();

        Path dataDir = getDataFolder().toPath().toAbsolutePath().normalize();
        extractBuiltinAssetsIfMissing(dataDir);

        configLoader = new ConfigLoader(dataDir, cfg.maxJsonFileBytes(), getLogger());
        configLoader.ensureDefaultProfilesExtracted(getClassLoader());
        profiles.set(configLoader.loadProfiles());

        Path assetsRoot = dataDir.resolve("data").resolve("lostcities").resolve("lostcities");
        AssetRegistry loaded = new AssetLoader(assetsRoot, cfg.maxJsonFileBytes(), getLogger()).loadAll();
        if (!loaded.hasCriticalAssets()) {
            getLogger().severe("Critical LostCities assets missing (" + loaded.summaryLine() + "). Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        assetRegistry.set(loaded);

        spawnHandler = new SpawnHandler(this);
        lootBridge = new LootBridge(this);
        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(spawnHandler, this);
        getServer().getPluginManager().registerEvents(lootBridge, this);
        getServer().getPluginManager().registerEvents(new BedTeleportListener(this), this);

        new CommandRegistrar(this).register();

        // Main-thread rate-limited GlobalTodo drain task (1 tick interval)
        getServer().getScheduler().runTaskTimer(this, () -> {
            int budget = pluginConfig.get().todoQueueSizePerTick();
            for (World w : Bukkit.getWorlds()) {
                if (dimensions.containsKey(w.getUID())) {
                    globalTodo.drainForWorld(w, budget);
                }
            }
        }, 1L, 1L);

        getLogger().info("LostCities-Paper v" + getPluginMeta().getVersion()
                + " enabled (" + apiAdapter.getAdapterName() + ")"
                + " | profiles=" + profiles.get().size()
                + " | defaultProfile=" + cfg.defaultProfile()
                + " | assets: " + loaded.summaryLine());
    }

    @Override
    public void onDisable() {
        getServer().getScheduler().cancelTasks(this);
        for (WorldDimensionState state : dimensions.values()) {
            state.flushPersistence(getLogger());
            state.close();
        }
        dimensions.clear();
        globalTodo.clearAll();
        getLogger().info("LostCities-Paper disabled cleanly (all tasks cancelled, persistence flushed, pools closed).");
    }

    @EventHandler
    public void onWorldUnload(WorldUnloadEvent event) {
        UUID id = event.getWorld().getUID();
        WorldDimensionState removed = dimensions.remove(id);
        if (removed != null) {
            removed.flushPersistence(getLogger());
            removed.close();
        }
        globalTodo.clearWorld(id);
    }

    @Override
    public @NotNull ChunkGenerator getDefaultWorldGenerator(@NotNull String worldName, @Nullable String id) {
        String requested = (id != null && !id.isBlank())
                ? id.trim()
                : pluginConfig.get().worldProfiles().getOrDefault(worldName, pluginConfig.get().defaultProfile());
        return new LostCitiesChunkGenerator(this, requested);
    }

    public @Nullable World createLostCityWorld(String worldName, String profileName, long seed) {
        LostCityProfile resolved = resolveProfile(profileName);
        LostCitiesChunkGenerator gen = new LostCitiesChunkGenerator(this, resolved.getName());
        WorldCreator creator = apiAdapter.createWorldCreator(worldName, null, seed, gen, null);
        World world = creator.createWorld();
        if (world != null) {
            getOrCreateDimensionState(world, resolved.getName());
            if (!apiAdapter.hasLostCityDimensionHeight(world)) {
                getLogger().info("World '" + world.getName() + "' active with adaptive fallback height ["
                        + world.getMinHeight() + ".." + world.getMaxHeight() + "] (DEC-02).");
            }
        }
        return world;
    }

    public @NotNull WorldDimensionState getOrCreateDimensionState(@NotNull WorldInfo worldInfo, @NotNull String profileName) {
        return dimensions.computeIfAbsent(worldInfo.getUID(), id -> new WorldDimensionState(
                id,
                worldInfo.getName(),
                worldInfo.getSeed(),
                resolveProfile(profileName),
                assetRegistry.get(),
                pluginConfig.get(),
                getDataFolder().toPath(),
                getLogger()
        ));
    }

    public @Nullable WorldDimensionState getDimensionState(UUID worldId) {
        return dimensions.get(worldId);
    }

    public synchronized AssetRegistry reloadAllAssets() {
        reloadConfig();
        PluginConfig cfg = PluginConfig.fromYaml(getConfig());
        pluginConfig.set(cfg);
        Path dataDir = getDataFolder().toPath().toAbsolutePath().normalize();
        configLoader = new ConfigLoader(dataDir, cfg.maxJsonFileBytes(), getLogger());
        profiles.set(configLoader.loadProfiles());

        Path assetsRoot = dataDir.resolve("data").resolve("lostcities").resolve("lostcities");
        AssetRegistry reloaded = new AssetLoader(assetsRoot, cfg.maxJsonFileBytes(), getLogger()).loadAll();
        if (reloaded.hasCriticalAssets()) {
            assetRegistry.set(reloaded);
        } else {
            getLogger().warning("Reload rejected: critical assets missing; keeping previous snapshot.");
        }
        return assetRegistry.get();
    }

    public @NotNull PaperApiAdapter getApiAdapter() { return apiAdapter; }
    public @NotNull PluginConfig getPluginConfig() { return pluginConfig.get(); }
    public @NotNull Map<String, LostCityProfile> getProfiles() { return profiles.get(); }
    public @NotNull AssetRegistry getAssetRegistry() { return assetRegistry.get(); }
    public @NotNull ConfigLoader getConfigLoader() { return configLoader; }
    public @NotNull GlobalTodo getGlobalTodo() { return globalTodo; }
    public @NotNull Metrics getMetrics() { return metrics; }
    public @NotNull SpawnHandler getSpawnHandler() { return spawnHandler; }
    public @NotNull LootBridge getLootBridge() { return lootBridge; }
    public int getActiveWorldCount() { return dimensions.size(); }
    public boolean isDebugEnabled() { return debugEnabled.get(); }
    public void setDebugEnabled(boolean enabled) { debugEnabled.set(enabled); }

    public @NotNull LostCityProfile resolveProfile(String requestedName) {
        Map<String, LostCityProfile> map = profiles.get();
        if (requestedName != null && !requestedName.isBlank()) {
            LostCityProfile exact = map.get(requestedName.trim().toLowerCase(Locale.ROOT));
            if (exact != null) return exact;
            getLogger().warning("Unknown LostCities profile '" + requestedName + "'; falling back to '"
                    + pluginConfig.get().defaultProfile() + "'");
        }
        LostCityProfile def = map.get(pluginConfig.get().defaultProfile());
        return def != null ? def : new LostCityProfile("default");
    }

    private void registerPermissions() {
        apiAdapter.registerPermission("lostcities.locate", "Locate cities, buildings, multibuildings, and parts", PermissionDefault.OP);
        apiAdapter.registerPermission("lostcities.map", "Display ASCII city map around player", PermissionDefault.OP);
        apiAdapter.registerPermission("lostcities.stats", "View LostCities generation and cache statistics", PermissionDefault.OP);
        apiAdapter.registerPermission("lostcities.admin", "Manage LostCities worlds, profiles, debug, and reloads", PermissionDefault.OP);
        apiAdapter.registerPermission("lostcities.edit", "Use server-side building and part export commands", PermissionDefault.OP);
    }

    private void extractBuiltinAssetsIfMissing(Path dataDir) {
        URL marker = getClassLoader().getResource("data/lostcities/lostcities/worldstyles/standard.json");
        if (marker == null || !"jar".equals(marker.getProtocol())) return;
        try {
            JarURLConnection conn = (JarURLConnection) marker.openConnection();
            try (JarFile jar = conn.getJarFile()) {
                Enumeration<JarEntry> entries = jar.entries();
                while (entries.hasMoreElements()) {
                    JarEntry entry = entries.nextElement();
                    String name = entry.getName();
                    if (!entry.isDirectory() && name.startsWith("data/lostcities/") && name.endsWith(".json")) {
                        Path target = dataDir.resolve(name).normalize();
                        if (target.startsWith(dataDir) && !Files.exists(target)) {
                            Files.createDirectories(target.getParent());
                            try (InputStream in = jar.getInputStream(entry)) {
                                Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
                            }
                        }
                    }
                }
            }
        } catch (IOException ex) {
            getLogger().warning("Failed extracting built-in JSON assets: " + ex.getMessage());
        }
    }
}
