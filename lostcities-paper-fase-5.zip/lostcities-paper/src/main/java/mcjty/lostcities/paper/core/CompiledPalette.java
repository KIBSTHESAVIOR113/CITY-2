/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import mcjty.lostcities.paper.assets.AssetModels;
import mcjty.lostcities.paper.assets.AssetRegistry;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Layered compiled character-to-block lookup table (Fase 5 port):
 * Supports {@code Style.randomPalettes}, {@code CityStyle} block overrides, {@code refpalette},
 * {@code frompalette} character remapping, inline {@code part.palette}/{@code building.palette},
 * {@code variant} expansion, {@code loot}, {@code mob}, {@code torch}, and {@code tag} metadata.
 */
public final class CompiledPalette {

    public record Entry(
            String[] table128,
            String lootCondition,
            String mobCondition,
            boolean isTorch,
            boolean isDamaged,
            JsonObject blockEntityTag
    ) {
        public Entry(String[] table128, String lootCondition, String mobCondition, boolean isTorch) {
            this(table128, lootCondition, mobCondition, isTorch, false, null);
        }

        public String sample() {
            if (table128 == null || table128.length == 0) return "minecraft:air";
            if (table128.length == 1) return table128[0];
            return table128[GenerationContext.nextPaletteIndex() % table128.length];
        }
    }

    private final Map<Character, Entry> entries = new LinkedHashMap<>();

    public CompiledPalette(AssetRegistry registry, List<String> paletteNames) {
        for (String name : paletteNames) {
            AssetModels.PaletteAsset palette = registry.getPalette(name);
            if (palette != null) {
                applyPaletteAsset(registry, palette);
            }
        }
        entries.putIfAbsent(' ', new Entry(new String[]{"minecraft:air"}, "", "", false));
    }

    private CompiledPalette(Map<Character, Entry> parentEntries) {
        this.entries.putAll(parentEntries);
        entries.putIfAbsent(' ', new Entry(new String[]{"minecraft:air"}, "", "", false));
    }

    /**
     * Builds the chunk/building base palette from {@code Style.randomPalettes}, {@code CityStyle},
     * and optional {@code BuildingAsset} ref/inline palette.
     */
    public static CompiledPalette buildForBuilding(
            AssetRegistry registry,
            String styleId,
            AssetModels.CityStyleAsset cityStyle,
            AssetModels.BuildingAsset building,
            Random rand
    ) {
        List<String> selectedNames = new ArrayList<>();
        AssetModels.StyleAsset style = registry.getStyle(styleId);
        if (style != null && !style.randomPalettes().isEmpty()) {
            for (List<AssetModels.WeightedRef> group : style.randomPalettes()) {
                String picked = pickWeightedRef(group, rand);
                if (picked != null && !picked.isBlank()) {
                    selectedNames.add(picked);
                }
            }
        }
        if (selectedNames.isEmpty() && !registry.palettes().isEmpty()) {
            // Fallback to common palette if style did not declare randompalettes
            if (registry.getPalette("lostcities:common") != null) {
                selectedNames.add("lostcities:common");
            } else {
                selectedNames.add(registry.palettes().keySet().iterator().next());
            }
        }

        CompiledPalette compiled = new CompiledPalette(registry, selectedNames);

        // Apply CityStyle block overrides if present
        if (cityStyle != null && cityStyle.raw() != null && cityStyle.raw().has("palette")
                && cityStyle.raw().get("palette").isJsonArray()) {
            compiled = compiled.withInlinePalette(registry, cityStyle.raw().getAsJsonArray("palette"));
        }

        // Apply Building refpalette & inline palette
        if (building != null) {
            if (building.refPaletteName() != null && !building.refPaletteName().isBlank()) {
                AssetModels.PaletteAsset ref = registry.getPalette(building.refPaletteName());
                if (ref != null) compiled = compiled.withPalette(registry, ref);
            }
            if (building.raw() != null && building.raw().has("palette") && building.raw().get("palette").isJsonArray()) {
                compiled = compiled.withInlinePalette(registry, building.raw().getAsJsonArray("palette"));
            }
        }
        return compiled;
    }

    /** Creates an overlaid {@link CompiledPalette} with a named {@link AssetModels.PaletteAsset}. */
    public CompiledPalette withPalette(AssetRegistry registry, AssetModels.PaletteAsset overlay) {
        if (overlay == null) return this;
        CompiledPalette copy = new CompiledPalette(this.entries);
        copy.applyPaletteAsset(registry, overlay);
        return copy;
    }

    /** Creates an overlaid {@link CompiledPalette} from an inline JSON {@code "palette": [...]} array. */
    public CompiledPalette withInlinePalette(AssetRegistry registry, JsonArray paletteArray) {
        if (paletteArray == null || paletteArray.isEmpty()) return this;
        CompiledPalette copy = new CompiledPalette(this.entries);
        List<AssetModels.PaletteEntryModel> models = new ArrayList<>();
        Map<Character, JsonObject> tags = new LinkedHashMap<>();
        for (JsonElement el : paletteArray) {
            if (!el.isJsonObject()) continue;
            JsonObject eo = el.getAsJsonObject();
            String chStr = eo.has("char") ? eo.get("char").getAsString() : "";
            if (chStr.isEmpty()) continue;
            char sym = chStr.charAt(0);
            List<AssetModels.WeightedBlock> randBlocks = new ArrayList<>();
            if (eo.has("blocks") && eo.get("blocks").isJsonArray()) {
                for (JsonElement bEl : eo.getAsJsonArray("blocks")) {
                    if (bEl.isJsonObject()) {
                        JsonObject bo = bEl.getAsJsonObject();
                        int w = bo.has("random") ? bo.get("random").getAsInt() : 1;
                        String b = bo.has("block") ? bo.get("block").getAsString() : "minecraft:stone";
                        randBlocks.add(new AssetModels.WeightedBlock(w, b));
                    }
                }
            }
            models.add(new AssetModels.PaletteEntryModel(
                    sym,
                    eo.has("block") && eo.get("block").isJsonPrimitive() ? eo.get("block").getAsString() : "",
                    eo.has("variant") && eo.get("variant").isJsonPrimitive() ? eo.get("variant").getAsString() : "",
                    eo.has("frompalette") && eo.get("frompalette").isJsonPrimitive() ? eo.get("frompalette").getAsString() : "",
                    eo.has("loot") && eo.get("loot").isJsonPrimitive() ? eo.get("loot").getAsString() : "",
                    eo.has("mob") && eo.get("mob").isJsonPrimitive() ? eo.get("mob").getAsString() : "",
                    eo.has("torch") && eo.get("torch").isJsonPrimitive() && eo.get("torch").getAsBoolean(),
                    eo.has("damaged"),
                    randBlocks
            ));
            if (eo.has("tag") && eo.get("tag").isJsonObject()) {
                tags.put(sym, eo.getAsJsonObject("tag"));
            }
        }
        copy.applyModels(registry, models, tags);
        return copy;
    }

    private void applyPaletteAsset(AssetRegistry registry, AssetModels.PaletteAsset palette) {
        Map<Character, JsonObject> tags = new LinkedHashMap<>();
        if (palette.raw() != null && palette.raw().has("palette") && palette.raw().get("palette").isJsonArray()) {
            for (JsonElement el : palette.raw().getAsJsonArray("palette")) {
                if (el.isJsonObject()) {
                    JsonObject eo = el.getAsJsonObject();
                    if (eo.has("char") && eo.has("tag") && eo.get("tag").isJsonObject()) {
                        String ch = eo.get("char").getAsString();
                        if (!ch.isEmpty()) tags.put(ch.charAt(0), eo.getAsJsonObject("tag"));
                    }
                }
            }
        }
        applyModels(registry, palette.entries(), tags);
    }

    private void applyModels(AssetRegistry registry, List<AssetModels.PaletteEntryModel> models, Map<Character, JsonObject> tags) {
        List<AssetModels.PaletteEntryModel> deferredFromPalette = new ArrayList<>();
        for (AssetModels.PaletteEntryModel e : models) {
            if (e.fromPalette() != null && !e.fromPalette().isEmpty()) {
                deferredFromPalette.add(e);
            } else {
                entries.put(e.symbol(), compileEntry(registry, e, tags.get(e.symbol())));
            }
        }
        // Resolve frompalette references against already-compiled parent/sibling entries
        for (AssetModels.PaletteEntryModel e : deferredFromPalette) {
            char refChar = e.fromPalette().charAt(0);
            Entry ref = entries.get(refChar);
            if (ref != null) {
                entries.put(e.symbol(), new Entry(
                        ref.table128(),
                        !e.loot().isEmpty() ? e.loot() : ref.lootCondition(),
                        !e.mob().isEmpty() ? e.mob() : ref.mobCondition(),
                        e.torch() || ref.isTorch(),
                        e.damaged() || ref.isDamaged(),
                        tags.getOrDefault(e.symbol(), ref.blockEntityTag())
                ));
            } else {
                entries.put(e.symbol(), compileEntry(registry, e, tags.get(e.symbol())));
            }
        }
    }

    private Entry compileEntry(AssetRegistry registry, AssetModels.PaletteEntryModel e, JsonObject tag) {
        if (!e.randomBlocks().isEmpty()) {
            return new Entry(expandWeighted(e.randomBlocks()), e.loot(), e.mob(), e.torch(), e.damaged(), tag);
        }
        if (e.variant() != null && !e.variant().isBlank()) {
            AssetModels.VariantAsset v = registry.getVariant(e.variant());
            if (v != null && !v.blocks().isEmpty()) {
                return new Entry(expandWeighted(v.blocks()), e.loot(), e.mob(), e.torch(), e.damaged(), tag);
            }
        }
        String blk = (e.block() == null || e.block().isBlank()) ? "minecraft:stone_bricks" : e.block();
        return new Entry(new String[]{blk}, e.loot(), e.mob(), e.torch(), e.damaged(), tag);
    }

    private static String pickWeightedRef(List<AssetModels.WeightedRef> list, Random rand) {
        if (list == null || list.isEmpty()) return null;
        float total = 0.0f;
        for (AssetModels.WeightedRef w : list) total += Math.max(0.0f, w.factor());
        if (total <= 0.0f) return list.get(0).value();
        float roll = rand.nextFloat() * total;
        float acc = 0.0f;
        for (AssetModels.WeightedRef w : list) {
            acc += Math.max(0.0f, w.factor());
            if (roll <= acc) return w.value();
        }
        return list.get(list.size() - 1).value();
    }

    private static String[] expandWeighted(List<AssetModels.WeightedBlock> list) {
        int totalWeight = 0;
        for (AssetModels.WeightedBlock wb : list) totalWeight += Math.max(1, wb.weight());
        List<String> expanded = new ArrayList<>(128);
        for (AssetModels.WeightedBlock wb : list) {
            int count = Math.max(1, Math.round((float) Math.max(1, wb.weight()) * 128.0f / totalWeight));
            for (int i = 0; i < count && expanded.size() < 128; i++) {
                expanded.add(wb.block());
            }
        }
        while (expanded.size() < 128 && !list.isEmpty()) {
            expanded.add(list.get(0).block());
        }
        return expanded.toArray(String[]::new);
    }

    public Entry getEntry(char c) { return entries.get(c); }

    public String getBlock(char c) {
        Entry e = entries.get(c);
        return e == null ? null : e.sample();
    }
}
