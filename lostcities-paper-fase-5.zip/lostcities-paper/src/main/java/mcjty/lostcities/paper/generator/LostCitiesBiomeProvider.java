/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.generator;

import mcjty.lostcities.paper.LostCitiesPlugin;
import mcjty.lostcities.paper.compat.PaperApiAdapter;
import mcjty.lostcities.paper.core.terrain.TerrainHeightField;
import org.bukkit.block.Biome;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.WorldInfo;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * {@link BiomeProvider} driven by the exact same {@link TerrainHeightField}
 * used by {@code generateNoise}, {@code generateSurface}, and {@code BuildingInfo} (K1 / C6).
 */
public final class LostCitiesBiomeProvider extends BiomeProvider {

    private static final List<String> SUPPORTED_IDS = List.of(
            "minecraft:plains", "minecraft:forest", "minecraft:taiga", "minecraft:desert",
            "minecraft:savanna", "minecraft:swamp", "minecraft:jungle", "minecraft:badlands",
            "minecraft:snowy_plains", "minecraft:beach", "minecraft:river", "minecraft:ocean",
            "minecraft:deep_ocean", "minecraft:snowy_slopes", "minecraft:stony_peaks",
            "minecraft:jagged_peaks"
    );

    private final LostCitiesPlugin plugin;
    private final String profileName;
    private final PaperApiAdapter apiAdapter;
    private final List<Biome> biomes;

    public LostCitiesBiomeProvider(LostCitiesPlugin plugin, String profileName) {
        this.plugin = plugin;
        this.profileName = profileName;
        this.apiAdapter = plugin.getApiAdapter();
        this.biomes = SUPPORTED_IDS.stream().map(apiAdapter::resolveBiome).distinct().toList();
    }

    @Override
    public @NotNull Biome getBiome(@NotNull WorldInfo worldInfo, int x, int y, int z) {
        WorldDimensionState state = plugin.getOrCreateDimensionState(worldInfo, profileName);
        TerrainHeightField.Sample s = state.heightField().sample(x, z);
        return apiAdapter.resolveBiome(s.biomeId());
    }

    @Override
    public @NotNull List<Biome> getBiomes(@NotNull WorldInfo worldInfo) {
        return biomes;
    }
}
