/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.generator;

import mcjty.lostcities.paper.LostCitiesPlugin;
import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.core.lost.StructureAvoidance;
import mcjty.lostcities.paper.core.terrain.TerrainHeightField;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.BlockPopulator;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Random;

/**
 * Fase 3 {@link ChunkGenerator} implementing K1 Opsi (a) & K4:
 * - {@code shouldGenerateNoise = false}: base terrain generated directly from {@link TerrainHeightField}
 * - {@code shouldGenerateSurface = false}: biome-consistent top/filler blocks + Fase 3
 *   {@code LostCityTerrainFeature.shapeChunkSurface} (slope blending & city clearing) directly on {@code ChunkData}
 * - Per-chunk {@code shouldGenerateDecorations/Caves/Structures}: trees, ores, caves & structures
 *   preserved outside cities, blocked inside cities (+4-chunk buffer for vanilla structures).
 */
public final class LostCitiesChunkGenerator extends ChunkGenerator {

    private static final int STRUCTURE_BUFFER_CHUNKS = 4;

    private final LostCitiesPlugin plugin;
    private final String profileName;

    public LostCitiesChunkGenerator(LostCitiesPlugin plugin, String profileName) {
        this.plugin = plugin;
        this.profileName = profileName;
    }

    @Override
    public boolean shouldGenerateNoise(@NotNull WorldInfo worldInfo, @NotNull Random random, int chunkX, int chunkZ) {
        return false; // K1 (DEC-12): single deterministic TerrainHeightField source
    }

    @Override
    public boolean shouldGenerateSurface(@NotNull WorldInfo worldInfo, @NotNull Random random, int chunkX, int chunkZ) {
        return false;
    }

    @Override
    public boolean shouldGenerateCaves(@NotNull WorldInfo worldInfo, @NotNull Random random, int chunkX, int chunkZ) {
        WorldDimensionState state = plugin.getOrCreateDimensionState(worldInfo, profileName);
        return !state.isCityChunk(chunkX, chunkZ);
    }

    @Override
    public boolean shouldGenerateDecorations(@NotNull WorldInfo worldInfo, @NotNull Random random, int chunkX, int chunkZ) {
        WorldDimensionState state = plugin.getOrCreateDimensionState(worldInfo, profileName);
        return !state.isCityChunk(chunkX, chunkZ);
    }

    @Override
    public boolean shouldGenerateStructures(@NotNull WorldInfo worldInfo, @NotNull Random random, int chunkX, int chunkZ) {
        WorldDimensionState state = plugin.getOrCreateDimensionState(worldInfo, profileName);
        ChunkCoord coord = new ChunkCoord(state.dimensionId(), chunkX, chunkZ);
        return StructureAvoidance.shouldAllowVanillaStructures(coord, STRUCTURE_BUFFER_CHUNKS,
                c -> state.isCityChunk(c.chunkX(), c.chunkZ()));
    }

    @Override
    public boolean shouldGenerateMobs(@NotNull WorldInfo worldInfo, @NotNull Random random, int chunkX, int chunkZ) {
        return true;
    }

    @Override
    public void generateNoise(@NotNull WorldInfo worldInfo, @NotNull Random random, int chunkX, int chunkZ, @NotNull ChunkData chunkData) {
        long start = System.nanoTime();
        try {
            WorldDimensionState state = plugin.getOrCreateDimensionState(worldInfo, profileName);
            TerrainHeightField field = state.heightField();
            int minY = chunkData.getMinHeight();
            int maxY = chunkData.getMaxHeight();
            int sea = field.seaLevel();
            BlockData stone = Material.STONE.createBlockData();
            BlockData deepslate = Material.DEEPSLATE.createBlockData();
            BlockData water = Material.WATER.createBlockData();

            int baseX = chunkX << 4;
            int baseZ = chunkZ << 4;
            for (int lx = 0; lx < 16; lx++) {
                for (int lz = 0; lz < 16; lz++) {
                    TerrainHeightField.Sample s = field.sample(baseX + lx, baseZ + lz);
                    int topY = Math.min(maxY - 1, s.height());
                    int deepTop = Math.min(topY, 0);
                    if (minY < deepTop) {
                        chunkData.setRegion(lx, minY, lz, lx + 1, deepTop, lz + 1, deepslate);
                    }
                    int stoneStart = Math.max(minY, 0);
                    if (stoneStart <= topY) {
                        chunkData.setRegion(lx, stoneStart, lz, lx + 1, topY + 1, lz + 1, stone);
                    }
                    if (topY < sea && !state.profile().avoidWater) {
                        chunkData.setRegion(lx, topY + 1, lz, lx + 1, Math.min(maxY, sea + 1), lz + 1, water);
                    }
                }
            }
        } finally {
            plugin.getMetrics().recordNoiseNanos(System.nanoTime() - start);
        }
    }

    @Override
    public void generateSurface(@NotNull WorldInfo worldInfo, @NotNull Random random, int chunkX, int chunkZ, @NotNull ChunkData chunkData) {
        long start = System.nanoTime();
        try {
            WorldDimensionState state = plugin.getOrCreateDimensionState(worldInfo, profileName);
            TerrainHeightField field = state.heightField();
            int minY = chunkData.getMinHeight();
            int maxY = chunkData.getMaxHeight();
            int baseX = chunkX << 4;
            int baseZ = chunkZ << 4;
            for (int lx = 0; lx < 16; lx++) {
                for (int lz = 0; lz < 16; lz++) {
                    TerrainHeightField.Sample s = field.sample(baseX + lx, baseZ + lz);
                    int topY = Math.min(maxY - 1, s.height());
                    if (topY < minY) continue;
                    chunkData.setBlock(lx, topY, lz, LimitedRegionSurface.parseBlockData(s.topBlock()));
                    BlockData filler = LimitedRegionSurface.parseBlockData(s.fillerBlock());
                    int fillerMin = Math.max(minY, topY - 3);
                    if (fillerMin < topY) {
                        chunkData.setRegion(lx, fillerMin, lz, lx + 1, topY, lz + 1, filler);
                    }
                }
            }
            // C1 & C3: Single-pass terrain shaping in generateSurface + track BuildingInfo computes/chunk
            long biBefore = state.chunkPlanner().buildingInfoComputes();
            state.terrainFeature().shapeChunkSurface(
                    new ChunkDataSurface(chunkX, chunkZ, chunkData),
                    chunkX, chunkZ,
                    plugin.getAssetRegistry(),
                    state.chunkPlanner(),
                    state.city(),
                    field,
                    state.multiChunkCache()
            );
            long biDelta = Math.max(0L, state.chunkPlanner().buildingInfoComputes() - biBefore);
            plugin.getMetrics().recordSurfaceNanos(System.nanoTime() - start, biDelta);
            return;
        } catch (RuntimeException ex) {
            plugin.getMetrics().recordSurfaceNanos(System.nanoTime() - start, 0L);
            throw ex;
        }
    }

    @Override
    public void generateBedrock(@NotNull WorldInfo worldInfo, @NotNull Random random, int chunkX, int chunkZ, @NotNull ChunkData chunkData) {
        WorldDimensionState state = plugin.getOrCreateDimensionState(worldInfo, profileName);
        int minY = chunkData.getMinHeight();
        int layers = Math.max(1, state.profile().bedrockLayer);
        chunkData.setRegion(0, minY, 0, 16, Math.min(chunkData.getMaxHeight(), minY + layers), 16, Material.BEDROCK);
    }

    @Override
    public @Nullable BiomeProvider getDefaultBiomeProvider(@NotNull WorldInfo worldInfo) {
        return new LostCitiesBiomeProvider(plugin, profileName);
    }

    @Override
    public @NotNull List<BlockPopulator> getDefaultPopulators(@NotNull World world) {
        return List.of(
                new LostCitiesBlockPopulator(plugin, profileName),
                new LostCitiesSpherePopulator(plugin, profileName)
        );
    }
}
