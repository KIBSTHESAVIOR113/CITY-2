/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.highway;

import mcjty.lostcities.paper.core.highway.HighwayModels.*;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Bounded async planning service for inter-city highways, cleanly shut down on plugin disable.
 */
public final class HighwayPlanningService implements AutoCloseable {

    private final IntercityHighwayPlanner planner;
    private final ExecutorService executor;
    private final BoundedFutureCache<HubKey, Optional<HighwayHub>> hubCache;
    private final BoundedFutureCache<HubKey, List<HighwayRoute>> routeCache;

    public HighwayPlanningService(IntercityHighwayPlanner planner, int hubMaxEntries, int depMaxEntries, int workerThreads) {
        this.planner = planner;
        this.hubCache = new BoundedFutureCache<>(hubMaxEntries);
        this.routeCache = new BoundedFutureCache<>(depMaxEntries);
        AtomicInteger idx = new AtomicInteger(1);
        this.executor = Executors.newFixedThreadPool(Math.max(1, workerThreads), r -> {
            Thread t = new Thread(r, "LostCities-Highway-" + idx.getAndIncrement());
            t.setDaemon(true);
            return t;
        });
    }

    public CompletableFuture<Optional<HighwayHub>> getHubAsync(HubKey key) {
        return hubCache.computeIfAbsent(key, k -> CompletableFuture.supplyAsync(() -> planner.getHub(k), executor));
    }

    public CompletableFuture<List<HighwayRoute>> getRoutesAsync(HubKey owner) {
        return routeCache.computeIfAbsent(owner, k -> CompletableFuture.supplyAsync(() -> planner.getRoutesForCell(k), executor));
    }

    public HighwayInfo getHighwayInfo(int chunkX, int chunkZ) {
        HubKey center = planner.getPlanningCell(chunkX, chunkZ);
        int r = planner.searchRadiusCells();
        int xLevel = -1;
        int zLevel = -1;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                List<HighwayRoute> routes = getRoutesAsync(new HubKey(center.planningCellX() + dx, center.planningCellZ() + dz)).join();
                for (HighwayRoute route : routes) {
                    for (HighwaySegment seg : route.segments()) {
                        if (seg.contains(chunkX, chunkZ)) {
                            if (seg.axis() == HighwayAxis.X) xLevel = Math.max(xLevel, route.level());
                            else zLevel = Math.max(zLevel, route.level());
                        }
                    }
                }
            }
        }
        return (xLevel < 0 && zLevel < 0) ? HighwayInfo.NONE : new HighwayInfo(xLevel, zLevel);
    }

    public int hubCacheSize() { return hubCache.size(); }
    public int routeCacheSize() { return routeCache.size(); }

    @Override
    public void close() {
        executor.shutdownNow();
        hubCache.clear();
        routeCache.clear();
    }
}
