/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.util;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.LongAdder;

/**
 * Lock-free rolling window metrics for populator, generateNoise, and generateSurface latency (p95 ms)
 * plus per-surface-chunk BuildingInfo compute counts (C3).
 */
public final class Metrics {

    private static final int WINDOW = 1024;
    private final long[] samplesNanos = new long[WINDOW];
    private final AtomicInteger cursor = new AtomicInteger(0);
    private final LongAdder chunksGenerated = new LongAdder();
    private final LongAdder totalNanos = new LongAdder();

    private final long[] noiseNanos = new long[WINDOW];
    private final AtomicInteger noiseCursor = new AtomicInteger(0);
    private final LongAdder noiseCount = new LongAdder();

    private final long[] surfaceNanos = new long[WINDOW];
    private final AtomicInteger surfaceCursor = new AtomicInteger(0);
    private final LongAdder surfaceCount = new LongAdder();
    private final LongAdder surfaceBiComputes = new LongAdder();

    public void recordChunkNanos(long nanos) {
        int idx = Math.floorMod(cursor.getAndIncrement(), WINDOW);
        samplesNanos[idx] = nanos;
        chunksGenerated.increment();
        totalNanos.add(nanos);
    }

    public void recordNoiseNanos(long nanos) {
        int idx = Math.floorMod(noiseCursor.getAndIncrement(), WINDOW);
        noiseNanos[idx] = nanos;
        noiseCount.increment();
    }

    public void recordSurfaceNanos(long nanos) {
        recordSurfaceNanos(nanos, 0L);
    }

    public void recordSurfaceNanos(long nanos, long biComputed) {
        int idx = Math.floorMod(surfaceCursor.getAndIncrement(), WINDOW);
        surfaceNanos[idx] = nanos;
        surfaceCount.increment();
        if (biComputed > 0) surfaceBiComputes.add(biComputed);
    }

    public long chunksGenerated() { return chunksGenerated.sum(); }
    public long noiseChunksGenerated() { return noiseCount.sum(); }
    public long surfaceChunksGenerated() { return surfaceCount.sum(); }

    public double avgSurfaceBiPerChunk() {
        long sc = surfaceCount.sum();
        return sc == 0 ? 0.0 : surfaceBiComputes.sum() / (double) sc;
    }

    public double averageMs() {
        long count = chunksGenerated.sum();
        return count == 0 ? 0.0 : (totalNanos.sum() / (double) count) / 1_000_000.0;
    }

    public double p95Ms() { return computeP95(samplesNanos, chunksGenerated.sum()); }
    public double noiseP95Ms() { return computeP95(noiseNanos, noiseCount.sum()); }
    public double surfaceP95Ms() { return computeP95(surfaceNanos, surfaceCount.sum()); }

    private static double computeP95(long[] arr, long count) {
        int n = (int) Math.min(WINDOW, count);
        if (n <= 0) return 0.0;
        long[] copy = new long[n];
        System.arraycopy(arr, 0, copy, 0, n);
        Arrays.sort(copy);
        int idx = Math.min(n - 1, (int) Math.ceil(n * 0.95) - 1);
        return copy[Math.max(0, idx)] / 1_000_000.0;
    }
}
