/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.generator;

import mcjty.lostcities.paper.core.BlockSurface;
import org.bukkit.block.data.BlockData;
import org.bukkit.generator.ChunkGenerator;

/**
 * {@link BlockSurface} adapter over Paper's {@link ChunkGenerator.ChunkData} for Fase 3
 * terrain shaping during {@code generateSurface} (zero neighbor chunk loading).
 */
public final class ChunkDataSurface implements BlockSurface {

    private final int baseX;
    private final int baseZ;
    private final int minY;
    private final int maxY;
    private final ChunkGenerator.ChunkData chunkData;

    public ChunkDataSurface(int chunkX, int chunkZ, ChunkGenerator.ChunkData chunkData) {
        this.baseX = chunkX << 4;
        this.baseZ = chunkZ << 4;
        this.minY = chunkData.getMinHeight();
        this.maxY = chunkData.getMaxHeight();
        this.chunkData = chunkData;
    }

    @Override
    public int minY() { return minY; }

    @Override
    public int maxY() { return maxY; }

    @Override
    public boolean isInBounds(int worldX, int y, int worldZ) {
        int lx = worldX - baseX;
        int lz = worldZ - baseZ;
        return lx >= 0 && lx < 16 && lz >= 0 && lz < 16 && y >= minY && y < maxY;
    }

    @Override
    public String getBlockId(int worldX, int y, int worldZ) {
        if (!isInBounds(worldX, y, worldZ)) return "minecraft:air";
        BlockData data = chunkData.getBlockData(worldX - baseX, y, worldZ - baseZ);
        return data.getAsString(true);
    }

    @Override
    public void setBlockId(int worldX, int y, int worldZ, String blockId) {
        if (!isInBounds(worldX, y, worldZ)) return;
        chunkData.setBlock(worldX - baseX, y, worldZ - baseZ, LimitedRegionSurface.parseBlockData(blockId));
    }
}
