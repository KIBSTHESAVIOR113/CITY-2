/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.generator;

import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.config.HighwayGenerationMode;
import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.config.PluginConfig;
import mcjty.lostcities.paper.core.BuildingInfo;
import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.core.LostCityTerrainFeature;
import mcjty.lostcities.paper.core.highway.HighwayModels.HighwayInfo;
import mcjty.lostcities.paper.core.highway.HighwayPlanningService;
import mcjty.lostcities.paper.core.highway.HighwayStore;
import mcjty.lostcities.paper.core.highway.IntercityHighwayPlanner;
import mcjty.lostcities.paper.core.lost.BiomeInfo;
import mcjty.lostcities.paper.core.lost.City;
import mcjty.lostcities.paper.core.lost.CitySphere;
import mcjty.lostcities.paper.core.lost.Highway;
import mcjty.lostcities.paper.core.lost.MultiChunk;
import mcjty.lostcities.paper.core.lost.Railway;
import mcjty.lostcities.paper.core.plan.ChunkPlanner;
import mcjty.lostcities.paper.core.street.HierarchicalStreetPlanner;
import mcjty.lostcities.paper.core.terrain.TerrainHeightField;
import mcjty.lostcities.paper.persistence.AtomicFileStore;

import java.io.IOException;
import java.nio.file.Path;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * Single per-world owner of {@link TerrainHeightField}, {@link City}, {@link CitySphere.Cache},
 * {@link MultiChunk.Cache}, {@link Highway}, {@link Railway}, and {@link ChunkPlanner} (K4).
 */
public final class WorldDimensionState implements AutoCloseable {

    private final UUID worldId;
    private final String worldName;
    private final String dimensionId;
    private final long seed;
    private final LostCityProfile profile;
    private final TerrainHeightField heightField;
    private final CitySphere.Cache sphereCache;
    private final City city;
    private final MultiChunk.Cache multiChunkCache;
    private final Highway highway;
    private final Railway railway;
    private final BiomeInfo.Cache biomeCache;
    private final ChunkPlanner chunkPlanner;
    private final LostCityTerrainFeature terrainFeature;
    private final HierarchicalStreetPlanner streetPlanner;
    private final HighwayStore highwayStore;
    private final HighwayPlanningService highwayService;

    public WorldDimensionState(UUID worldId, String worldName, long seed, LostCityProfile profile,
                               AssetRegistry registry, PluginConfig cfg, Path pluginDataDir, Logger logger) {
        this.worldId = worldId;
        this.worldName = worldName;
        this.dimensionId = "lostcities:" + worldName;
        this.seed = seed;
        this.profile = profile;
        this.heightField = new TerrainHeightField(seed, profile);
        this.sphereCache = new CitySphere.Cache(seed, profile, registry, cfg.cityMaxEntries(), cfg.cacheTtlSeconds());
        this.city = new City(seed, profile, registry, sphereCache, cfg.cityMaxEntries(), cfg.cacheTtlSeconds());
        this.multiChunkCache = new MultiChunk.Cache(cfg.cityMaxEntries(), cfg.cacheTtlSeconds());
        this.highway = new Highway(seed, cfg.highwayHubMaxEntries(), cfg.cacheTtlSeconds());
        this.railway = new Railway(seed, cfg.chunkPlanMaxEntries(), cfg.cacheTtlSeconds());
        this.biomeCache = new BiomeInfo.Cache(cfg.chunkPlanMaxEntries(), cfg.cacheTtlSeconds());
        this.chunkPlanner = new ChunkPlanner(cfg.chunkPlanMaxEntries(), cfg.cacheTtlSeconds());
        this.terrainFeature = new LostCityTerrainFeature(seed, dimensionId, profile);
        this.streetPlanner = new HierarchicalStreetPlanner(seed, dimensionId, profile);

        if (profile.highwayGenerationMode == HighwayGenerationMode.INTERCITY_NETWORK_V1) {
            Path worldDataDir = pluginDataDir.resolve("data").resolve(worldId.toString());
            AtomicFileStore store = new AtomicFileStore(worldDataDir, cfg.maxJsonFileBytes(), logger);
            long sig = seed ^ (long) profile.getName().hashCode() * 31L ^ profile.highwayPlanningCellSize;
            this.highwayStore = new HighwayStore(store, sig);
            IntercityHighwayPlanner planner = new IntercityHighwayPlanner(seed, dimensionId, profile, highwayStore, this.city);
            this.highwayService = new HighwayPlanningService(
                    planner, cfg.highwayHubMaxEntries(), cfg.highwayDependencyMaxEntries(), cfg.highwayWorkerThreads());
        } else {
            this.highwayStore = null;
            this.highwayService = null;
        }
    }

    public UUID worldId() { return worldId; }
    public String worldName() { return worldName; }
    public String dimensionId() { return dimensionId; }
    public long seed() { return seed; }
    public LostCityProfile profile() { return profile; }
    public TerrainHeightField heightField() { return heightField; }
    public CitySphere.Cache sphereCache() { return sphereCache; }
    public City city() { return city; }
    public MultiChunk.Cache multiChunkCache() { return multiChunkCache; }
    public Highway highway() { return highway; }
    public Railway railway() { return railway; }
    public BiomeInfo.Cache biomeCache() { return biomeCache; }
    public ChunkPlanner chunkPlanner() { return chunkPlanner; }
    public LostCityTerrainFeature terrainFeature() { return terrainFeature; }
    public HierarchicalStreetPlanner streetPlanner() { return streetPlanner; }
    public HighwayPlanningService highwayService() { return highwayService; }

    public boolean isCityChunk(int chunkX, int chunkZ) {
        ChunkCoord c = new ChunkCoord(dimensionId, chunkX, chunkZ);
        int h = heightField.sampleChunkCenterHeight(c);
        return h >= profile.cityMinHeight && h <= profile.cityMaxHeight && city.isCityChunk(c, k -> 1.0);
    }

    public BuildingInfo getBuildingInfo(int chunkX, int chunkZ, AssetRegistry registry) {
        ChunkCoord coord = new ChunkCoord(dimensionId, chunkX, chunkZ);
        HighwayInfo hw = highway.computeHighwayInfo(
                coord, profile, highwayService,
                c -> city.isCityChunk(c, k -> 1.0),
                c -> BuildingInfo.computeCityLevel(c, seed, profile, heightField.sampleChunkCenterHeight(c)),
                c -> sphereCache.getCitySphere(c).isOnBorder(c.chunkX(), c.chunkZ())
        );
        return BuildingInfo.get(coord, seed, profile, registry, chunkPlanner, city, heightField, multiChunkCache, hw, Railway.RailChunkInfo.NOTHING);
    }

    public void flushPersistence(Logger logger) {
        if (highwayStore != null) {
            try {
                highwayStore.flushIfDirty();
            } catch (IOException ex) {
                logger.warning("Failed flushing highway persistence for world '" + worldName + "': " + ex.getMessage());
            }
        }
    }

    @Override
    public void close() {
        if (highwayService != null) highwayService.close();
        chunkPlanner.clear();
        city.clearCache();
        sphereCache.clear();
        multiChunkCache.clear();
        highway.clearCache();
        railway.clearCache();
        biomeCache.clear();
    }
}
