/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.lost;

import mcjty.lostcities.paper.assets.AssetModels;
import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.util.BoundedCache;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToIntFunction;

/**
 * Full port of {@code mcjty.lostcities.worldgen.lost.MultiChunk} (L1-231) including
 * sorted {@code CityStyle} frequency weighting, largest-first sorting, {@code correctStyleFactor},
 * and city-level consistency checks.
 */
public final class MultiChunk {

    public record MB(String name, int offsetX, int offsetZ, int dimX, int dimZ) {}

    public record Settings(int areaSize, int minimum, int maximum, float correctStyleFactor, int attempts) {
        public static final Settings DEFAULT = new Settings(8, 1, 2, 0.5f, 20);
    }

    private final ChunkCoord topleft;
    private final int areaSize;
    private final MB[][] grid;

    private MultiChunk(ChunkCoord mc, int areaSize) {
        this.areaSize = Math.max(4, areaSize);
        this.topleft = new ChunkCoord(mc.dimensionId(), mc.chunkX() * this.areaSize, mc.chunkZ() * this.areaSize);
        this.grid = new MB[this.areaSize][this.areaSize];
    }

    public MB getMultiBuilding(ChunkCoord coord) {
        int lx = coord.chunkX() - topleft.chunkX();
        int lz = coord.chunkZ() - topleft.chunkZ();
        if (lx < 0 || lx >= areaSize || lz < 0 || lz >= areaSize) {
            return null;
        }
        return grid[lx][lz];
    }

    private void calculate(
            AssetRegistry registry,
            Settings settings,
            Function<ChunkCoord, String> cityStyleIdProvider,
            Function<String, List<String>> styleMultiBuildingsProvider,
            ToIntFunction<ChunkCoord> cityLevelProvider,
            Predicate<ChunkCoord> canPlaceChunk
    ) {
        // Exact seed constants from MultiChunk.java:70
        int mcX = Math.floorDiv(topleft.chunkX(), areaSize);
        int mcZ = Math.floorDiv(topleft.chunkZ(), areaSize);
        Random rand = new Random(mcX * 797013493L + mcZ * 295085213L);

        int min = Math.max(0, settings.minimum());
        int max = Math.max(min, settings.maximum());
        int cnt = min + rand.nextInt(max - min + 1);
        if (cnt <= 0 || registry.multiBuildings().isEmpty()) {
            return;
        }

        int baseCityLevel = cityLevelProvider.applyAsInt(topleft);

        // Count city styles deterministically across the NxN macro-area (L90-104)
        Map<String, Integer> styleCounts = new LinkedHashMap<>();
        String[][] chunkStyles = new String[areaSize][areaSize];
        for (int x = 0; x < areaSize; x++) {
            for (int z = 0; z < areaSize; z++) {
                String st = cityStyleIdProvider.apply(topleft.offset(x, z));
                chunkStyles[x][z] = st;
                styleCounts.merge(st, 1, Integer::sum);
            }
        }

        List<String> sortedStyles = new ArrayList<>(styleCounts.keySet());
        sortedStyles.sort(Comparator.naturalOrder());

        record Candidate(AssetModels.MultiBuildingAsset mb, String styleId) {}
        List<Candidate> chosen = new ArrayList<>();
        for (int i = 0; i < cnt; i++) {
            String styleId = pickWeightedStyle(rand, sortedStyles, styleCounts);
            List<String> allowed = styleMultiBuildingsProvider.apply(styleId);
            if (allowed == null || allowed.isEmpty()) {
                allowed = new ArrayList<>(registry.multiBuildings().keySet());
            }
            if (allowed.isEmpty()) continue;
            String mbId = allowed.get(rand.nextInt(allowed.size()));
            AssetModels.MultiBuildingAsset mb = registry.getMultiBuilding(mbId);
            if (mb != null) {
                chosen.add(new Candidate(mb, styleId));
            }
        }

        // Largest-first sorting (MultiChunk.java:118)
        chosen.sort((a, b) -> Integer.compare(b.mb().dimX() + b.mb().dimZ(), a.mb().dimX() + a.mb().dimZ()));

        for (Candidate c : chosen) {
            int dimX = Math.max(1, c.mb().dimX());
            int dimZ = Math.max(1, c.mb().dimZ());
            if (dimX > areaSize || dimZ > areaSize) continue;
            for (int att = 0; att < Math.max(1, settings.attempts()); att++) {
                int x = rand.nextInt(areaSize - dimX + 1);
                int z = rand.nextInt(areaSize - dimZ + 1);
                if (canPlaceBuilding(x, z, dimX, dimZ, c.styleId(), baseCityLevel,
                        settings.correctStyleFactor(), chunkStyles, cityLevelProvider, canPlaceChunk)) {
                    for (int dx = 0; dx < dimX; dx++) {
                        for (int dz = 0; dz < dimZ; dz++) {
                            grid[x + dx][z + dz] = new MB(c.mb().id(), dx, dz, dimX, dimZ);
                        }
                    }
                    break;
                }
            }
        }
    }

    private boolean canPlaceBuilding(
            int ox, int oz, int dimX, int dimZ,
            String requiredStyle, int baseCityLevel, float correctStyleFactor,
            String[][] chunkStyles,
            ToIntFunction<ChunkCoord> cityLevelProvider,
            Predicate<ChunkCoord> canPlaceChunk
    ) {
        int matchingStyle = 0;
        int total = dimX * dimZ;
        for (int dx = 0; dx < dimX; dx++) {
            for (int dz = 0; dz < dimZ; dz++) {
                if (grid[ox + dx][oz + dz] != null) return false;
                ChunkCoord cc = topleft.offset(ox + dx, oz + dz);
                if (!canPlaceChunk.test(cc)) return false;
                if (cityLevelProvider.applyAsInt(cc) != baseCityLevel) return false;
                if (requiredStyle != null && requiredStyle.equals(chunkStyles[ox + dx][oz + dz])) {
                    matchingStyle++;
                }
            }
        }
        return total > 0 && ((float) matchingStyle / total) >= correctStyleFactor;
    }

    private static String pickWeightedStyle(Random rand, List<String> styles, Map<String, Integer> counts) {
        int total = 0;
        for (String s : styles) total += counts.getOrDefault(s, 0);
        if (total <= 0) return styles.get(0);
        int roll = rand.nextInt(total);
        int acc = 0;
        for (String s : styles) {
            acc += counts.getOrDefault(s, 0);
            if (roll < acc) return s;
        }
        return styles.get(styles.size() - 1);
    }

    public static final class Cache {
        private final BoundedCache<ChunkCoord, MultiChunk> cache;

        public Cache(int maxEntries, int ttlSeconds) {
            this.cache = new BoundedCache<>(maxEntries, ttlSeconds);
        }

        public MultiChunk getOrCreate(
                ChunkCoord coord,
                Settings settings,
                AssetRegistry registry,
                Function<ChunkCoord, String> cityStyleIdProvider,
                Function<String, List<String>> styleMultiBuildingsProvider,
                ToIntFunction<ChunkCoord> cityLevelProvider,
                Predicate<ChunkCoord> canPlaceChunk
        ) {
            int size = Math.max(4, settings.areaSize());
            ChunkCoord mc = new ChunkCoord(coord.dimensionId(),
                    Math.floorDiv(coord.chunkX(), size),
                    Math.floorDiv(coord.chunkZ(), size));
            return cache.computeIfAbsent(mc, key -> {
                MultiChunk chunk = new MultiChunk(key, size);
                chunk.calculate(registry, settings, cityStyleIdProvider, styleMultiBuildingsProvider, cityLevelProvider, canPlaceChunk);
                return chunk;
            });
        }

        public void clear() { cache.clear(); }
    }
}
