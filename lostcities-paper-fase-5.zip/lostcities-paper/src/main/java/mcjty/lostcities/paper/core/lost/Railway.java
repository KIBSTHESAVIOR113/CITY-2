/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.lost;

import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.util.BoundedCache;
import mcjty.lostcities.paper.util.DeterministicRandom;

import java.util.function.Predicate;
import java.util.function.ToIntFunction;

import static mcjty.lostcities.paper.core.lost.RailChunkType.*;
import static mcjty.lostcities.paper.core.lost.Railway.RailDirection.*;

/**
 * Port of {@code mcjty.lostcities.worldgen.lost.Railway} state machine preserving exact
 * seed constants (2600003897L, 43600002517L), {@code RAILWAY_LEVEL_OFFSET = -3},
 * and station/extension thresholds (0.5f and 0.4f).
 */
public final class Railway {

    public static final int RAILWAY_LEVEL_OFFSET = -3;

    public enum RailDirection { BI, WEST, EAST }

    public record RailChunkInfo(RailChunkType type, RailDirection direction, int level, int rails, boolean openRoof) {
        public static final RailChunkInfo NOTHING = new RailChunkInfo(NONE, BI, 0, 0, false);

        public RailChunkInfo(RailChunkType type, RailDirection direction, int level, int rails) {
            this(type, direction, level, rails, false);
        }
    }

    public interface Context {
        boolean isCityRaw(ChunkCoord coord);
        int getCityLevel(ChunkCoord coord);
        int getHighwayXLevel(ChunkCoord coord);
        int getHighwayZLevel(ChunkCoord coord);
        boolean isOnSphereBorder(ChunkCoord coord);
    }

    private final long seed;
    private final BoundedCache<ChunkCoord, RailChunkInfo> cache;

    public Railway(long seed, int maxEntries, int ttlSeconds) {
        this.seed = seed;
        this.cache = new BoundedCache<>(maxEntries, ttlSeconds);
    }

    public static int getRailwayLevel(LostCityProfile profile) {
        return RAILWAY_LEVEL_OFFSET + profile.railwayLevelOffset;
    }

    public RailChunkInfo getRailChunkType(ChunkCoord coord, LostCityProfile profile, Context ctx) {
        RailChunkInfo cached = cache.get(coord);
        if (cached != null) return cached;

        RailChunkInfo info = computeInternal(coord, profile, ctx);
        if ((profile.isSpace() || profile.isSpheres()) && ctx.isOnSphereBorder(coord)) {
            info = RailChunkInfo.NOTHING;
        } else if (info.type().isStation()) {
            if (!profile.railwayStationsEnabled) {
                info = RailChunkInfo.NOTHING;
            }
        } else {
            if (!profile.railwaysEnabled) {
                info = RailChunkInfo.NOTHING;
            }
        }
        cache.put(coord, info);
        return info;
    }

    private RailChunkInfo computeInternal(ChunkCoord key, LostCityProfile profile, Context ctx) {
        int chunkX = key.chunkX();
        int chunkZ = key.chunkZ();
        // Exact seed from Railway.java:107
        DeterministicRandom.QualityRandom randomRailChunkType = new DeterministicRandom.QualityRandom(
                seed + chunkZ * 2600003897L + chunkX * 43600002517L);

        int railwayLevel = getRailwayLevel(profile);
        float r = randomRailChunkType.nextFloat();

        int spacingX = Math.max(LostCityProfile.MIN_RAILWAY_SPACING, profile.railwaySpacingEastWest);
        int spacingZ = Math.max(LostCityProfile.MIN_RAILWAY_SPACING, profile.railwaySpacingNorthSouth);
        int halfSpacingX = spacingX / 2;
        int mx = Math.floorMod(chunkX + 1, spacingX * 2);
        int mz = Math.floorMod(chunkZ + 1, spacingZ * 2);

        if (mx == 0 && mz == spacingZ) {
            if (!ctx.isCityRaw(key)) {
                if (profile.railwaysCanEnd) {
                    boolean cityEast = ctx.isCityRaw(key.offset(spacingX, 0))
                            || ctx.isCityRaw(key.offset(spacingX, -spacingZ))
                            || ctx.isCityRaw(key.offset(spacingX, spacingZ));
                    boolean cityWest = ctx.isCityRaw(key.offset(-spacingX, 0))
                            || ctx.isCityRaw(key.offset(-spacingX, -spacingZ))
                            || ctx.isCityRaw(key.offset(-spacingX, spacingZ));
                    if (!cityEast && !cityWest) return RailChunkInfo.NOTHING;
                    if (!cityEast) return new RailChunkInfo(RAILS_END_HERE, WEST, railwayLevel, 3);
                    if (!cityWest) return new RailChunkInfo(RAILS_END_HERE, EAST, railwayLevel, 3);
                }
                return new RailChunkInfo(HORIZONTAL, BI, railwayLevel, 3);
            }
            return getStationType(key, profile, ctx, r, 3, randomRailChunkType.nextFloat() < 0.5f);
        }
        if (mx == spacingX && mz == 0) {
            if (!ctx.isCityRaw(key)) {
                if (profile.railwaysCanEnd) {
                    boolean cityEast = ctx.isCityRaw(key.offset(spacingX, -spacingZ))
                            || ctx.isCityRaw(key.offset(spacingX, spacingZ));
                    boolean cityWest = ctx.isCityRaw(key.offset(-spacingX, -spacingZ))
                            || ctx.isCityRaw(key.offset(-spacingX, spacingZ));
                    if (!cityEast && !cityWest) return RailChunkInfo.NOTHING;
                    if (!cityEast) return new RailChunkInfo(RAILS_END_HERE, WEST, railwayLevel, 2);
                    if (!cityWest) return new RailChunkInfo(RAILS_END_HERE, EAST, railwayLevel, 2);
                }
                return new RailChunkInfo(HORIZONTAL, BI, railwayLevel, 2);
            }
            return getStationType(key, profile, ctx, r, 2, randomRailChunkType.nextFloat() < 0.5f);
        }
        if (mx == spacingX && mz == spacingZ) {
            if (!ctx.isCityRaw(key)) {
                if (profile.railwaysCanEnd) {
                    boolean cityEast = ctx.isCityRaw(key.offset(spacingX, 0));
                    boolean cityWest = ctx.isCityRaw(key.offset(-spacingX, 0));
                    if (!cityEast && !cityWest) return RailChunkInfo.NOTHING;
                    if (!cityEast) return new RailChunkInfo(RAILS_END_HERE, WEST, railwayLevel, 1);
                    if (!cityWest) return new RailChunkInfo(RAILS_END_HERE, EAST, railwayLevel, 1);
                }
                return new RailChunkInfo(HORIZONTAL, BI, railwayLevel, 1);
            }
            return getStationType(key, profile, ctx, r, 1, randomRailChunkType.nextFloat() < 0.5f);
        }
        if (mx == 0 && mz == 0) {
            return RailChunkInfo.NOTHING;
        }

        if (mz == 0 || mz == spacingZ) {
            if ((mx >= spacingX + halfSpacingX + 1 && mz != 0)
                    || (mx >= halfSpacingX + 1 && mx < spacingX)) {
                RailChunkInfo adjacent = getRailChunkType(key.east(), profile, ctx);
                RailDirection dir = adjacent.direction();
                if (dir == BI || adjacent.type() == RAILS_END_HERE) dir = WEST;
                return testAdjacentRailChunk(r, adjacent, dir, key.west(), profile, ctx);
            }
            if ((mx >= 1 && mx < halfSpacingX && mz != 0)
                    || (mx > spacingX && mx < spacingX + halfSpacingX)) {
                RailChunkInfo adjacent = getRailChunkType(key.west(), profile, ctx);
                RailDirection dir = adjacent.direction();
                if (dir == BI || adjacent.type() == RAILS_END_HERE) dir = EAST;
                return testAdjacentRailChunk(r, adjacent, dir, key.east(), profile, ctx);
            }
            if (mz == 0 && mx == halfSpacingX) {
                if (profile.railwaysCanEnd) {
                    boolean cityWest = ctx.isCityRaw(key.offset(-halfSpacingX, -spacingZ))
                            || ctx.isCityRaw(key.offset(-halfSpacingX, spacingZ));
                    boolean cityEast = ctx.isCityRaw(key.offset(halfSpacingX, 0));
                    if (!cityEast && !cityWest) return RailChunkInfo.NOTHING;
                }
                return new RailChunkInfo(DOUBLE_BEND, EAST, railwayLevel, 1);
            }
            if (mz == 0 && mx == spacingX + halfSpacingX) {
                if (profile.railwaysCanEnd) {
                    boolean cityEast = ctx.isCityRaw(key.offset(halfSpacingX, -spacingZ))
                            || ctx.isCityRaw(key.offset(halfSpacingX, spacingZ));
                    boolean cityWest = ctx.isCityRaw(key.offset(-halfSpacingX, 0));
                    if (!cityEast && !cityWest) return RailChunkInfo.NOTHING;
                }
                return new RailChunkInfo(DOUBLE_BEND, WEST, railwayLevel, 1);
            }
            if (mz == spacingZ && mx == halfSpacingX) {
                if (profile.railwaysCanEnd) {
                    boolean cityEast = ctx.isCityRaw(key.offset(halfSpacingX, 0));
                    boolean cityWest = ctx.isCityRaw(key.offset(-halfSpacingX, 0));
                    if (!cityEast && !cityWest) {
                        if (getRailChunkType(key.offset(0, -spacingZ), profile, ctx).type() == NONE
                                && getRailChunkType(key.offset(0, spacingZ), profile, ctx).type() == NONE) {
                            return RailChunkInfo.NOTHING;
                        }
                    }
                }
                return new RailChunkInfo(THREE_SPLIT, EAST, railwayLevel, 3);
            }
            if (mz == spacingZ && mx == spacingX + halfSpacingX) {
                if (profile.railwaysCanEnd) {
                    boolean cityEast = ctx.isCityRaw(key.offset(halfSpacingX, 0));
                    boolean cityWest = ctx.isCityRaw(key.offset(-halfSpacingX, 0));
                    if (!cityEast && !cityWest) {
                        if (getRailChunkType(key.offset(0, -spacingZ), profile, ctx).type() == NONE
                                && getRailChunkType(key.offset(0, spacingZ), profile, ctx).type() == NONE) {
                            return RailChunkInfo.NOTHING;
                        }
                    }
                }
                return new RailChunkInfo(THREE_SPLIT, WEST, railwayLevel, 3);
            }
            return RailChunkInfo.NOTHING;
        }
        if (mx == halfSpacingX) {
            if (profile.railwaysCanEnd) {
                if (getRailChunkType(key.offset(0, -(mz % spacingZ)), profile, ctx).type() == NONE
                        || getRailChunkType(key.offset(0, -(mz % spacingZ) + spacingZ), profile, ctx).type() == NONE) {
                    return RailChunkInfo.NOTHING;
                }
            }
            return new RailChunkInfo(VERTICAL, EAST, railwayLevel, 1);
        }
        if (mx == spacingX + halfSpacingX) {
            if (profile.railwaysCanEnd) {
                if (getRailChunkType(key.offset(0, -(mz % spacingZ)), profile, ctx).type() == NONE
                        || getRailChunkType(key.offset(0, -(mz % spacingZ) + spacingZ), profile, ctx).type() == NONE) {
                    return RailChunkInfo.NOTHING;
                }
            }
            return new RailChunkInfo(VERTICAL, WEST, railwayLevel, 1);
        }
        return RailChunkInfo.NOTHING;
    }

    private RailChunkInfo getStationType(ChunkCoord coord, LostCityProfile profile, Context ctx, float r, int rails, boolean openStation) {
        int cityLevel = ctx.getCityLevel(coord);
        int railwayLevel = getRailwayLevel(profile);
        int maximumDescent = profile.railwaySpacingEastWest - 2;
        if (cityLevel > 2 || cityLevel - railwayLevel > maximumDescent || !profile.railwaySurfaceStationsEnabled) {
            return new RailChunkInfo(STATION_UNDERGROUND, BI, railwayLevel, rails);
        }
        int hx = ctx.getHighwayXLevel(coord);
        int hz = ctx.getHighwayZLevel(coord);
        if ((hx != -1 && cityLevel >= hx) || (hz != -1 && cityLevel >= hz)) {
            return new RailChunkInfo(STATION_UNDERGROUND, BI, railwayLevel, rails);
        }
        int hwWest = ctx.getHighwayZLevel(coord.west());
        int hwEast = ctx.getHighwayZLevel(coord.east());
        if ((hwWest != -1 && cityLevel >= hwWest) || (hwEast != -1 && cityLevel >= hwEast)) {
            return new RailChunkInfo(STATION_UNDERGROUND, BI, railwayLevel, rails);
        }
        // Exact 0.5f threshold from Railway.java:331
        return r < 0.5f
                ? new RailChunkInfo(STATION_SURFACE, BI, cityLevel, rails, !openStation)
                : new RailChunkInfo(STATION_UNDERGROUND, BI, railwayLevel, rails);
    }

    private RailChunkInfo testAdjacentRailChunk(float r, RailChunkInfo adjacent, RailDirection direction,
                                                ChunkCoord nextCoord, LostCityProfile profile, Context ctx) {
        int railwayLevel = getRailwayLevel(profile);
        return switch (adjacent.type()) {
            case NONE -> RailChunkInfo.NOTHING;
            case STATION_SURFACE -> {
                int hx = ctx.getHighwayXLevel(nextCoord);
                int hz = ctx.getHighwayZLevel(nextCoord);
                if ((hx != -1 && adjacent.level() == hx) || (hz != -1 && adjacent.level() == hz)) {
                    r = 1.0f;
                }
                int maxDescentAfterExt = profile.railwaySpacingEastWest - 4;
                // Exact 0.4f threshold from Railway.java:375
                if (r < 0.4f && adjacent.level() - railwayLevel <= maxDescentAfterExt) {
                    yield new RailChunkInfo(STATION_EXTENSION_SURFACE, direction, adjacent.level(), adjacent.rails());
                }
                yield startDescending(adjacent, direction, railwayLevel);
            }
            case STATION_UNDERGROUND -> r < 0.4f
                    ? new RailChunkInfo(STATION_EXTENSION_UNDERGROUND, direction, adjacent.level(), adjacent.rails())
                    : new RailChunkInfo(HORIZONTAL, direction, adjacent.level(), adjacent.rails());
            case STATION_EXTENSION_SURFACE -> startDescending(adjacent, direction, railwayLevel);
            case STATION_EXTENSION_UNDERGROUND -> new RailChunkInfo(HORIZONTAL, direction, adjacent.level(), adjacent.rails());
            case GOING_DOWN_FURTHER, GOING_DOWN_ONE_FROM_SURFACE, GOING_DOWN_TWO_FROM_SURFACE ->
                    adjacent.level() == railwayLevel
                            ? new RailChunkInfo(HORIZONTAL, direction, adjacent.level(), adjacent.rails())
                            : new RailChunkInfo(GOING_DOWN_FURTHER, direction, adjacent.level() - 2, adjacent.rails());
            case RAILS_END_HERE -> direction == adjacent.direction()
                    ? new RailChunkInfo(HORIZONTAL, direction, adjacent.level(), adjacent.rails())
                    : RailChunkInfo.NOTHING;
            case HORIZONTAL -> adjacent;
            default -> throw new IllegalStateException("Unexpected adjacent rail chunk type: " + adjacent.type());
        };
    }

    private static RailChunkInfo startDescending(RailChunkInfo adjacent, RailDirection direction, int railwayLevel) {
        int difference = adjacent.level() - railwayLevel;
        if ((difference & 1) == 1) {
            return new RailChunkInfo(GOING_DOWN_ONE_FROM_SURFACE, direction, adjacent.level() - 1, adjacent.rails());
        }
        return new RailChunkInfo(GOING_DOWN_TWO_FROM_SURFACE, direction, adjacent.level() - 2, adjacent.rails());
    }

    public void clearCache() { cache.clear(); }
}
