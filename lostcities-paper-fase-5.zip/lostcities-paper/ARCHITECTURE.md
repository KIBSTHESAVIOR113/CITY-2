# ARCHITECTURE — LostCities Port (Fabric 26.3-12.0.2 -> Paper 26.3)

Sumber referensi: `LostCities 26.3-12.0.2-fabric` (MIT, McJty) | Target: Plugin Paper 26.3 (Java 25, klien vanilla).

## 1. Ringkasan Arsitektur Sumber vs Target

Pada Fabric 26.3, LostCities **tidak** mengganti `ChunkGenerator` vanilla secara langsung `[PASTI: terlihat di LostCities.java, Registration.java, data/lostcities/dimension/lostcity.json]`. Mod mendaftarkan dua `Feature` (`lostcities:lostcity` dan `lostcities:spheres`) yang disuntikkan ke seluruh biome bertag `#minecraft:is_overworld` via `BiomeModifications.addFeature` pada tahap `GenerationStep.Decoration.RAW_GENERATION` dan `TOP_LAYER_MODIFICATION` `[PASTI: terlihat di LostCities.java:60-65]`. Dimensi `lostcities:lostcity` memakai `minecraft:noise` preset `minecraft:overworld` dengan `dimension_type` kustom `lostcities:lostcity` (`min_y: 0`, `height: 256`, `logical_height: 256`) `[PASTI: terlihat di data/lostcities/dimension/lostcity.json dan dimension_type/lostcity.json]`.

Pada Paper 26.3, plugin tidak memiliki `BiomeModifications` Fabric maupun Mixin server (`MinecraftServerMixin`, `PlayerSpawnFinderMixin`), sehingga penulisan ulang menggunakan:
1. `LostCitiesChunkGenerator extends ChunkGenerator` dengan `shouldGenerateNoise() = true`, `shouldGenerateSurface() = true`, `shouldGenerateCaves() = true`, `shouldGenerateStructures() = true` (tergantung profil) + `LostCitiesBlockPopulator extends BlockPopulator` dan `LostCitiesSpherePopulator` yang memodifikasi terrain vanilla secara deterministik `[PASTI: kontrak ChunkGenerator & shouldGenerate* terverifikasi di Javadoc Paper 26.3]`.
2. Datapack bawaan plugin via `LifecycleEvents.DATAPACK_DISCOVERY` (bootstrapper `paper-plugin.yml`) untuk menyuplai `dimension_type/lostcity.json` (`min_y: 0`, `height: 256`) dan `loot_table/chests/*`, disertai fallback `WorldCreator` + penyesuaian offset Y dinamis (`worldInfo.getMinHeight()` / `getMaxHeight()`) bila server tidak memakai dimension type kustom `[PERLU-VERIFIKASI: perilaku DATAPACK_DISCOVERY untuk dimension_type baru di Paper 26.3 | alternatif aman: WorldCreator.ofKey + offset Y dinamis berbasis WorldInfo]`.
3. `SpawnHandler` berbasis `AsyncPlayerSpawnLocationEvent` (pengganti `PlayerSpawnLocationEvent` yang deprecated di Paper 26.3) + `PlayerJoinEvent` untuk set world spawn dan penjaminan spawn aman di kota/cavern `[PASTI: AsyncPlayerSpawnLocationEvent terverifikasi di Javadoc Paper 26.3]`.

## 2. Control Flow Generate Chunk (Sumber Fabric -> Target Paper)

### 2.1 Alur Sumber (Fabric 26.3) `[PASTI: terlihat di kode]`
1. **Inisialisasi Mod**: `LostCities.onInitialize()` -> `Registration.init()` (daftar `LostCityFeature`, `LostCitySphereFeature`) -> `CustomRegistries.init()` (daftar 13 `DynamicRegistries`) -> `ConfigRegistry.INSTANCE.register(...)` -> `ModSetup.preInit()` (`ProfileSetup.setupProfiles()`) -> `ModSetup.init()` (`ForgeEventHandlers.register()`, `AssetRegistries.reset()`) -> `BiomeModifications.addFeature(...)` (`RAW_GENERATION` untuk `lostcities:lostcities`, `TOP_LAYER_MODIFICATION` untuk `lostcities:spheres`).
2. **Inisialisasi Dunia Baru**: `MinecraftServer.setInitialSpawn` -> `MinecraftServerMixin.lostcities$onSetInitialSpawn` -> `ForgeEventHandlers.onCreateSpawnPoint(level, levelData)` -> `LostCityWorldGenData.initializeNewWorld(level)` -> increment `LostCityFeature.globalDimensionInfoDirtyCounter` -> cari posisi spawn kota/bangunan (`SpawnBuildingPrefilter` / `CavernSpawn`).
3. **Permintaan Generate Chunk (`RAW_GENERATION`)**:
   - `LostCityFeature.place(WorldGenLevel, ChunkGenerator, RandomSource, BlockPos)`
   - -> `LostCityFeature.runWithDimensionInfo(level, action)`:
     1. `lockCurrentLifecycleForReading()` (`lifecycleLock.readLock()`)
     2. `getOrCreateDimensionInfo(world)` -> `new DefaultDimensionInfo(world, profile, profileOutside)` (membuat `LostCityTerrainFeature`, `HierarchicalStreetPlanner`, opsional `IntercityHighwayPlanner` + `HighwayPlanningService`)
     3. `runWithChunkNeighborhoodLocks(dim, cx, cz, action)` (mengunci 3x3 chunk stripe dari `ReentrantLock[4096]` dalam urutan stripe terurut untuk mencegah deadlock)
   - Cek `biome.is(LostTags.IS_VOID)` -> skip jika void.
   - -> `DefaultDimensionInfo.getFeature().generate(WorldGenRegion, ChunkAccess)`:
     1. `GenerationContext.open(region, seed, dim, cx, cz)` (siapkan `ThreadLocal` `ScratchBuffers`: `LegacyRandomSource`, `paletteSeed`, `ChunkDriver`, 4 array noise 256)
     2. `ChunkDriver.setPrimer(region, chunk)` (buat `SectionCache` lokal chunk)
     3. `LostCityTerrainFeature.getHeightmap(coord, world)` -> sampel atau cache `ChunkHeightmap`
     4. `BuildingInfo.getBuildingInfo(coord, provider)` -> `ChunkPlanner.buildingInfo(coord, provider)` -> `ChunkPlan.buildingInfo(...)` (yang bertahap memanggil `ChunkPlanner.characteristics` -> `ChunkPlanner.highway` / `ChunkPlanner.cityLevel` / `City` / `MultiChunk` / `HierarchicalStreetPlanner`)
     5. Set `GenerationContext.current().setStreet(cityStyle.getStreetBlock())`
     6. Cek `doCity = info.isCity || (info.outsideChunk && info.hasBuilding)` (serta cek `CITY_AVOID_VOID` pada profil floating)
     7. Jika `doCity`: `doCityChunk(info, heightmap, chunk)`:
        - Lapisan bedrock & high water level (profil default/voidspheres)
        - City surface leveling (`moveDown` / `moveUp` ke `info.getCityGroundLevel()`)
        - Event `PRE_GEN_CITY_CHUNK` -> jika tidak dibatalkan: `generateBuilding(info, heightmap, chunk)` (makeRoom, cellar, lantai, atap, tiang, tangga, pintu, loot/spawner todo) ATAU `generateStreet(info, heightmap)` (borders, park, street section, bridge, connectors) -> event `POST_GEN_CITY_CHUNK`
        - `generateRuins(info)` (jika `RUIN_CHANCE > 0`)
        - `generateStreetDecorations(info)` (jika bukan building, tanpa highway/surface rail/slope)
        - `Highways.generateHighways(this, info)` (jika `levelX >= 0 || levelZ >= 0`)
        - `generateRubble(info)` (jika `RUBBLELAYER`)
        - `Stuff.generateStuff(this, info)`
     8. Jika `!doCity`: `doNormalChunk(info, heightmap)` (terrain correction, highways, bridges, scattered, stuff)
     9. Jika `profile.isSpace() || profile.isSpheres()`: pasang `centerpart` bila `CitySphere.isCitySphereCenter`
     10. `Railways.generateRailways(this, info, railInfo, heightmap)` & `Railways.generateRailwayDungeons(this, info)`
     11. `fixTorches(info)`
     12. Reseed RNG: `GenerationContext.current().random().setSeed(cx * 257017164707L + cz * 101754694003L)`
     13. Event `PRE_EXPLOSION` -> `breakBlocksForDamageNew(cx, cz, info)` + `generateDebris(info)`
     14. `ChunkDriver.actuallyGenerate(chunk)` (tulis `SectionCache` ke `BulkSectionAccess`, hapus block entity tidak valid, update 4 heightmap)
     15. `ChunkFixer.fix(provider, coord)` (eksekusi `postTodo` & `generateVines` lintas batas yang sudah `ChunkStatus.FEATURES`)
4. **Tahap Sphere (`TOP_LAYER_MODIFICATION`)**: `LostCitySphereFeature.place(...)` -> `runWithDimensionInfo` -> `GenerationContext.open` -> `Spheres.generateSpheres(feature, region, chunk)`.
5. **Finalisasi Main Thread (Tick)**: `ServerTickEvents.END_LEVEL_TICK` -> `ForgeEventHandlers.onWorldTick(level)` -> `AssetRegistries.load(level)` -> `GlobalTodo.get(level).executeAndClearTodo(level)` (maks `Config.TODO_QUEUE_SIZE` per tick: loot chest, spawner, block update/POI/lighting).

### 2.2 Alur Target (Paper 26.3)
1. **Bootstrap & Enable**: `LostCitiesBootstrap` (`DATAPACK_DISCOVERY` untuk `dimension_type` + `loot_table`) -> `LostCitiesPlugin.onEnable()` -> muat `config.yml`, ekstrak & muat `profiles/*.json`, muat `AssetRegistry` dari data folder (menimpa resource bawaan), validasi semua aset, registrasi command Brigadier (`LifecycleEvents.COMMANDS`), listener `SpawnHandler` & `LootBridge`, scheduler `GlobalTodoDispatcher`.
2. **Generate Chunk**: Paper menjalankan vanilla noise/surface/caves (karena `shouldGenerateNoise/Surface/Caves = true`) -> `LostCitiesBlockPopulator.populate(WorldInfo, Random, cx, cz, LimitedRegion)` menjalankan pipeline `LostCityTerrainFeature.generate(...)` menggunakan `PaperChunkDriver` (buffered 16x16 + safe write dalam `LimitedRegion.isInRegion`), lalu `LostCitiesSpherePopulator` menjalankan `Spheres.generateSpheres(...)`.
3. **Finalisasi Main Thread**: `GlobalTodo` antrean thread-safe (`ConcurrentHashMap<ChunkKey, ConcurrentLinkedQueue<MainThreadTask>>`) dieksekusi oleh `GlobalRegionScheduler` / `BukkitScheduler` berbatas laju (`todoQueueSizePerTick`) hanya ketika chunk sudah `isChunkLoaded(cx, cz)`, tidak pernah memaksa load chunk.

## 3. Data Flow: Seed -> RNG -> Planner -> Aset -> Blok

```text
worldSeed (long) + dimensionId (String) + LostCityProfile (JSON) + AssetRegistry (immutable snapshot)
  |
  +--> [Per-Dimension Noise] LegacyRandomSource(worldSeed)
  |      |-- NoiseGeneratorPerlin(rand, 4) #1 -> rubbleNoise
  |      |-- NoiseGeneratorPerlin(rand, 4) #2 -> leavesNoise
  |      |-- NoiseGeneratorPerlin(rand, 4) #3 -> ruinNoise
  |      |-- NoiseGeneratorPerlin(rand, 4) #4 -> bottomLayerNoise
  |      +-- LegacyRandomSource(worldSeed ^ dimHash * 0x9e3779b97f4a7c15L ^ 0x6a09e667f3bcc909L) -> terrainTransitionNoise
  |
  +--> [Per-Chunk Planning: ChunkPlanner]
  |      |-- Stage 1 (INFRASTRUCTURE): Highway.computeHighwayInfo / IntercityHighwayPlanner (hub cache + HighwayHubPersistence)
  |      |-- Stage 2 (CHARACTERISTICS): BuildingInfo.computeChunkCharacteristics (City factor, MultiChunk, HierarchicalStreetPlanner)
  |      +-- Stage 3 (CHUNK): BuildingInfo.computeBuildingInfo (QualityRandom dari getBuildingRandom(cx, cz, seed) -> floors, cellars, buildingType, part selection, CompiledPalette)
  |
  +--> [Per-Chunk Block Synthesis: GenerationContext.open]
  |      |-- mixSeed(worldSeed, dimId, cx, cz) [MurmurHash3 finalizer]
  |      |     |-- buffers.random.setSeed(mixed)       -> RNG utama generate chunk
  |      |     +-- paletteSeed = (int)(mixed ^ (mixed >>> 32)) -> LCG 214013*s + 2531011, (s >> 16) & 0x7f
  |      |-- Reseed sebelum damage/debris: cx * 257017164707L + cz * 101754694003L
  |      +-- BuildingPart (207 JSON) + Transform (rotasi/mirror) + CompiledPalette (char -> BlockData/loot/spawner)
  |            --> ChunkDriver (SectionCache 16xHx16) --> LimitedRegion --> GlobalTodo (main-thread loot/spawner/POI)
```

## 4. Daftar Invariants ("HARUS") — Minimal 15 Butir

1. **HARUS** membuat keempat `NoiseGeneratorPerlin` di `LostCityTerrainFeature` dalam urutan persis (`rubbleNoise`, `leavesNoise`, `ruinNoise`, `bottomLayerNoise`) dari satu `LegacyRandomSource(worldSeed)` agar state PRNG tiap noise identik `[PASTI: LostCityTerrainFeature.java:101-104]`.
2. **HARUS** menghitung `transitionSeed` dengan konstanta persis `seed ^ (long) dimId.hashCode() * 0x9e3779b97f4a7c15L ^ 0x6a09e667f3bcc909L` `[PASTI: LostCityTerrainFeature.java:105-107]`.
3. **HARUS** menghitung seed `GenerationContext` dengan `mixSeed` MurmurHash3 identik (`0x9e3779b97f4a7c15L`, `257017164707L`, `101754694003L`, `0xff51afd7ed558ccdL`, `0xc4ceb9fe1a85ec53L`) `[PASTI: GenerationContext.java:108-119]`.
4. **HARUS** menggunakan LCG persis `paletteSeed = 214013 * paletteSeed + 2531011; return (paletteSeed >> 16) & 0x7f;` untuk `nextPaletteIndex()` per-thread `[PASTI: GenerationContext.java:63-66]`.
5. **HARUS** mereset seed RNG chunk ke `chunkX * 257017164707L + chunkZ * 101754694003L` tepat sebelum fase `breakBlocksForDamageNew` dan `generateDebris` `[PASTI: LostCityTerrainFeature.java:356]`.
6. **HARUS** menjaga `FLOORHEIGHT = 6` blok per lantai pada seluruh perhitungan `BuildingInfo`, tangga, jembatan, dan elevasi kota `[PASTI: LostCityTerrainFeature.java:70]`.
7. **HARUS** mengeksekusi tahap `ChunkPlanner` secara berurutan tanpa siklus: `BASE` -> `INFRASTRUCTURE` (`highway`) -> `CHARACTERISTICS` (`characteristics`) -> `CHUNK` (`buildingInfo`) `[PASTI: ChunkStage.java, ChunkPlan.java]`.
8. **HARUS** mengevaluasi `prefersLonely` tetangga dalam urutan arah persis `west -> east -> north -> south` pada `BuildingInfo` karena tiap pengecekan mengonsumsi `rand.nextFloat()` `[PASTI: BuildingInfo.java:805-813]`.
9. **HARUS** menjalankan urutan sub-tahap `doCityChunk` persis: bedrock/water -> city leveling -> building/street -> ruins -> street decorations -> highways -> rubble -> stuff `[PASTI: LostCityTerrainFeature.java:949-1023]`.
10. **HARUS** menjalankan urutan pasca-city/normal di `generate()` persis: sphere centerpart -> railways -> railway dungeons -> fixTorches -> reseed -> explosions/debris -> `actuallyGenerate` -> `ChunkFixer.fix` `[PASTI: LostCityTerrainFeature.java:313-371]`.
11. **HARUS** membaca `minY` dan `maxY` secara dinamis dari `WorldInfo` (`worldInfo.getMinHeight()`, `worldInfo.getMaxHeight()`), dengan target dimensi `lostcity` memakai `min_y = 0`, `height = 256` sesuai `dimension_type/lostcity.json` `[PASTI: dimension_type/lostcity.json, ChunkGenerator Javadoc Paper 26.3]`.
12. **HARUS** mengunci stripe lock 3x3 chunk dalam urutan indeks stripe menaik (`Arrays.sort`) jika diperlukan sinkronisasi lintas-batas, untuk menjamin bebas deadlock `[PASTI: LostCityFeature.java:101-135]`.
13. **HARUS** membatasi seluruh penulisan blok pada fase generate ke dalam chunk aktif atau area `LimitedRegion.isInRegion(x, y, z)`; operasi di luar batas atau butuh `BlockState`/loot/spawner **HARUS** masuk ke `GlobalTodo` dan tidak pernah memanggil `World.getChunkAt` secara rekursif `[PASTI: PRD Bagian 7-8]`.
14. **HARUS** menormalisasi seluruh nama profil/aset dan menolak path traversal (`..`, separator absolut), serta selalu memakai `Locale.ROOT` untuk parsing/formatting angka dan string `[PASTI: PRD NF6 & Daftar Kegagalan Fatal]`.
15. **HARUS** menggunakan koleksi berurutan (`LinkedHashMap`, `TreeMap`, `ArrayList` terurut) untuk setiap iterasi yang memengaruhi pemilihan aset, probabilitas, atau RNG; dilarang bergantung pada urutan iterasi `HashMap`/`HashSet` `[PASTI: Daftar Kegagalan Fatal]`.
16. **HARUS** mengisolasi `AssetRegistry` sebagai snapshot immutable yang diganti secara atomik (`AtomicReference`) saat `/lostcities reload`, sehingga chunk yang sedang digenerate selalu melihat snapshot konsisten `[PASTI: PRD F12 & Bagian 8]`.
17. **HARUS** melakukan persistence `HighwayHub` secara atomik (tulis ke `.tmp` + `fsync` + `Files.move(..., ATOMIC_MOVE, REPLACE_EXISTING)`) dengan nomor versi format dan hash signature agar tahan crash/korupsi `[PASTI: PRD F5 & LostCityHighwayData.java]`.

## 5. State Global, Cache, dan Persistence

| Komponen Sumber | Jenis State | Masalah di Sumber | Desain Target di Paper 26.3 |
|---|---|---|---|
| `LostCityFeature.dimensionInfo` | `ConcurrentHashMap<ResourceKey, IDimensionInfo>` + `lifecycleLock` + `generationLocks[4096]` | Aman-thread, tetapi static dirty counter | Instance field di `DimensionRegistry` milik `LostCitiesPlugin` (bukan static global), dibersihkan di `onDisable()` |
| `ChunkPlanner.PLANS` & `CITY_LEVELS` | `static TimedCache<ChunkCoord, ...>` | Static global tidak terikat lifecycle plugin | Instance field per-world / `DimensionState` dengan batas ukuran maksimum + TTL |
| `BuildingInfo`, `MultiChunk`, `Highway`, `Railway`, `BiomeInfo`, `City`, `CitySphere`, `Scattered` | Static cache masing-masing (`cleanCache()`) | Rawan bocor saat reload/unload world | Seluruh cache dipindahkan ke objek per-world `WorldCacheBundle` dengan kapasitas terkonfigurasi (`BoundedCache`) |
| `LostCityTerrainFeature.cachedHeightmaps` & `pendingHeightmapSamples` | `TimedCache` + `ConcurrentHashMap` | Per-feature | Dipertahankan per-world dengan batas ukuran eksplisit |
| `HighwayPlanningService` | 5 `BoundedFutureCache` (4096 / 2048) + `ForkJoinPool` | Perlu `close()` saat shutdown | Ditutup penuh di `onDisable()` dan `WorldUnloadEvent`, kapasitas dapat dikonfigurasi di `config.yml` |
| `GlobalTodo.todoQueues` & `instances` | **`HashMap` biasa (TIDAK thread-safe!)** `[PASTI: GlobalTodo.java:32-33]` | Race condition antara thread worldgen & server tick | Diganti `ConcurrentHashMap<UUID, ConcurrentHashMap<Long, ConcurrentLinkedQueue<MainThreadTask>>>` |
| `AssetRegistries.*` | Static `RegistryAssetRegistry` | Mutable saat reset | `AtomicReference<AssetRegistry>` immutable per-plugin |
| `LostData` / `LostCityWorldGenData` / `LostCityHighwayData` | Minecraft `SavedData` (NBT/Codec) | Bergantung `SavedDataStorage` NMS | `AtomicFileStore` (JSON berversi + `ATOMIC_MOVE`) di `plugins/LostCities/data/<world-uuid>/` |

## 6. Model Thread yang Terlibat

1. **Server Main Thread**: `onEnable`/`onDisable`, pembuatan dunia (`WorldCreator`), eksekusi `GlobalTodo` berbatas laju (loot chest, spawner, block update), command Brigadier non-async, `WorldUnloadEvent`.
2. **Paper Chunk Generation Worker Threads (Async)**: `LostCitiesChunkGenerator` (`generateNoise`/`generateSurface`), `LostCitiesBiomeProvider.getBiome`, `LostCitiesBlockPopulator.populate`, `LostCitiesSpherePopulator.populate`. **Dilarang keras** menyentuh `World` hidup, `Entity`, `Event`, atau `Chunk.load()`.
3. **Highway Planning Pool (`ExecutorService` / `ForkJoinPool` bernama `LostCities-Highway-*`)**: `HighwayPlanningService` untuk komputasi hub/rute inter-city secara async dengan `BoundedFutureCache`. Ditutup bersih di `onDisable()`.
4. **Network / Configuration Async Thread**: `AsyncPlayerSpawnLocationEvent` di Paper 26.3 untuk menentukan titik spawn awal pemain sebelum masuk dunia tanpa memblokir main thread.
