# TESTING — Panduan Pengujian LostCities Paper 26.3

## 1. Build & Unit / Audit Tests (JUnit 5)
Pastikan JDK 25 terpasang dan variabel `paperApiVersion` di `gradle.properties` sudah sesuai dengan versi Paper 26.3 di `https://repo.papermc.io/repository/maven-public/io/papermc/paper/paper-api/`:

```bash
./gradlew clean build
```

Cakupan tes otomatis yang dijalankan `./gradlew test`:
1. `LostCityProfileParityTest`: memverifikasi seluruh default `LostCityProfile`, validasi out-of-range, dan kelengkapan 22 preset bawaan (`profiles/*.json`).
2. `AssetLoaderTest`: memverifikasi jumlah aset bawaan cocok dengan PRD Bagian 2 (`parts=207`, `buildings=37`, `palettes=30`, `multibuildings=14`, `variants=12`, `citystyles=5`, `scattered=5`, `styles=4`, `stuff=3`, `conditions=3`, `worldstyles=2`), toleransi JSON rusak, anti path traversal, dan batas ukuran file 2 MB.
3. `CoreWorldgenDeterminismTest`: uji determinisme 100 chunk x 2 urutan acak.
4. `NetworkAndPersistenceTest`: konektivitas jalan primer lintas chunk, persistence highway atomik, dan pemulihan file korup.
5. `DeterminismAndConcurrencyAuditTest`: uji determinisme 1.000 chunk x 2 urutan acak x 1 vs 4 thread (Putaran 7).
6. `ChunkBoundaryAndHeightAuditTest`: uji 200 sampel batas chunk pada rentang tinggi `[0..256]` dan fallback `[-64..320]` (Putaran 8).

## 2. Uji Integrasi Server Paper 26.3
1. Salin `build/libs/LostCities-Paper-26.3-12.0.2-paper.1.jar` ke folder `plugins/` server Paper 26.3 (Java 25).
2. Jalankan server dan periksa log startup (`parts=207`, `buildings=37`, dst., nol `ERROR`/`WARN`).
3. Jalankan:
   - `/lc world create lostcity default 12345`
   - `/lc stats`
   - `/lc locate city`
   - `/lc map`
   - `/lc saveprofile backup_default`
   - `/lc reload`
4. Restart server dan verifikasi dunia `lostcity` dimuat ulang dengan generator sama melalui `bukkit.yml`:
   ```yaml
   worlds:
     lostcity:
       generator: LostCities:default
   ```
5. Jalankan skenario beban 20 pemain/bot 15 menit sesuai `docs/PERFORMANCE_AND_LOAD_TEST.md`.
