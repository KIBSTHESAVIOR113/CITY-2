# PROFILE_FIELD_PARITY — LostCities 26.3-12.0.2 -> Paper 26.3

Total field di `mcjty.lostcities.config.LostCityProfile` (sumber): **165** field (2 field konstruktor + 163 field konfigurasi `cfg.get*`).
Semua kunci JSON, nilai default, dan rentang validasi pada port Paper disalin 1:1 dari `LostCityProfile.java` sumber tanpa mengarang rentang clamp baru `[PASTI: diekstrak langsung dari LostCityProfile.java]`.

| No | Nama Field Sumber | Kunci JSON & Field Port | Tipe | Default Sumber | Rentang/Validasi di Sumber | Status |
|---|---|---|---|---|---|---|
| 1 | `name` | `name` | `String` | `constructor arg ("default")` | `Tidak dibatasi di sumber (disanitasi anti-traversal di Paper)` | SAMA (sanitasi path traversal) |
| 2 | `isPublic` | `public` | `boolean` | `true (JSON default)` | `Boolean` | SAMA |
| 3 | `HORIZON` | `horizon` | `float` | `-1f` | `[-1f, 256f]` | SAMA (field dipertahankan untuk kompatibilitas JSON; tidak aktif di klien vanilla) |
| 4 | `FOG_RED` | `fogRed` | `float` | `-1.0f` | `[-1f, 1f]` | SAMA (field dipertahankan untuk kompatibilitas JSON; tidak aktif di klien vanilla) |
| 5 | `FOG_GREEN` | `fogGreen` | `float` | `-1.0f` | `[-1f, 1f]` | SAMA (field dipertahankan untuk kompatibilitas JSON; tidak aktif di klien vanilla) |
| 6 | `FOG_BLUE` | `fogBlue` | `float` | `-1.0f` | `[-1f, 1f]` | SAMA (field dipertahankan untuk kompatibilitas JSON; tidak aktif di klien vanilla) |
| 7 | `FOG_DENSITY` | `fogDensity` | `float` | `-1.0f` | `[-1f, 1f]` | SAMA (field dipertahankan untuk kompatibilitas JSON; tidak aktif di klien vanilla) |
| 8 | `CITYSPHERE_FACTOR` | `citySphereFactor` | `float` | `1.2f` | `[0.1f, 10.0f]` | SAMA |
| 9 | `CITYSPHERE_CHANCE` | `citySphereChance` | `float` | `0.7f` | `[0.0f, 1.0f]` | SAMA |
| 10 | `CITYSPHERE_CLEARABOVE` | `citySphereClearAbove` | `int` | `0` | `[0, 1024]` | SAMA |
| 11 | `CITYSPHERE_CLEARABOVE_UNTIL_AIR` | `citySphereClearAboveUntilAir` | `boolean` | `false` | `Tidak dibatasi di sumber` | SAMA |
| 12 | `CITYSPHERE_CLEARBELOW` | `citySphereClearBelow` | `int` | `0` | `[0, 1024]` | SAMA |
| 13 | `CITYSPHERE_CLEARBELOW_UNTIL_AIR` | `citySphereClearBelowUntilAir` | `boolean` | `false` | `Tidak dibatasi di sumber` | SAMA |
| 14 | `CITYSPHERE_SURFACE_VARIATION` | `sphereSurfaceVariation` | `float` | `1.0f` | `[0.0f, 1.0f]` | SAMA |
| 15 | `CITYSPHERE_OUTSIDE_SURFACE_VARIATION` | `outsideSurfaceVariation` | `float` | `1.0f` | `[0.0f, 1.0f]` | SAMA |
| 16 | `CITYSPHERE_MONORAIL_CHANCE` | `monorailChance` | `float` | `0.8f` | `[0.0f, 1.0f]` | SAMA |
| 17 | `CITYSPHERE_ONLY_PREDEFINED` | `onlyPredefined` | `boolean` | `false` | `Tidak dibatasi di sumber` | SAMA |
| 18 | `CITYSPHERE_OUTSIDE_GROUNDLEVEL` | `outsideGroundLevel` | `int` | `-1` | `[-1, 256]` | SAMA |
| 19 | `CITYSPHERE_OUTSIDE_PROFILE` | `outsideProfile` | `String` | `""` | `Tidak dibatasi di sumber` | SAMA |
| 20 | `CITYSPHERE_MONORAIL_HEIGHT_OFFSET` | `monorailOffset` | `int` | `-2` | `[-100, 100]` | SAMA |
| 21 | `CITYSPHERE_32GRID` | `grid32` | `boolean` | `false` | `Tidak dibatasi di sumber` | SAMA |
| 22 | `description` | `description` | `String` | `"Default generation, common cities, explosions"` | `Tidak dibatasi di sumber` | SAMA |
| 23 | `extraDescription` | `extraDescription` | `String` | `""` | `Tidak dibatasi di sumber` | SAMA |
| 24 | `warning` | `warning` | `String` | `""` | `Tidak dibatasi di sumber` | SAMA |
| 25 | `worldStyle` | `worldStyle` | `String` | `"standard"` | `Tidak dibatasi di sumber` | SAMA |
| 26 | `iconFile` | `icon` | `String` | `""` | `Tidak dibatasi di sumber` | SAMA (field dipertahankan untuk kompatibilitas JSON; tidak aktif di klien vanilla) |
| 27 | `LIQUID_BLOCK` | `liquidBlock` | `String` | `"minecraft:water"` | `Tidak dibatasi di sumber` | SAMA |
| 28 | `BASE_BLOCK` | `baseBlock` | `String` | `"minecraft:stone"` | `Tidak dibatasi di sumber` | SAMA |
| 29 | `SPAWN_BIOME` | `spawnBiome` | `String` | `""` | `Tidak dibatasi di sumber` | SAMA |
| 30 | `SPAWN_CITY` | `spawnCity` | `String` | `""` | `Tidak dibatasi di sumber` | SAMA |
| 31 | `SPAWN_SPHERE` | `spawnSphere` | `String` | `""` | `Tidak dibatasi di sumber` | SAMA |
| 32 | `SPAWN_NOT_IN_BUILDING` | `spawnNotInBuilding` | `boolean` | `false` | `Tidak dibatasi di sumber` | SAMA |
| 33 | `FORCE_SPAWN_IN_BUILDING` | `forceSpawnInBuilding` | `boolean` | `false` | `Tidak dibatasi di sumber` | SAMA |
| 34 | `FORCE_SPAWN_BUILDINGS` | `forceSpawnBuildings` | `String[]` | `new String[0]` | `Tidak dibatasi di sumber` | SAMA |
| 35 | `FORCE_SPAWN_PARTS` | `forceSpawnParts` | `String[]` | `new String[0]` | `Tidak dibatasi di sumber` | SAMA |
| 36 | `SPAWN_CHECK_RADIUS` | `spawnCheckRadius` | `int` | `200` | `[1, 100000]` | SAMA |
| 37 | `SPAWN_RADIUS_INCREASE` | `spawnRadiusIncrease` | `int` | `100` | `[1, 100000]` | SAMA |
| 38 | `SPAWN_CHECK_ATTEMPTS` | `spawnCheckAttempts` | `int` | `20000` | `[1, 1000000]` | SAMA |
| 39 | `SCATTERED_CHANCE_MULTIPLIER` | `scatteredChanceMultiplier` | `float` | `1.0f` | `[0.0f, 100.0f]` | SAMA |
| 40 | `TERRAIN_FIX_LOWER_MIN_OFFSET` | `terrainFixLowerMinOffset` | `int` | `-4` | `[-40, 40]` | SAMA |
| 41 | `TERRAIN_FIX_LOWER_MAX_OFFSET` | `terrainFixLowerMaxOffset` | `int` | `-3` | `[-40, 40]` | SAMA |
| 42 | `TERRAIN_FIX_UPPER_MIN_OFFSET` | `terrainFixUpperMinOffset` | `int` | `-1` | `[-40, 40]` | SAMA |
| 43 | `TERRAIN_FIX_UPPER_MAX_OFFSET` | `terrainFixUpperMaxOffset` | `int` | `1` | `[-40, 40]` | SAMA |
| 44 | `VINE_CHANCE` | `vineChance` | `float` | `0.009f` | `[0.0f, 1.0f]` | SAMA |
| 45 | `CHANCE_OF_RANDOM_LEAFBLOCKS` | `randomLeafBlockChance` | `float` | `.1f` | `[0.0f, 1.0f]` | SAMA |
| 46 | `THICKNESS_OF_RANDOM_LEAFBLOCKS` | `randomLeafBlockThickness` | `int` | `2` | `[1, 8]` | SAMA |
| 47 | `AVOID_FOLIAGE` | `avoidFoliage` | `boolean` | `false` | `Tidak dibatasi di sumber` | SAMA |
| 48 | `LANDSCAPE_TYPE` | `landscapeType` | `LandscapeType` | `LandscapeType.DEFAULT` | `Enum: default, floating, space, cavern, spheres, cavernspheres` | SAMA |
| 49 | `RUBBLELAYER` | `rubbleLayer` | `boolean` | `true` | `Tidak dibatasi di sumber` | SAMA |
| 50 | `RUBBLE_DIRT_SCALE` | `rubbleDirtScale` | `float` | `3.0f` | `[0.0f, 100.0f]` | SAMA |
| 51 | `RUBBLE_LEAVE_SCALE` | `rubbleLeaveScale` | `float` | `6.0f` | `[0.0f, 100.0f]` | SAMA |
| 52 | `RUIN_CHANCE` | `ruinChance` | `float` | `0.05f` | `[0.0f, 1.0f]` | SAMA |
| 53 | `RUIN_MINLEVEL_PERCENT` | `ruinMinlevelPercent` | `float` | `0.8f` | `[0.0f, 1.0f]` | SAMA |
| 54 | `RUIN_MAXLEVEL_PERCENT` | `ruinMaxlevelPercent` | `float` | `1.0f` | `[0.0f, 1.0f]` | SAMA |
| 55 | `GROUNDLEVEL` | `groundLevel` | `int` | `71` | `[2, 256]` | SAMA |
| 56 | `SEALEVEL` | `seaLevel` | `int` | `-1` | `[-1, 256]` | SAMA |
| 57 | `CHEST_WITHOUT_LOOT_CHANCE` | `chestWithoutLootChance` | `float` | `.2f` | `[0.0f, 1.0f]` | SAMA |
| 58 | `BUILDING_WITHOUT_LOOT_CHANCE` | `buildingWithoutLootChance` | `float` | `.2f` | `[0.0f, 1.0f]` | SAMA |
| 59 | `BUILDING_CHANCE` | `buildingChance` | `float` | `.3f` | `[0.0f, 1.0f]` | SAMA |
| 60 | `BUILDING_MINFLOORS` | `buildingMinFloors` | `int` | `0` | `[0, 60]` | SAMA |
| 61 | `BUILDING_MAXFLOORS` | `buildingMaxFloors` | `int` | `8` | `[0, 60]` | SAMA |
| 62 | `BUILDING_MINFLOORS_CHANCE` | `buildingMinFloorsChance` | `int` | `4` | `[1, 60]` | SAMA |
| 63 | `BUILDING_MAXFLOORS_CHANCE` | `buildingMaxFloorsChance` | `int` | `6` | `[1, 60]` | SAMA |
| 64 | `BUILDING_MINCELLARS` | `buildingMinCellars` | `int` | `0` | `[0, 20]` | SAMA |
| 65 | `BUILDING_MAXCELLARS` | `buildingMaxCellars` | `int` | `3` | `[0, 20]` | SAMA |
| 66 | `BUILDING_DOORWAYCHANCE` | `buildingDoorwayChance` | `float` | `.6f` | `[0.0f, 1.0f]` | SAMA |
| 67 | `BUILDING_FRONTCHANCE` | `buildingFrontChance` | `float` | `.2f` | `[0.0f, 1.0f]` | SAMA |
| 68 | `PARK_CHANCE` | `parkChance` | `float` | `.2f` | `[0.0f, 1.0f]` | SAMA |
| 69 | `OPEN_LOT_PARK_CHANCE` | `openLotParkChance` | `float` | `.8f` | `[0.0f, 1.0f]` | SAMA |
| 70 | `CORRIDOR_CHANCE` | `corridorChance` | `float` | `.7f` | `[0.0f, 1.0f]` | SAMA |
| 71 | `BRIDGE_CHANCE` | `bridgeChance` | `float` | `.7f` | `[0.0f, 1.0f]` | SAMA |
| 72 | `PLANNED_PRIMARY_BRIDGE_CHANCE` | `plannedPrimaryBridgeChance` | `float` | `1.0f` | `[0.0f, 1.0f]` | SAMA |
| 73 | `PLANNED_PRIMARY_BRIDGE_MAX_LENGTH` | `plannedPrimaryBridgeMaxLength` | `int` | `12` | `[1, 64]` | SAMA |
| 74 | `BRIDGE_SUPPORTS` | `bridgeSupports` | `boolean` | `true` | `Tidak dibatasi di sumber` | SAMA |
| 75 | `PARK_ELEVATION` | `parkElevation` | `boolean` | `true` | `Tidak dibatasi di sumber` | SAMA |
| 76 | `PARK_BORDER` | `parkBorder` | `boolean` | `true` | `Tidak dibatasi di sumber` | SAMA |
| 77 | `PARK_STREET_THRESHOLD` | `parkStreetThreshold` | `int` | `3` | `[0, 8]` | SAMA |
| 78 | `STREET_GENERATION_MODE` | `streetGenerationMode` | `StreetGenerationMode` | `StreetGenerationMode.HIERARCHICAL_GRID_V1` | `Enum: LEGACY, HIERARCHICAL_GRID_V1` | SAMA |
| 79 | `PRIMARY_ROAD_SPACING_X` | `primaryRoadSpacingX` | `int` | `8` | `[8, 128]` | SAMA |
| 80 | `PRIMARY_ROAD_SPACING_Z` | `primaryRoadSpacingZ` | `int` | `8` | `[8, 128]` | SAMA |
| 81 | `PRIMARY_ROAD_OPTIONAL_CHANCE` | `primaryRoadOptionalChance` | `float` | `.45f` | `[0.0f, 1.0f]` | SAMA |
| 82 | `PRIMARY_ROAD_FORCE_EVERY` | `primaryRoadForceEvery` | `int` | `4` | `[1, 16]` | SAMA |
| 83 | `SECONDARY_ROAD_MIN_COUNT_X` | `secondaryRoadMinCountX` | `int` | `0` | `[0, 128]` | SAMA |
| 84 | `SECONDARY_ROAD_MAX_COUNT_X` | `secondaryRoadMaxCountX` | `int` | `2` | `[0, 128]` | SAMA |
| 85 | `SECONDARY_ROAD_MIN_COUNT_Z` | `secondaryRoadMinCountZ` | `int` | `0` | `[0, 128]` | SAMA |
| 86 | `SECONDARY_ROAD_MAX_COUNT_Z` | `secondaryRoadMaxCountZ` | `int` | `2` | `[0, 128]` | SAMA |
| 87 | `MINIMUM_ROAD_SEPARATION` | `minimumRoadSeparation` | `int` | `4` | `[2, 32]` | SAMA |
| 88 | `MINIMUM_ROAD_EDGE_DISTANCE` | `minimumRoadEdgeDistance` | `int` | `3` | `[2, 32]` | SAMA |
| 89 | `TERTIARY_ROAD_CHANCE` | `tertiaryRoadChance` | `float` | `.40f` | `[0.0f, 1.0f]` | SAMA |
| 90 | `TERTIARY_ROAD_MIN_LENGTH` | `tertiaryRoadMinLength` | `int` | `2` | `[1, 16]` | SAMA |
| 91 | `TERTIARY_ROAD_MAX_LENGTH` | `tertiaryRoadMaxLength` | `int` | `5` | `[1, 32]` | SAMA |
| 92 | `MULTI_BUILDING_STREET_CONFLICT` | `multiBuildingStreetConflict` | `MultiBuildingStreetConflict` | `MultiBuildingStreetConflict.OVERRIDE_MINOR` | `Enum: BLOCK_ALL, OVERRIDE_MINOR, OVERRIDE_ALL` | SAMA |
| 93 | `FOUNTAIN_CHANCE` | `fountainChance` | `float` | `.05f` | `[0.0f, 1.0f]` | SAMA |
| 94 | `RAILWAY_DUNGEON_CHANCE` | `railwayDungeonChance` | `float` | `.01f` | `[0.0f, 1.0f]` | SAMA |
| 95 | `RAILWAYS_CAN_END` | `railwaysCanEnd` | `boolean` | `false` | `Tidak dibatasi di sumber` | SAMA |
| 96 | `RAILWAYS_ENABLED` | `railwaysEnabled` | `boolean` | `true` | `Tidak dibatasi di sumber` | SAMA |
| 97 | `RAILWAY_STATIONS_ENABLED` | `railwayStationsEnabled` | `boolean` | `true` | `Tidak dibatasi di sumber` | SAMA |
| 98 | `RAILWAY_SURFACE_STATIONS_ENABLED` | `railwaySurfaceStationsEnabled` | `boolean` | `true` | `Tidak dibatasi di sumber` | SAMA |
| 99 | `RAILWAY_LEVEL_OFFSET` | `railwayLevelOffset` | `int` | `0` | `[-8, 2]` | SAMA |
| 100 | `RAILWAY_SPACING_NORTH_SOUTH` | `railwaySpacingNorthSouth` | `int` | `DEFAULT_RAILWAY_SPACING` | `[MIN_RAILWAY_SPACING, MAX_RAILWAY_SPACING]` | SAMA |
| 101 | `RAILWAY_SPACING_EAST_WEST` | `railwaySpacingEastWest` | `int` | `DEFAULT_RAILWAY_SPACING` | `[MIN_RAILWAY_SPACING, MAX_RAILWAY_SPACING]` | SAMA |
| 102 | `MULTI_USE_CORNER` | `multiUseCorner` | `boolean` | `false` | `Tidak dibatasi di sumber` | SAMA |
| 103 | `USE_AVG_HEIGHTMAP` | `useAvgHeightmap` | `boolean` | `false` | `Tidak dibatasi di sumber` | SAMA |
| 104 | `HIGHWAY_REQUIRES_TWO_CITIES` | `highwayRequiresTwoCities` | `boolean` | `true` | `Tidak dibatasi di sumber` | SAMA |
| 105 | `HIGHWAY_LEVEL_FROM_CITIES_MODE` | `highwayLevelFromCities` | `int` | `3` | `[0, 4]` | SAMA |
| 106 | `HIGHWAY_DISTANCE_MASK` | `highwayDistanceMask` | `int` | `7` | `[0, Integer.MAX_VALUE]` | SAMA |
| 107 | `HIGHWAY_MAINPERLIN_SCALE` | `highwayMainPerlinScale` | `float` | `50.0f` | `[1.0f, 1000.0f]` | SAMA |
| 108 | `HIGHWAY_SECONDARYPERLIN_SCALE` | `highwaySecondaryPerlinScale` | `float` | `10.0f` | `[1.0f, 1000.0f]` | SAMA |
| 109 | `HIGHWAY_PERLIN_FACTOR` | `highwayPerlinFactor` | `float` | `2.0f` | `[-100, 100]` | SAMA |
| 110 | `HIGHWAY_SUPPORTS` | `highwaySupports` | `boolean` | `true` | `Tidak dibatasi di sumber` | SAMA |
| 111 | `HIGHWAY_GENERATION_MODE` | `highwayGenerationMode` | `HighwayGenerationMode` | `HighwayGenerationMode.INTERCITY_NETWORK_V1` | `Enum: LEGACY, INTERCITY_NETWORK_V1` | SAMA |
| 112 | `HIGHWAY_PLANNING_CELL_SIZE` | `highwayPlanningCellSize` | `int` | `128` | `[32, 512]` | SAMA |
| 113 | `HIGHWAY_HUB_SAMPLE_SPACING` | `highwayHubSampleSpacing` | `int` | `16` | `[1, 512]` | SAMA |
| 114 | `HIGHWAY_HUB_MINIMUM_POTENTIAL` | `highwayHubMinimumPotential` | `float` | `.20f` | `[0.0f, 1.0f]` | SAMA |
| 115 | `HIGHWAY_HUB_SEARCH_RADIUS_CELLS` | `highwayHubSearchRadiusCells` | `int` | `2` | `[0, 8]` | SAMA |
| 116 | `HIGHWAY_MINIMUM_HUB_DISTANCE` | `highwayMinimumHubDistance` | `int` | `64` | `[0, 4096]` | SAMA |
| 117 | `HIGHWAY_MAXIMUM_HUB_DISTANCE` | `highwayMaximumHubDistance` | `int` | `320` | `[0, 4096]` | SAMA |
| 118 | `HIGHWAY_MAXIMUM_CONNECTIONS_PER_HUB` | `highwayMaximumConnectionsPerHub` | `int` | `2` | `[1, 8]` | SAMA |
| 119 | `HIGHWAY_MINIMUM_ROUTE_LENGTH` | `highwayMinimumRouteLength` | `int` | `40` | `[0, 4096]` | SAMA |
| 120 | `HIGHWAY_ROUTE_CITY_PENALTY` | `highwayRouteCityPenalty` | `float` | `1.0f` | `[0.0f, 1000.0f]` | SAMA |
| 121 | `HIGHWAY_NETWORK_LEVEL` | `highwayNetworkLevel` | `int` | `0` | `[0, 32]` | SAMA |
| 122 | `BEDROCK_LAYER` | `bedrockLayer` | `int` | `1` | `[0, 10]` | SAMA |
| 123 | `EDITMODE` | `editMode` | `boolean` | `false` | `Tidak dibatasi di sumber` | SAMA |
| 124 | `GENERATE_NETHER` | `generateNether` | `boolean` | `false` | `Tidak dibatasi di sumber` | SAMA |
| 125 | `GENERATE_SPAWNERS` | `generateSpawners` | `boolean` | `true` | `Tidak dibatasi di sumber` | SAMA |
| 126 | `GENERATE_LOOT` | `generateLoot` | `boolean` | `true` | `Tidak dibatasi di sumber` | SAMA |
| 127 | `GENERATE_LIGHTING` | `generateLighting` | `boolean` | `false` | `Tidak dibatasi di sumber` | SAMA |
| 128 | `AVOID_WATER` | `avoidWater` | `boolean` | `false` | `Tidak dibatasi di sumber` | SAMA |
| 129 | `CITY_CHANCE` | `cityChance` | `double` | `.01` | `[-1.0, 1.0]` | SAMA |
| 130 | `CITY_SPAWN_DISTANCE1` | `citySpawnDistance1` | `int` | `0` | `[0, 10000000]` | SAMA |
| 131 | `CITY_SPAWN_DISTANCE2` | `citySpawnDistance2` | `int` | `0` | `[0, 10000000]` | SAMA |
| 132 | `CITY_SPAWN_MULTIPLIER1` | `citySpawnMultiplier1` | `double` | `1.0` | `[0, 1]` | SAMA |
| 133 | `CITY_SPAWN_MULTIPLIER2` | `citySpawnMultiplier2` | `double` | `1.0` | `[0, 1]` | SAMA |
| 134 | `CITY_MINRADIUS` | `cityMinRadius` | `int` | `50` | `[1, 2000]` | SAMA |
| 135 | `CITY_MAXRADIUS` | `cityMaxRadius` | `int` | `128` | `[1, 2000]` | SAMA |
| 136 | `CITY_PERLIN_SCALE` | `cityPerlinScale` | `double` | `3` | `[-1000000, 1000000]` | SAMA |
| 137 | `CITY_PERLIN_OFFSET` | `cityPerlinOffset` | `double` | `.1` | `[-1000000, 1000000]` | SAMA |
| 138 | `CITY_PERLIN_INNERSCALE` | `cityPerlinInnerScale` | `double` | `.1` | `[-1000000, 1000000]` | SAMA |
| 139 | `CITY_THRESHOLD` | `cityThreshold` | `float` | `.2f` | `[0.0f, 1.0f]` | SAMA |
| 140 | `CITY_STYLE_THRESHOLD` | `cityStyleThreshold` | `float` | `-1f` | `[0.0f, 1.0f]` | SAMA |
| 141 | `CITY_STYLE_ALTERNATIVE` | `cityStyleAlternative` | `String` | `""` | `Tidak dibatasi di sumber` | SAMA |
| 142 | `CITY_AVOID_VOID` | `cityAvoidVoid` | `boolean` | `true` | `Tidak dibatasi di sumber` | SAMA |
| 143 | `CITY_LEVEL0_HEIGHT` | `cityLevel0Height` | `int` | `75` | `[1, 384]` | SAMA |
| 144 | `CITY_LEVEL1_HEIGHT` | `cityLevel1Height` | `int` | `83` | `[1, 384]` | SAMA |
| 145 | `CITY_LEVEL2_HEIGHT` | `cityLevel2Height` | `int` | `91` | `[1, 384]` | SAMA |
| 146 | `CITY_LEVEL3_HEIGHT` | `cityLevel3Height` | `int` | `99` | `[1, 384]` | SAMA |
| 147 | `CITY_LEVEL4_HEIGHT` | `cityLevel4Height` | `int` | `107` | `[1, 384]` | SAMA |
| 148 | `CITY_LEVEL5_HEIGHT` | `cityLevel5Height` | `int` | `115` | `[1, 384]` | SAMA |
| 149 | `CITY_LEVEL6_HEIGHT` | `cityLevel6Height` | `int` | `123` | `[1, 384]` | SAMA |
| 150 | `CITY_LEVEL7_HEIGHT` | `cityLevel7Height` | `int` | `131` | `[1, 384]` | SAMA |
| 151 | `CITY_MINHEIGHT` | `cityMinHeight` | `int` | `50` | `[-1024, 2048]` | SAMA |
| 152 | `CITY_MAXHEIGHT` | `cityMaxHeight` | `int` | `150` | `[-1024, 2048]` | SAMA |
| 153 | `OCEAN_CORRECTION_BORDER` | `oceanCorrectionBorder` | `int` | `4` | `[-255, 255]` | SAMA |
| 154 | `DEBRIS_TO_NEARBYCHUNK_FACTOR` | `debrisToNearbyChunkFactor` | `int` | `200` | `[1, 10000]` | SAMA |
| 155 | `EXPLOSION_CHANCE` | `explosionChance` | `float` | `.002f` | `[0.0f, 1.0f]` | SAMA |
| 156 | `EXPLOSION_MINRADIUS` | `explosionMinRadius` | `int` | `15` | `[1, 1000]` | SAMA |
| 157 | `EXPLOSION_MAXRADIUS` | `explosionMaxRadius` | `int` | `35` | `[1, 3000]` | SAMA |
| 158 | `EXPLOSION_MINHEIGHT` | `explosionMinHeight` | `int` | `75` | `[1, 256]` | SAMA |
| 159 | `EXPLOSION_MAXHEIGHT` | `explosionMaxHeight` | `int` | `90` | `[1, 256]` | SAMA |
| 160 | `MINI_EXPLOSION_CHANCE` | `miniExplosionChance` | `float` | `.03f` | `[0.0f, 1.0f]` | SAMA |
| 161 | `MINI_EXPLOSION_MINRADIUS` | `miniExplosionMinRadius` | `int` | `5` | `[1, 1000]` | SAMA |
| 162 | `MINI_EXPLOSION_MAXRADIUS` | `miniExplosionMaxRadius` | `int` | `12` | `[1, 3000]` | SAMA |
| 163 | `MINI_EXPLOSION_MINHEIGHT` | `miniExplosionMinHeight` | `int` | `60` | `[1, 256]` | SAMA |
| 164 | `MINI_EXPLOSION_MAXHEIGHT` | `miniExplosionMaxHeight` | `int` | `100` | `[1, 256]` | SAMA |
| 165 | `EXPLOSIONS_IN_CITIES_ONLY` | `explosionsInCitiesOnly` | `boolean` | `true` | `Tidak dibatasi di sumber` | SAMA |
