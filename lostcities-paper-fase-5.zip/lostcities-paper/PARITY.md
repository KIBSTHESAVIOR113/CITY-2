# PARITY — LostCities Fabric 26.3-12.0.2 vs LostCities Paper 26.3

| Komponen / Method Sumber | Perilaku Asli (Fabric 26.3) | Perilaku Port (Paper 26.3) | Alasan Teknis (Batasan API Paper) | Dampak Visual / Gameplay |
|---|---|---|---|---|
| `LostCityTerrainFeature.generateHeightmap` & `NoiseBasedChunkGenerator` (K1 / DEC-12) | Menggunakan `minecraft:noise` vanilla dan query stateless `NoiseBasedChunkGenerator.getBaseHeight(...)` | Satu sumber tinggi tunggal (`TerrainHeightField`): `shouldGenerateNoise = false`, `generateNoise` membentuk medan langsung dari `TerrainHeightField` sehingga tinggi rencana 100% identik dengan tinggi blok nyata tanpa memuat chunk tetangga | Paper API publik tidak mengekspos `RandomState` / `NoiseBasedChunkGenerator.getBaseHeight` tanpa NMS | Bentuk bukit/lembah tidak identik 1:1 dengan noise vanilla, tetapi kota 100% menyatu mulus dengan lereng tanpa dua sumber tinggi yang bentrok. |
| `data/lostcities/dimension_type/lostcity.json` (K3 / DEC-13) | `min_y: 0`, `height: 256`, `logical_height: 256` | Permanen memakai Overworld `-64..320` (`World.Environment.NORMAL`), membaca `minY`/`maxY` dinamis, `GROUNDLEVEL = 71`, bedrock di `minY`, ceiling cavern di `min(127, maxY - 1)` | `WorldCreator` Paper 26.3 tidak memiliki API publik untuk mengikat dunia baru ke custom `dimension_type` tanpa NMS | Area di bawah `Y=0` berisi batu/deepslate/ore vanilla; bangunan kota tetap berada di elevasi `GROUNDLEVEL` (71) tanpa crash. |
| `StructureAvoidance` (K4) | Membaca `ChunkAccess.getAllStarts()` / `getAllReferences()` pada proto-chunk | `shouldGenerateStructures` mengembalikan `false` pada chunk kota + buffer radius 4 chunk, disertai pembersihan di `generateSurface`/`makeRoomForBuilding` | `LimitedRegion` tidak mengekspos `StructureStart` proto-chunk secara publik | Village/struktur vanilla tidak masuk ke kota, dengan buffer 4 chunk di tepi kota. |
| `BiomeModifications.addFeature` (`RAW_GENERATION`) | Menyuntikkan feature sebelum dekorasi vanilla | `ChunkGenerator` (`generateNoise`/`generateSurface` pada `ChunkData`) + flag `shouldGenerateDecorations/Structures/Caves` per chunk + `BlockPopulator` (`LimitedRegion`) khusus blok pasca-pass | Paper API publik tidak memiliki `BiomeModifications` | Pohon, ore, dan gua tetap ada di luar kota; nol pohon/struktur menabrak kota. |
| `SavedData` NBT (`LostData`, `LostCityHighwayData`) | Disimpan di NBT `SavedDataStorage` | `AtomicFileStore` JSON berversi (`tmp -> fsync -> ATOMIC_MOVE`) | Nol NMS; tahan `kill -9` | Tidak kompatibel dengan save dunia Fabric lama. |
| Client GUI / Fog / Horizon / Network | `GuiLCConfig`, `CreateWorldScreenMixin`, paket jaringan | Dibuang (field JSON profil tetap dipertahankan) | Klien Minecraft vanilla tanpa mod | Konfigurasi melalui `config.yml`, `profiles/*.json`, dan `/lostcities`. |


## Koreksi C1–C6 & Fase 3 (Terrain Shaping & Building Clearing)
- **C1 (`BuildingInfo.hasXBridge`/`hasZBridge`/`isSuitableForBridge`)**: Diperbaiki agar menelusuri tetangga west/east atau north/south dengan pembanding `isSuitableForBridge(i)` (`i.cityLevel < this.cityLevel || i.waterBiome`) hingga ujung kota tanpa gedung (`cityLevel <= 0`), sesuai `BuildingInfo.java:1526-1684`. Dibatasi `MAX_BRIDGE_WALK = 16` agar deterministik tanpa scan tak terbatas.
- **C2 (`xRailCorridor`/`zRailCorridor`)**: Disamakan dengan `BuildingInfo.java:1076-1082` menggunakan `CityStyleResolver.resolveCorridorChance(registry, cityStyleId, profile.corridorChance)` (fallback ke `profile.corridorChance` jika `CityStyle` JSON tidak mendefinisikan `corridorchance`).
- **C3 (`IntercityHighwayPlanner`)**: `new City(...)` dihapus; `City` diinjeksi langsung dari `WorldDimensionState`.
- **C4 (`Metrics.noiseP95Ms` & `surfaceP95Ms`)**: Diukur langsung di `LostCitiesChunkGenerator.generateNoise` & `generateSurface`, ditampilkan di `/lc stats` (angka runtime nyata diambil dari server Paper 26.3, bukan sandbox).
- **C6 (`TerrainHeightField`)**: Diperkaya dengan ridge/mountain noise (puncak ~150–190), valley carving, dan biome iklim (`savanna`, `swamp`, `jungle`, `badlands`, `snowy_plains`, `jagged_peaks`) tetap dari satu sumber tunggal (tinggi + biome + blok permukaan, nol biome kering di bawah air). Berbeda dari noise vanilla Overworld (DEC-12).
- **Fase 3 (`LostCityTerrainFeature` + `BuildingInfo` L1/L2 + `ChunkDataSurface`)**:
  - Utang `getDesiredMaxHeightL1/L2` + `updateMinMaxL1/L2` + `MinMax` + `getCityGroundLevelOutsideLower` **DITUTUP** di `BuildingInfo.java`.
  - Port dari `LostCityTerrainFeature.java`: `getRandomizedOffset`, `getHeightOffsetL1/L2`, `getHeightmap` (dari `TerrainHeightField` + `BoundedCache`), `getTerrainTransitionNoise`, `correctTerrainShape`, `getInterpolatedHeight`/`bipolate`, `getMinHeightAt`, `moveUp`, `moveDown` (mempertahankan 6 lapisan permukaan), `makeRoomForBuilding`, `clearToMax`, `clearRange`, `fillToGround`.
  - Dihubungkan ke `LostCitiesChunkGenerator.generateSurface` melalui `ChunkDataSurface` (nol pemuatan chunk tetangga); carving rel di luar kota pada `LostCitiesBlockPopulator` diblokir.

### Status DAFTAR UTANG PORT Setelah Fase 3
| Item | Status | Fase Penutup |
|---|---|---|
| `BuildingInfo.getDesiredMaxHeightL1/L2` + `updateMinMaxL1/L2` | **DITUTUP (Fase 3)** | Fase 3 |
| `BuildingInfo` multi-building, stairs, doors, `getRelativePos` | TERBUKA | Sebelum Fase 5 |
| `CitySphere.initSphere` | TERBUKA | Fase 5 |
| `BuildingInfo.getStreetSlopeDirection`, `hasFrontPartFrom` | TERBUKA | Sebelum Fase 6 |
| `BuildingInfo` monorail, `getExplosions`, `getCityLevel*` non-normal; `RailwayParts` | TERBUKA | Fase 7 |


## Koreksi C1–C4 & Fase 5 (Bangunan & Palet Bertingkat)
- **C1 (Single-Pass Terrain Shaping)**: `correctTerrainShape`, `makeRoomForBuilding`, `clearToMax`, dan `fillToGround` hanya berjalan **SEKALI** di `LostCitiesChunkGenerator.generateSurface` (`ChunkDataSurface`). `LostCityTerrainFeature.generateChunk` (dipanggil `LostCitiesBlockPopulator` pada `LimitedRegion`) tidak lagi memodifikasi medan sehingga nol risiko pohon vanilla melayang/terkubur.
- **C2 (`correctTerrainShape` `heightmap ± 90`)**: Diverifikasi ada verbatim di source asli `LostCityTerrainFeature.java:620-621` (`int maxHeightP = heightmap.getHeight() + 90; int minHeightP = heightmap.getHeight() - 90;`).
- **C3 (`generateSurface` cost & cache `MinMax`)**: `ChunkPlanner` menambahkan cache `minMaxL2` per chunk + counter `buildingInfoLookups`/`buildingInfoComputes`; `Metrics` mencatat `surfaceP95Ms()` & `avgSurfaceBiPerChunk()` yang tampil di `/lc stats`.
- **Fase 5 (Bangunan)**:
  - Utang `BuildingInfo` **DITUTUP**: `initMultiBuildingSection` + `calculateTopLeft` (berbagi `CompiledPalette` dari top-left), `checkBuildingPossibility`, `getRelativePos`, `localToGlobal`/`globalToLocal`, `calculateStairDirection`/`getActualStairDirection`, `getRandomDoor` (7 jenis pintu).
  - `Transform`: menambah `MIRROR_90_X` + `transformBlockState` penuh untuk `facing`, `hinge` (mirror), `axis`, `shape` (rail), `north/east/south/west` (wall/fence/bars/pane), dan `rotation` (0..15).
  - `CompiledPalette`: mendukung `Style.randomPalettes`, `CityStyle` inline palette, `building.refPaletteName`/inline palette, `part.refPaletteName`/inline palette, `frompalette` remapping, `variant`, `loot`, `mob`, `torch`, `tag`.
  - `LostCityTerrainFeature`: `HardAirSetting` (`AIR`/`WATERLEVEL`/`VOID`), `computePalette`, `generateBuilding` (loop `-cellars..floors` dengan `Transform.ROTATE_NONE`, pass kedua `parts2`, `Doors.generateDoors`, pengisi perimeter cellar), `generatePart`, `handleLoot`, `handleSpawner`, `handleBlockEntity`, `handleTodo`, `fixTorches`. `placePart`/`generateStreet` lama dihapus total.
