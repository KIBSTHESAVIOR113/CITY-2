# LostCities for Paper 26.3

Port penulisan ulang mod **LostCities 26.3-12.0.2** (karya asli **McJty**, lisensi MIT) menjadi plugin server **Paper 26.3** (Java 25) yang sepenuhnya kompatibel dengan **klien Minecraft vanilla** tanpa mod atau resource pack wajib.

## Instalasi
1. Siapkan server **Paper 26.3** dengan **Java 25**.
2. Build plugin dari source (setelah menyesuaikan `paperApiVersion` di `gradle.properties`):
   ```bash
   ./gradlew clean build
   ```
3. Salin JAR hasil di `build/libs/LostCities-Paper-26.3-12.0.2-paper.1.jar` ke folder `plugins/`.
4. Jalankan server sekali untuk mengekstrak `config.yml`, 22 preset `profiles/*.json`, dan seluruh aset JSON di `plugins/LostCities/data/lostcities/`.

## Membuat Dunia LostCities
- **Melalui Command**:
  `/lostcities world create lostcity default 12345`
- **Melalui `bukkit.yml`** (agar otomatis dimuat dengan generator LostCities setelah restart):
  ```yaml
  worlds:
    lostcity:
      generator: LostCities:default
  ```

## Command & Permission (`/lostcities`, alias `/lc`)
| Subcommand | Fungsi | Permission |
|---|---|---|
| `world create <nama> [profil] [seed]` | Membuat dunia LostCities baru | `lostcities.admin` |
| `locate [city\|building\|multibuilding]` | Mencari kota/struktur terdekat | `lostcities.locate` |
| `locatepart <part>` | Mencari lokasi part tertentu | `lostcities.locate` |
| `listparts [filter]` | Menampilkan daftar part JSON termuat | `lostcities.admin` |
| `map` | Menampilkan peta ASCII kota di sekitar pemain | `lostcities.map` |
| `stats` | Menampilkan metrik chunk, avg/p95 ms, todo queue, dan jumlah aset | `lostcities.stats` |
| `debug [on\|off]` | Mengaktifkan/mematikan log debug | `lostcities.admin` |
| `saveprofile <nama>` | Menyimpan profil aktif ke `profiles/<nama>.json` | `lostcities.admin` |
| `reload` | Memuat ulang aset JSON & profil secara atomik | `lostcities.admin` |
| `createbuilding` / `createpart` / `exportpart` / `editpart` / `resumeedit` | Panduan alur skema JSON server-side | `lostcities.edit` |

## Troubleshooting
- **Gagal kompilasi `paper-api`**: Cek versi terbaru di `https://repo.papermc.io/repository/maven-public/io/papermc/paper/paper-api/` dan perbarui satu baris `paperApiVersion` di `gradle.properties`.
- **Tinggi dunia `-64..320` alih-alih `0..256`**: Lihat `PARITY.md` (`DEC-02`); plugin otomatis mengaktifkan mode fallback adaptif yang aman tanpa crash.

## Lisensi & Atribusi
Berlisensi **MIT**. Hak cipta mod asli dan seluruh aset JSON LostCities dimiliki oleh **McJty** (lihat berkas `LICENSE`).
