/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.lost;

import mcjty.lostcities.paper.assets.AssetModels;
import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.util.BoundedCache;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.BiFunction;
import java.util.function.ToDoubleFunction;

/**
 * Port of {@code mcjty.lostcities.worldgen.lost.City} preserving all 7 RNG seed constants
 * (797003437L, 295075153L, 100001653L, 899809363L, 256203221L, 593441843L, 217645177L).
 */
public final class City {

    public record WeightedStyle(float weight, String styleId) {}

    private final long worldSeed;
    private final LostCityProfile profile;
    private final CityRarityMap rarityMap;
    private final CitySphere.Cache sphereCache;
    private final Map<ChunkCoord, AssetModels.PredefinedCityAsset> predefinedCities;
    private final BoundedCache<ChunkCoord, Float> factorCache;
    private final BoundedCache<ChunkCoord, String> styleCache;

    public City(long worldSeed, LostCityProfile profile, AssetRegistry registry,
                CitySphere.Cache sphereCache, int cacheMaxEntries, int cacheTtlSeconds) {
        this.worldSeed = worldSeed;
        this.profile = profile;
        this.sphereCache = sphereCache;
        this.rarityMap = new CityRarityMap(worldSeed, profile.cityPerlinScale, profile.cityPerlinOffset, profile.cityPerlinInnerScale);
        this.predefinedCities = new LinkedHashMap<>();
        if (registry != null) {
            for (AssetModels.PredefinedCityAsset pc : registry.predefinedCities().values()) {
                this.predefinedCities.put(new ChunkCoord(pc.dimension(), pc.chunkX(), pc.chunkZ()), pc);
            }
        }
        this.factorCache = new BoundedCache<>(cacheMaxEntries, cacheTtlSeconds);
        this.styleCache = new BoundedCache<>(cacheMaxEntries, cacheTtlSeconds);
    }

    public boolean isCityCenter(ChunkCoord coord) {
        if (predefinedCities.containsKey(coord)) {
            return true;
        }
        // Exact RNG seed constants from City.java:187
        Random cityCenterRandom = new Random(coord.chunkZ() * 797003437L + coord.chunkX() * 295075153L);
        if ((profile.isSpace() || profile.isSpheres()) && sphereCache != null) {
            CitySphere sphere = sphereCache.getCitySphere(coord);
            if (!sphere.isEnabled()) {
                return cityCenterRandom.nextDouble() < profile.cityChance;
            }
            if (sphere.getCenter().chunkX() == coord.chunkX() && sphere.getCenter().chunkZ() == coord.chunkZ()) {
                return cityCenterRandom.nextDouble() < profile.cityChance;
            }
            return false;
        }
        return cityCenterRandom.nextDouble() < profile.cityChance;
    }

    public float getCityRadius(ChunkCoord coord) {
        AssetModels.PredefinedCityAsset predefined = predefinedCities.get(coord);
        if (predefined != null) {
            return predefined.radius();
        }
        // Exact RNG seed constants from City.java:215
        Random cityRadiusRandom = new Random(coord.chunkZ() * 100001653L + coord.chunkX() * 295075153L);
        int range = Math.max(1, profile.cityMaxRadius - profile.cityMinRadius);
        return profile.cityMinRadius + cityRadiusRandom.nextInt(range);
    }

    /**
     * Exact port of {@code City.getCityStyleForCityCenter} (L233-245) using 899809363L & 256203221L.
     */
    public String getCityStyleForCityCenter(ChunkCoord coord, BiFunction<ChunkCoord, Random, String> worldStyleSelector) {
        AssetModels.PredefinedCityAsset predefined = predefinedCities.get(coord);
        if (predefined != null && predefined.cityStyle() != null && !predefined.cityStyle().isBlank()) {
            return predefined.cityStyle();
        }
        Random cityStyleForCenterRandom = new Random(coord.chunkZ() * 899809363L + coord.chunkX() * 256203221L);
        return worldStyleSelector.apply(coord, cityStyleForCenterRandom);
    }

    /**
     * Exact port of {@code City.getCityStyleInt} (L252-302) using 593441843L & 217645177L.
     */
    public String getCityStyleId(ChunkCoord coord, BiFunction<ChunkCoord, Random, String> worldStyleSelector) {
        return styleCache.computeIfAbsent(coord, key -> computeCityStyleIdInternal(key, worldStyleSelector));
    }

    private String computeCityStyleIdInternal(ChunkCoord coord, BiFunction<ChunkCoord, Random, String> worldStyleSelector) {
        List<WeightedStyle> styles = new ArrayList<>();
        int chunkX = coord.chunkX();
        int chunkZ = coord.chunkZ();
        Random cityStyleRandom = new Random(worldSeed + chunkZ * 593441843L + chunkX * 217645177L);

        if (profile.cityChance < 0.0) {
            float factor = rarityMap.getCityFactor(chunkX, chunkZ);
            if (factor < profile.cityStyleThreshold) {
                styles.add(new WeightedStyle(factor, profile.cityStyleAlternative));
            } else {
                styles.add(new WeightedStyle(factor, getCityStyleForCityCenter(coord, worldStyleSelector)));
            }
        } else {
            int offset = (profile.cityMaxRadius + 15) / 16;
            for (int cx = chunkX - offset; cx <= chunkX + offset; cx++) {
                for (int cz = chunkZ - offset; cz <= chunkZ + offset; cz++) {
                    ChunkCoord c = new ChunkCoord(coord.dimensionId(), cx, cz);
                    if (isCityCenter(c)) {
                        float radius = getCityRadius(c);
                        float dx = (cx * 16) - (chunkX << 4);
                        float dz = (cz * 16) - (chunkZ << 4);
                        float sqdist = dx * dx + dz * dz;
                        if (sqdist < radius * radius) {
                            float dist = (float) Math.sqrt(sqdist);
                            float factor = (radius - dist) / radius;
                            if (factor < profile.cityStyleThreshold) {
                                styles.add(new WeightedStyle(factor, profile.cityStyleAlternative));
                            } else {
                                styles.add(new WeightedStyle(factor, getCityStyleForCityCenter(coord, worldStyleSelector)));
                            }
                        }
                    }
                }
            }
        }

        if (styles.isEmpty()) {
            return worldStyleSelector.apply(coord, cityStyleRandom);
        }
        float total = 0.0f;
        for (WeightedStyle ws : styles) {
            total += Math.max(0.0f, ws.weight());
        }
        if (total <= 0.0f) {
            return styles.get(0).styleId();
        }
        float roll = cityStyleRandom.nextFloat() * total;
        float acc = 0.0f;
        for (WeightedStyle ws : styles) {
            acc += Math.max(0.0f, ws.weight());
            if (roll <= acc) {
                return ws.styleId();
            }
        }
        return styles.get(styles.size() - 1).styleId();
    }

    public float getCityFactor(ChunkCoord coord, ToDoubleFunction<ChunkCoord> biomeMultiplier) {
        float factor = factorCache.computeIfAbsent(coord, this::computeCityFactorInternal);
        if (factor > 0.0f && biomeMultiplier != null) {
            factor *= (float) biomeMultiplier.applyAsDouble(coord);
        }
        return factor;
    }

    private float computeCityFactorInternal(ChunkCoord coord) {
        float factor = 0.0f;
        if (profile.cityChance < 0.0) {
            factor = rarityMap.getCityFactor(coord.chunkX(), coord.chunkZ());
        } else {
            int offset = (profile.cityMaxRadius + 15) / 16;
            int bx = coord.chunkX() << 4;
            int bz = coord.chunkZ() << 4;
            for (int cx = coord.chunkX() - offset; cx <= coord.chunkX() + offset; cx++) {
                for (int cz = coord.chunkZ() - offset; cz <= coord.chunkZ() + offset; cz++) {
                    ChunkCoord c = new ChunkCoord(coord.dimensionId(), cx, cz);
                    if (isCityCenter(c)) {
                        float radius = getCityRadius(c);
                        float dx = (cx << 4) - bx;
                        float dz = (cz << 4) - bz;
                        float sqdist = dx * dx + dz * dz;
                        if (sqdist < radius * radius) {
                            float dist = (float) Math.sqrt(sqdist);
                            factor += (radius - dist) / radius;
                        }
                    }
                }
            }
        }
        if (factor > 0.0f) {
            factor *= computeSpawnDistanceMultiplier(coord);
        }
        return factor;
    }

    private float computeSpawnDistanceMultiplier(ChunkCoord coord) {
        if (profile.citySpawnDistance1 <= 0 && profile.citySpawnDistance2 <= 0) return 1.0f;
        double distBlocks = Math.hypot(coord.chunkX() * 16.0, coord.chunkZ() * 16.0);
        if (distBlocks <= profile.citySpawnDistance1) return (float) profile.citySpawnMultiplier1;
        if (distBlocks >= profile.citySpawnDistance2 || profile.citySpawnDistance2 <= profile.citySpawnDistance1) {
            return (float) profile.citySpawnMultiplier2;
        }
        double t = (distBlocks - profile.citySpawnDistance1) / (double) (profile.citySpawnDistance2 - profile.citySpawnDistance1);
        return (float) (profile.citySpawnMultiplier1 + t * (profile.citySpawnMultiplier2 - profile.citySpawnMultiplier1));
    }

    public boolean isCityChunk(ChunkCoord coord, ToDoubleFunction<ChunkCoord> biomeMultiplier) {
        return getCityFactor(coord, biomeMultiplier) >= profile.cityThreshold;
    }

    public void clearCache() {
        factorCache.clear();
        styleCache.clear();
    }
}
