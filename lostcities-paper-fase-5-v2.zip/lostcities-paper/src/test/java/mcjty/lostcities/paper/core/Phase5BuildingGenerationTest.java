/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import mcjty.lostcities.paper.assets.AssetModels;
import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.gen.Doors;
import mcjty.lostcities.paper.core.highway.HighwayModels.HighwayInfo;
import mcjty.lostcities.paper.core.lost.City;
import mcjty.lostcities.paper.core.lost.Railway;
import mcjty.lostcities.paper.core.plan.ChunkPlanner;
import mcjty.lostcities.paper.core.terrain.TerrainHeightField;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

class Phase5BuildingGenerationTest {

    private static final class MapSurface implements BlockSurface {
        final Map<Long, String> blocks = new HashMap<>();
        final int bx, bz;
        MapSurface(int cx, int cz) { this.bx = cx << 4; this.bz = cz << 4; }
        @Override public int minY() { return -64; }
        @Override public int maxY() { return 320; }
        @Override public boolean isInBounds(int x, int y, int z) {
            return x >= bx && x < bx + 16 && z >= bz && z < bz + 16 && y >= -64 && y < 320;
        }
        @Override public String getBlockId(int x, int y, int z) {
            return blocks.getOrDefault(ChunkDriver.packPos(x, y, z), "minecraft:air");
        }
        @Override public void setBlockId(int x, int y, int z, String id) {
            if ("minecraft:air".equals(id)) blocks.remove(ChunkDriver.packPos(x, y, z));
            else blocks.put(ChunkDriver.packPos(x, y, z), id);
        }
    }

    @Test
    void transformRotatesAndMirrorsAllBlockStates() {
        assertEquals("minecraft:oak_stairs[facing=east,half=bottom]",
                Transform.ROTATE_90.transformBlockState("minecraft:oak_stairs[facing=north,half=bottom]"));
        assertEquals("minecraft:oak_door[facing=west,half=lower,hinge=right]",
                Transform.MIRROR_X.transformBlockState("minecraft:oak_door[facing=east,half=lower,hinge=left]"));
        assertEquals("minecraft:oak_log[axis=z]",
                Transform.ROTATE_90.transformBlockState("minecraft:oak_log[axis=x]"));
        assertEquals("minecraft:rail[shape=east_west]",
                Transform.ROTATE_90.transformBlockState("minecraft:rail[shape=north_south]"));
        assertEquals("minecraft:rail[shape=ascending_east]",
                Transform.ROTATE_90.transformBlockState("minecraft:rail[shape=ascending_north]"));
        assertEquals("minecraft:cobblestone_wall[north=none,east=tall,south=none,west=low]",
                Transform.ROTATE_90.transformBlockState("minecraft:cobblestone_wall[north=tall,east=none,south=low,west=none]"));
        assertEquals("minecraft:oak_sign[rotation=4]",
                Transform.ROTATE_90.transformBlockState("minecraft:oak_sign[rotation=0]"));
    }

    @Test
    void layeredPaletteResolvesFromPaletteAndInlineOverride() {
        AssetModels.PaletteEntryModel baseWall = new AssetModels.PaletteEntryModel(
                'W', "minecraft:bricks", "", "", "", "", false, false, List.of());
        AssetModels.PaletteEntryModel aliasWall = new AssetModels.PaletteEntryModel(
                'X', "", "", "W", "", "", false, false, List.of());
        AssetModels.PaletteAsset pBase = new AssetModels.PaletteAsset("lostcities:base", List.of(baseWall, aliasWall), new JsonObject());
        AssetRegistry reg = new AssetRegistry(
                Map.of(), Map.of(), Map.of(), Map.of(),
                Map.of("lostcities:base", pBase),
                Map.of("lostcities:s1", new AssetModels.StyleAsset("lostcities:s1",
                        List.of(List.of(new AssetModels.WeightedRef(1.0f, "lostcities:base"))), new JsonObject())),
                Map.of(), Map.of(), Map.of(), Map.of(), Map.of(), Map.of(), Map.of()
        );
        CompiledPalette compiled = CompiledPalette.buildForBuilding(reg, "lostcities:s1", null, null, new Random(1L));
        assertEquals("minecraft:bricks", compiled.getBlock('W'));
        assertEquals("minecraft:bricks", compiled.getBlock('X'));

        JsonArray inline = new JsonArray();
        JsonObject ov = new JsonObject();
        ov.addProperty("char", "W");
        ov.addProperty("block", "minecraft:stone_bricks");
        inline.add(ov);
        CompiledPalette overlaid = compiled.withInlinePalette(reg, inline);
        assertEquals("minecraft:stone_bricks", overlaid.getBlock('W'));
        assertEquals("minecraft:bricks", overlaid.getBlock('X'));
    }

    @Test
    void hardAirSettingAndFixTorchesAndDoorsWork() {
        LostCityProfile profile = new LostCityProfile("default");
        LostCityTerrainFeature feature = new LostCityTerrainFeature(123L, "lostcities:world", profile);
        MapSurface surface = new MapSurface(0, 0);
        surface.setBlockId(1, 70, 1, "minecraft:stone");
        surface.setBlockId(2, 70, 1, "minecraft:stone");

        AssetModels.PaletteEntryModel hardAir = new AssetModels.PaletteEntryModel(
                '?', "minecraft:structure_void", "", "", "", "", false, false, List.of());
        AssetModels.PaletteEntryModel torch = new AssetModels.PaletteEntryModel(
                'T', "minecraft:torch", "", "", "", "", true, false, List.of());
        AssetModels.PaletteAsset pal = new AssetModels.PaletteAsset("lostcities:p", List.of(hardAir, torch), new JsonObject());
        AssetModels.PartAsset part = new AssetModels.PartAsset(
                "lostcities:testpart", 3, 1, 2, "lostcities:p",
                List.of(List.of("   ", " ?T")), Map.of(), new JsonObject());
        AssetRegistry reg = new AssetRegistry(
                Map.of("lostcities:testpart", part), Map.of(), Map.of(), Map.of(),
                Map.of("lostcities:p", pal), Map.of(), Map.of(), Map.of(), Map.of(), Map.of(), Map.of(), Map.of(), Map.of()
        );

        City city = new City(123L, profile, reg, null, 128, 60);
        TerrainHeightField field = new TerrainHeightField(123L, profile);
        ChunkPlanner planner = new ChunkPlanner(128, 60);
        BuildingInfo info = BuildingInfo.get(new ChunkCoord("lostcities:world", 0, 0), 123L, profile,
                reg, planner, city, field, HighwayInfo.NONE, Railway.RailChunkInfo.NOTHING);

        try (GenerationContext.Scope ignored = GenerationContext.open(123L, "lostcities:world", 0, 0)) {
            ChunkDriver driver = GenerationContext.current().driver();
            driver.begin(surface, 0, 0);
            feature.generatePart(driver, info, part, Transform.ROTATE_NONE, 0, 70, 0,
                    LostCityTerrainFeature.HardAirSetting.AIR, reg, c -> info, null);
            feature.fixTorches(driver, info);
            driver.flush();
        }
        assertEquals("minecraft:air", surface.getBlockId(1, 70, 1));
        assertEquals(70, info.getRelativePos(1, 70, 1).y());
        assertEquals(info.cityLevel + 2, info.localToGlobal(2));
        assertNotNull(BuildingInfo.getRandomDoor(new Random(7L)));
        assertTrue(Doors.doorState("minecraft:oak_door", true, true, "east").contains("half=upper"));
    }
}
